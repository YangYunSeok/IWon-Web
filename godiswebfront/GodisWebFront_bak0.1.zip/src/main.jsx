import React from 'react'
import { createRoot } from 'react-dom/client'

import { ThemeProvider } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline'

import App from '@/App.jsx'
import theme from '@/theme';

import '@/css/styles.css'
// import { PermissionProvider } from '@/authz/PermissionStore.jsx'
// import PermissionEnforcer from '@/authz/PermissionEnforcer.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <StyledEngineProvider injectFirst> {/* 전역 CSS보다 MUI가 먼저 주입되게 */}    
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <App />
      </ThemeProvider>
    </StyledEngineProvider>
  </React.StrictMode>,
)
