import React, { useEffect, useState } from 'react';
import { Stack, Box, Button, TextField, FormControl, Select, MenuItem } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import { SimpleTreeView } from '@mui/x-tree-view/SimpleTreeView';
import { TreeItem } from '@mui/x-tree-view/TreeItem';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import dayjs from 'dayjs';
import CommonSelect from '@/components/CommonSelect';
import CommonButton, { btnSave } from '@/components/CommonButton';
import { http } from '@/libs/TaskHttp';

/**
 * 사용자 관리 화면
 * - 좌측: 소속그룹 트리
 * - 중앙: 사용자 그리드
 * - 우측: 사용자 상세 정보
 */
export default function GPCLOPRUS01S1() {
	// ==============================================================
	//                        변수 정의
	// ==============================================================
	const [groups, setGroups] = useState([]);
	const [selectedGroup, setSelectedGroup] = useState(null);
	const [loadingGroups, setLoadingGroups] = useState(false);

	const [users, setUsers] = useState([]);
	const [selectedUser, setSelectedUser] = useState(null);
	const [loadingUsers, setLoadingUsers] = useState(false);

	const [savingGroup, setSavingGroup] = useState(false);
	const [savingUser, setSavingUser] = useState(false);
	const [hasChanges, setHasChanges] = useState(false);
	const [nextGroupId, setNextGroupId] = useState(5);

	// ==============================================================
	//                        데이터 조회 처리
	// ==============================================================

	const getGroups = async () => {
		try {
			setLoadingGroups(true);
			const param = {};
			const { table } = await http.post('/admin/getusergroups', param, { shape: 'datatable' });

			console.log('=== 받은 데이터 확인 ===');
			console.log('table:', table);
			console.log('첫번째 데이터:', table[0]);
			console.log('USR_GRP_ID:', table[0]?.USR_GRP_ID);
			console.log('USR_GRP_NM:', table[0]?.USR_GRP_NM);
			console.log('UP_USR_GRP_ID:', table[0]?.UP_USR_GRP_ID);

			const mapped = table.map((g, idx) => ({
				id: g.USR_GRP_ID || String(idx),
				...g,
				UP_USR_GRP_ID: g.UP_USR_GRP_ID || null  // 빈 문자열 → null 변환
			}));

			console.log('=== 매핑 후 데이터 ===');
			console.log('mapped:', mapped);

			setGroups(mapped);

			if (!selectedGroup && mapped.length > 0) {
				setSelectedGroup(mapped[0]);
				getUsers(mapped[0].USR_GRP_ID);
			}
		} catch (e) {
			console.error('[소속그룹] 조회 실패', e);
		} finally {
			setLoadingGroups(false);
		}
	};

	const getUsers = async (usrGrpId) => {
		if (!usrGrpId) {
			setUsers([]);
			return;
		}

		try {
			setLoadingUsers(true);
			const param = { USR_GRP_ID: usrGrpId };
			const { table } = await http.post('/admin/getuser', param, { shape: 'datatable' });

			const mapped = table.map((u, idx) => ({ id: u.USR_ID || String(idx), ...u }));
			setUsers(mapped);

			if (mapped.length > 0) {
				setSelectedUser(mapped[0]);
			} else {
				setSelectedUser(null);
			}
		} catch (e) {
			console.error('[사용자] 조회 실패', e);
		} finally {
			setLoadingUsers(false);
		}
	};

	useEffect(() => {
		getGroups();
	}, []);

	// ==============================================================
	//                        데이터 저장 처리
	// ==============================================================
	const saveGroup = async () => {
		if (!hasChanges) return;
		try {
			setSavingGroup(true);
			await new Promise(resolve => setTimeout(resolve, 1000));
			getGroups();
			setHasChanges(false);
		} catch (e) {
			console.error(e);
		} finally {
			setSavingGroup(false);
		}
	};

	const saveUser = async () => {
		if (!hasChanges) return;
		try {
			setSavingUser(true);
			await new Promise(resolve => setTimeout(resolve, 1000));
			if (selectedGroup) {
				getUsers(selectedGroup.USR_GRP_ID);
			}
			setHasChanges(false);
		} catch (e) {
			console.error(e);
		} finally {
			setSavingUser(false);
		}
	};

	const resetPassword = async () => {
		if (!selectedUser) return;
		if (window.confirm(`${selectedUser.USR_NM || selectedUser.USR_ID}의 비밀번호를 초기화하시겠습니까?`)) {
			try {
				await new Promise(resolve => setTimeout(resolve, 500));
				setSelectedUser({ ...selectedUser, PW_ERR_CNT: 0 });
			} catch (e) {
				console.error(e);
			}
		}
	};

	// ==============================================================
	//                     그룹 추가/삭제 처리
	// ==============================================================
	const handleAddGroup = () => {
		if (!selectedGroup) return;

		const newGroupId = `USRG${String(nextGroupId).padStart(6, '0')}`;
		const newGroup = {
			id: newGroupId,
			USR_GRP_ID: newGroupId,
			USR_GRP_NM: '새 그룹',
			UP_USR_GRP_ID: selectedGroup.USR_GRP_ID
		};

		setGroups([...groups, newGroup]);
		setSelectedGroup(newGroup);
		setNextGroupId(nextGroupId + 1);
		setHasChanges(true);
	};

	const handleRemoveGroup = () => {
		if (!selectedGroup) return;

		// 하위 그룹이 있는지 확인
		const hasChildren = groups.some(g => g.UP_USR_GRP_ID === selectedGroup.USR_GRP_ID);
		if (hasChildren) {
			alert('하위 그룹이 존재하는 그룹은 삭제할 수 없습니다.');
			return;
		}

		if (window.confirm(`'${selectedGroup.USR_GRP_NM}' 그룹을 삭제하시겠습니까?`)) {
			const updatedGroups = groups.filter(g => g.USR_GRP_ID !== selectedGroup.USR_GRP_ID);
			setGroups(updatedGroups);

			// 삭제된 그룹이 선택되어 있었다면 선택 해제
			if (updatedGroups.length > 0) {
				const newSelected = updatedGroups.find(g => !g.UP_USR_GRP_ID) || updatedGroups[0];
				setSelectedGroup(newSelected);
				getUsers(newSelected.USR_GRP_ID);
			} else {
				setSelectedGroup(null);
				setUsers([]);
			}

			setHasChanges(true);
		}
	};

	const handleRevertGroup = () => {
		getGroups();
		setHasChanges(false);
	};

	// ==============================================================
	//                        이벤트 정의
	// ==============================================================
	const handleGroupSelect = (group) => {
		if (hasChanges) {
			if (window.confirm('변경된 데이터가 존재합니다! 무시하고 조회 하겠습니까?')) {
				setSelectedGroup(group);
				getUsers(group.USR_GRP_ID);
				setHasChanges(false);
			}
		} else {
			setSelectedGroup(group);
			getUsers(group.USR_GRP_ID);
		}
	};

	const handleUserSelect = (user) => {
		setSelectedUser(user);
	};

	const handleAddUser = () => {
		const today = dayjs().format('YYYYMMDD');
		const newUser = {
			id: `new_${Date.now()}`,
			USR_ID: '',
			USR_NM: '',
			USR_GRP_ID: selectedGroup?.USR_GRP_ID || '',
			USR_GRP_NM: selectedGroup?.USR_GRP_NM || '',
			JOBTITL_NM: '',
			USR_STAT_CD: 'N',
			VALID_STRT_DD: today,
			VALID_END_DD: '99991231',
			PW_ERR_CNT: 0,
			_isNew: true
		};
		setUsers([newUser, ...users]);
		setSelectedUser(newUser);
		setHasChanges(true);
	};

	const handleDeleteUser = () => {
		if (!selectedUser) return;
		if (window.confirm(`${selectedUser.USR_NM || selectedUser.USR_ID}을(를) 삭제하시겠습니까?`)) {
			const updated = users.filter(u => u.id !== selectedUser.id);
			setUsers(updated);
			setSelectedUser(updated.length > 0 ? updated[0] : null);
			setHasChanges(true);
		}
	};

	const handleRevertUser = () => {
		if (selectedGroup) {
			getUsers(selectedGroup.USR_GRP_ID);
			setHasChanges(false);
		}
	};

	const handleUserStatusChange = (newStatus) => {
		if (!selectedUser) return;
		const today = dayjs().format('YYYYMMDD');
		let updatedUser = { ...selectedUser, USR_STAT_CD: newStatus };
		if (newStatus === 'E') {
			updatedUser.VALID_END_DD = today;
		} else if (selectedUser.USR_STAT_CD === 'E' && newStatus === 'A') {
			updatedUser.VALID_END_DD = '99991231';
		}
		setSelectedUser(updatedUser);
		setHasChanges(true);
	};

	const handleValidStartChange = (date) => {
		if (!selectedUser) return;
		const dateStr = dayjs(date).format('YYYYMMDD');
		if (dateStr > selectedUser.VALID_END_DD) return;
		setSelectedUser({ ...selectedUser, VALID_STRT_DD: dateStr });
		setHasChanges(true);
	};

	const handleValidEndChange = (date) => {
		if (!selectedUser) return;
		const dateStr = dayjs(date).format('YYYYMMDD');
		if (dateStr < selectedUser.VALID_STRT_DD) return;
		setSelectedUser({ ...selectedUser, VALID_END_DD: dateStr });
		setHasChanges(true);
	};

	// ==============================================================
	//                        그리드 컬럼 정의
	// ==============================================================
	const userColumns = [
		{
			headerName: 'ID',
			headerAlign: 'center',
			field: 'USR_ID',
			flex: 1,
			editable: false
		},
		{
			headerName: '직위',
			headerAlign: 'center',
			field: 'JOBTITL_NM',
			flex: 1,
			editable: false,
			align: 'center'
		}
	];

	const renderTreeItems = (nodes, parentId = null) => {
		return nodes
			.filter(node => node.UP_USR_GRP_ID === parentId)
			.map(node => (
				<TreeItem
					key={node.id}
					itemId={node.id}
					label={node.USR_GRP_NM}
				>
					{renderTreeItems(nodes, node.USR_GRP_ID)}
				</TreeItem>
			));
	};

	const LabeledInput = ({ label, value, onChange, readOnly = false, width = '100%' }) => (
		<Box display="flex" alignItems="center" width={width}>
			<Box minWidth="100px" fontSize="12px" color="#666" bgcolor="#f5f5f5" padding="6px 12px" marginRight="8px">
				{label}
			</Box>
			<TextField
				fullWidth
				size="small"
				value={value || ''}
				onChange={onChange}
				InputProps={{ readOnly, style: { fontSize: '13px', height: '32px' } }}
				sx={{ '& .MuiOutlinedInput-root': { height: '32px', '& fieldset': { borderColor: '#d0d0d0' } } }}
			/>
		</Box>
	);

	const LabeledSelect = ({ label, value, onChange, options, disabled = false, width = '100%' }) => (
		<Box display="flex" alignItems="center" width={width}>
			<Box minWidth="100px" fontSize="12px" color="#666" bgcolor="#f5f5f5" padding="6px 12px" marginRight="8px">
				{label}
			</Box>
			<FormControl fullWidth size="small">
				<Select
					value={value || ''}
					onChange={onChange}
					disabled={disabled}
					style={{ fontSize: '13px', height: '32px' }}
					sx={{ '& .MuiOutlinedInput-notchedOutline': { borderColor: '#d0d0d0' } }}
				>
					{options.map(option => (
						<MenuItem key={option.code} value={option.code} style={{ fontSize: '13px' }}>
							{option.name}
						</MenuItem>
					))}
				</Select>
			</FormControl>
		</Box>
	);

	const LabeledDatePicker = ({ label, value, onChange, disabled = false, readOnly = false, width = '100%' }) => (
		<Box display="flex" alignItems="center" width={width}>
			<Box minWidth="100px" fontSize="12px" color="#666" bgcolor="#f5f5f5" padding="6px 12px" marginRight="8px">
				{label}
			</Box>
			<DatePicker
				value={value ? dayjs(value, 'YYYYMMDD') : null}
				onChange={onChange}
				format="YYYY-MM-DD"
				disabled={disabled}
				slotProps={{
					textField: {
						size: 'small',
						fullWidth: true,
						InputProps: { readOnly, style: { fontSize: '13px', height: '32px' } },
						sx: { '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#d0d0d0' } } }
					}
				}}
				sx={{ width: '100%', '& .MuiOutlinedInput-root': { height: '32px' } }}
			/>
		</Box>
	);

	// ==============================================================
	//                          화면구성 영역
	// ==============================================================
	return (
		<LocalizationProvider dateAdapter={AdapterDayjs}>
			<div style={{ padding: '8px' }}>
				<Stack spacing={2}>
					{/* 상단: 소속그룹 영역 */}
					<Box sx={{ border: '2px solid #4472C4', padding: '8px', backgroundColor: '#fff', borderRadius: '4px' }}>
						<Stack direction="row" spacing={2} height={380}>
							{/* 좌측: 소속그룹 트리 */}
							<Stack flex={4} style={{ backgroundColor: '#fff' }}>
								<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: '4px 8px', marginBottom: '8px', borderBottom: '1px solid #ddd' }}>
									<Box fontSize="13px" fontWeight="600" color="#333">● 소속그룹</Box>
									<CommonButton
										showAdd={true}
										showDelete={true}
										showRevert={true}
										showExcel={false}
										showSave={false}
										onAdd={handleAddGroup}
										onDelete={handleRemoveGroup}
										onRevert={handleRevertGroup}
									/>
								</Box>
								<Box padding="4px 8px" fontSize="12px" marginBottom="4px">
									사용자그룹명
								</Box>
								<SimpleTreeView
									defaultExpandedItems={groups.map(g => g.id)}
									selectedItems={selectedGroup?.id}
									onSelectedItemsChange={(event, itemId) => {
										const selected = groups.find(g => g.id === itemId);
										if (selected) {
											handleGroupSelect(selected);
										}
									}}
									slots={{ collapseIcon: ExpandMoreIcon, expandIcon: ChevronRightIcon }}
									sx={{
										height: '100%',
										flexGrow: 1,
										overflowY: 'auto',
										backgroundColor: '#fff',
										border: '1px solid #e0e0e0',
										padding: '4px',
										'& .MuiTreeItem-content': { padding: '2px 4px' },
										'& .MuiTreeItem-label': { fontSize: '13px' },
										'& .MuiTreeItem-groupTransition': { marginLeft: 0, paddingLeft: '32px' }
									}}
								>
									{renderTreeItems(groups)}
								</SimpleTreeView>
							</Stack>

							{/* 우측: 사용자 그룹 정보 */}
							<Stack flex={6} style={{ backgroundColor: '#fff' }}>
								<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: '4px 8px', marginBottom: '8px', borderBottom: '1px solid #ddd' }}>
									<Box fontSize="13px" fontWeight="600" color="#333">● 사용자 그룹 정보</Box>
								</Box>
								<Box sx={{ border: '1px solid #e0e0e0', borderRadius: '4px', padding: '16px', flex: 1, display: 'flex', flexDirection: 'column' }}>
									{/* 그룹ID */}
									<Box sx={{ display: 'flex', alignItems: 'center' }}>
										<Box sx={{ minWidth: '100px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderTop: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											그룹ID
										</Box>
										<Box sx={{ flex: 1, marginLeft: '8px' }}>
											<TextField
												fullWidth
												size="small"
												value={selectedGroup?.USR_GRP_ID || ''}
												InputProps={{ readOnly: true, style: { fontSize: '13px', height: '32px' } }}
												sx={{ '& .MuiOutlinedInput-root': { height: '32px', '& fieldset': { borderColor: '#d0d0d0' } } }}
											/>
										</Box>
									</Box>

									{/* 그룹명 */}
									<Box sx={{ display: 'flex', alignItems: 'center', marginTop: '-1px' }}>
										<Box sx={{ minWidth: '100px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											그룹명
										</Box>
										<Box sx={{ flex: 1, marginLeft: '8px' }}>
											<TextField
												fullWidth
												size="small"
												value={selectedGroup?.USR_GRP_NM || ''}
												onChange={(e) => {
													const updatedGroup = { ...selectedGroup, USR_GRP_NM: e.target.value };
													setSelectedGroup(updatedGroup);
													setGroups(groups.map(g =>
														g.USR_GRP_ID === selectedGroup.USR_GRP_ID
															? updatedGroup
															: g
													));
													setHasChanges(true);
												}}
												InputProps={{ style: { fontSize: '13px', height: '32px' } }}
												sx={{ '& .MuiOutlinedInput-root': { height: '32px', '& fieldset': { borderColor: '#d0d0d0' } } }}
											/>
										</Box>
									</Box>
								</Box>
								<div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'auto' }}>
									<Button
										variant="contained"
										onClick={saveGroup}
										disabled={savingGroup || !hasChanges}
										sx={btnSave}
									>
										Save
									</Button>
								</div>
							</Stack>
						</Stack>
					</Box>

					{/* 하단: 사용자 영역 */}
					<Box sx={{ border: '2px solid #4472C4', padding: '8px', backgroundColor: '#fff', borderRadius: '4px' }}>
						<Stack direction="row" spacing={2} height={380}>
							{/* 좌측: 사용자 목록 */}
							<Stack flex={4}>
								<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: '4px 8px', marginBottom: '8px', borderBottom: '1px solid #ddd' }}>
									<Box fontSize="13px" fontWeight="600" color="#333">
										● 사용자 <span style={{ fontSize: '11px' }}>Total ({users.length})</span>
									</Box>
									<CommonButton
										showAdd={true}
										showDelete={true}
										showRevert={true}
										showExcel={false}
										showSave={false}
										onAdd={handleAddUser}
										onDelete={handleDeleteUser}
										onRevert={handleRevertUser}
									/>
								</Box>
								<DataGrid
									rows={users}
									columns={userColumns}
									getRowId={(row) => row.id}
									columnHeaderHeight={30}
									rowHeight={25}
									checkboxSelection
									disableRowSelectionOnClick
									pagination={false}
									hideFooter
									onRowClick={(params) => handleUserSelect(params.row)}
									loading={loadingUsers}
									sx={{
										border: '1px solid #e0e0e0',
										'& .MuiDataGrid-cell': { fontSize: '13px' },
										'& .MuiDataGrid-columnHeaders': { backgroundColor: '#e8f0fe' },
										'& .MuiDataGrid-columnHeaderTitle': { fontSize: '13px', fontWeight: 'bold', color: '#2c5aa0' }
									}}
								/>
							</Stack>

							{/* 우측: 사용자 상세 정보 */}
							<Stack flex={6} style={{ backgroundColor: '#fff' }}>
								<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: '4px 8px', marginBottom: '8px', borderBottom: '1px solid #ddd' }}>
									<Box fontSize="13px" fontWeight="600" color="#333">● 사용자 정보</Box>
								</Box>
								<Box sx={{ border: '1px solid #e0e0e0', borderRadius: '4px', padding: '16px', flex: 1, display: 'flex', flexDirection: 'column' }}>
									{/* ID */}
									<Box sx={{ display: 'flex', alignItems: 'center' }}>
										<Box sx={{ minWidth: '100px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderTop: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											ID
										</Box>
										<Box sx={{ width: '460px', marginLeft: '8px' }}>
											<TextField
												fullWidth
												size="small"
												value={selectedUser?.USR_ID || ''}
												InputProps={{
													readOnly: !selectedUser?._isNew,
													style: { fontSize: '13px', height: '32px' }
												}}
												onChange={(e) => {
													const updatedUser = { ...selectedUser, USR_ID: e.target.value };
													setSelectedUser(updatedUser);
													setUsers(users.map(u =>
														u.id === selectedUser.id ? updatedUser : u
													));
													setHasChanges(true);
												}}
												sx={{ '& .MuiOutlinedInput-root': { height: '32px', '& fieldset': { borderColor: '#d0d0d0' } } }}
											/>
										</Box>
									</Box>

									{/* 소속그룹 / 직위 - ✅ CommonSelect로 변경 */}
									<Box sx={{ display: 'flex', alignItems: 'center', marginTop: '-1px' }}>
										<Box sx={{ minWidth: '100px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderTop: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											소속그룹
										</Box>
										<Box sx={{ width: '460px', marginLeft: '8px', marginRight: '8px' }}>
											<CommonSelect
												data={groups}
												valueKey="USR_GRP_ID"
												labelKey="USR_GRP_NM"
												value={selectedUser?.USR_GRP_ID || ''}
												onChange={(value) => {
													console.log('선택된 그룹 ID:', value);
													const selectedGrp = groups.find(g => g.USR_GRP_ID === value);
													
													const updatedUser = {
														...selectedUser,
														USR_GRP_ID: value,
														USR_GRP_NM: selectedGrp?.USR_GRP_NM || ''
													};
													
													setSelectedUser(updatedUser);
													setUsers(users.map(u =>
														u.id === selectedUser.id ? updatedUser : u
													));
													setHasChanges(true);
												}}
												includeAll={false}
												includeSelect={false}
												width={460}
												height={32}
											/>
										</Box>
										<Box sx={{ minWidth: '105px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderTop: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											직위
										</Box>
										<Box sx={{ flex: 1, marginLeft: '8px' }}>
											<TextField
												fullWidth
												size="small"
												value={selectedUser?.JOBTITL_NM || ''}
												InputProps={{ readOnly: false, style: { fontSize: '13px', height: '32px' } }}
												onChange={(e) => {
													const updatedUser = { ...selectedUser, JOBTITL_NM: e.target.value };
													setSelectedUser(updatedUser);
													setUsers(users.map(u =>
														u.id === selectedUser.id ? updatedUser : u
													));
													setHasChanges(true);
												}}
												sx={{ '& .MuiOutlinedInput-root': { height: '32px', '& fieldset': { borderColor: '#d0d0d0' } } }}
											/>
										</Box>
									</Box>

									{/* 사용자상태 + 로그인실패횟수 */}
									<Box sx={{ display: 'flex', alignItems: 'center', marginTop: '-1px' }}>
										<Box sx={{ minWidth: '100px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											사용자상태
										</Box>
										<Box sx={{ width: '460px', marginLeft: '8px', marginRight: '8px' }}>
											<CommonSelect
												grpCdId="USR_STAT_CD"
												value={selectedUser?.USR_STAT_CD || ''}
												onChange={(value) => {
													console.log('선택된 값:', value);
													handleUserStatusChange(value);
												}}
												includeAll={false}
												includeSelect={false}
												width={460}
												height={32}
											/>
										</Box>
										<Box sx={{ minWidth: '105px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderTop: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											로그인실패횟수
										</Box>
										<Box sx={{ flex: 1, marginLeft: '8px', display: 'flex', gap: 1, alignItems: 'center' }}>
											<TextField
												size="small"
												value={selectedUser?.PW_ERR_CNT || 0}
												InputProps={{ readOnly: true, style: { fontSize: '13px', height: '32px' } }}
												sx={{ flex: 1, '& .MuiOutlinedInput-root': { height: '32px', '& fieldset': { borderColor: '#d0d0d0' } } }}
											/>
											<Button
												variant="contained"
												size="small"
												onClick={resetPassword}
												disabled={!selectedUser}
												style={{ whiteSpace: 'nowrap', height: 32, fontSize: '12px', minWidth: 110, backgroundColor: '#1976d2', color: '#fff' }}
											>
												Reset Password
											</Button>
										</Box>
									</Box>

									{/* 적용일 / 만료일 */}
									<Box sx={{ display: 'flex', alignItems: 'center', marginTop: '-1px' }}>
										<Box sx={{ minWidth: '100px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											적용일
										</Box>
										<Box sx={{ width: '460px', marginLeft: '8px', marginRight: '8px' }}>
											<DatePicker
												value={selectedUser?.VALID_STRT_DD ? dayjs(selectedUser.VALID_STRT_DD, 'YYYYMMDD') : null}
												onChange={handleValidStartChange}
												format="YYYY-MM-DD"
												disabled={!selectedUser}
												readOnly={selectedUser?.USR_STAT_CD !== 'N'}
												slotProps={{
													textField: {
														size: 'small',
														fullWidth: true,
														InputProps: { style: { fontSize: '13px', height: '32px' } },
														sx: { '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#d0d0d0' } } }
													}
												}}
												sx={{ width: '100%', '& .MuiOutlinedInput-root': { height: '32px' } }}
											/>
										</Box>
										<Box sx={{ minWidth: '105px', fontSize: '12px', color: '#666', bgcolor: '#f5f5f5', padding: '6px 12px', borderRight: '1px solid #e0e0e0', borderTop: '1px solid #e0e0e0', borderLeft: '1px solid #e0e0e0', borderBottom: '1px solid #e0e0e0' }}>
											만료일
										</Box>
										<Box sx={{ flex: 1, marginLeft: '8px' }}>
											<DatePicker
												value={selectedUser?.VALID_END_DD ? dayjs(selectedUser.VALID_END_DD, 'YYYYMMDD') : null}
												onChange={handleValidEndChange}
												format="YYYY-MM-DD"
												disabled={!selectedUser}
												readOnly={selectedUser?.USR_STAT_CD === 'E'}
												slotProps={{
													textField: {
														size: 'small',
														fullWidth: true,
														error: false,
														InputProps: { style: { fontSize: '13px', height: '32px' } },
														sx: { '& .MuiOutlinedInput-root': { '& fieldset': { borderColor: '#d0d0d0' } } }
													}
												}}
												sx={{ width: '100%', '& .MuiOutlinedInput-root': { height: '32px' } }}
											/>
										</Box>
									</Box>
								</Box>
								<div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'auto', gap: 8 }}>
									<Button
										variant="contained"
										sx={{
											...btnSave,
											minWidth: 100,
											backgroundColor: '#1976d2',
											'&:hover': { bgcolor: '#1565c0' }
										}}
									>
										관리자로그인
									</Button>
									<Button
										variant="contained"
										onClick={saveUser}
										disabled={savingUser || !hasChanges}
										sx={btnSave}
									>
										Save
									</Button>
								</div>
							</Stack>
						</Stack>
					</Box>
				</Stack>
			</div>
		</LocalizationProvider>
	);
}