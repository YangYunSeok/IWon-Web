// screen file rebuilt to fix syntax and apply requested features
import React, { useEffect, useRef, useState } from "react";
import { Button, Checkbox, Input, Modal, Space, Tabs, message } from "antd";

// 서버호출
import { http } from '@/libs/TaskHttp';

import FlowCanvas from "@/components/FlowCanvas";
import GPCLOPRBT01P1 from "./GPCLOPRBT01P1";


const IMG = {
  group: new URL("./Images/group.png", import.meta.url).href,
  folder: new URL("./Images/folder.png", import.meta.url).href,
  fileExport: new URL("./Images/file-export.png", import.meta.url).href,
  fileImport: new URL("./Images/file-import.png", import.meta.url).href,
  taskStart: new URL("./Images/TaskStart.png", import.meta.url).href,
  proc: new URL("./Images/proc.png", import.meta.url).href,
};

// local saved list (kept for other features)
function listSaved(){
  const keys = Object.keys(localStorage).filter(k=>k.startsWith("flow:"));
  const items = keys.map(k=>{
    try {
      const v = JSON.parse(localStorage.getItem(k) || "{}");
      return { id: k.slice(5), title: v?.meta?.title ?? k.slice(5), updatedAt: v?.meta?.updatedAt ?? '', folderId: v?.meta?.folderId ?? null };
    } catch { return null; }
  }).filter(Boolean);
  items.sort((a,b)=>(b.updatedAt||"").localeCompare(a.updatedAt||""));
  return items;
}

export default function GPCLOPRBT01S1(){
  const canvasRef = useRef(null);

  // === Multi-tab for opened jobs ===
  const [openTabs, setOpenTabs] = useState([]); // [{id, title, _server}]
  const [activeExplorerTab, setActiveExplorerTab] = useState('group');
  const [activeTabId, setActiveTabId] = useState(null);
  const canvasRefs = useRef({}); // id -> FlowCanvas ref

  // selections per explorer tab
  const [selectedGroupId, setSelectedGroupId] = useState(null);
  const [selectedFileMapId, setSelectedFileMapId] = useState(null);
  const [selectedProcId, setSelectedProcId] = useState(null);

  // mount: fetch groups by default
  useEffect(() => {
    try { fetchGroups && fetchGroups(); } catch (e) { console.error(e); }
  }, []);

  const importToTab = (id, payload) => {
    const nodes = payload?.nodes ?? payload?.value?.nodes ?? [];
    const edges = payload?.edges ?? payload?.value?.edges ?? [];
    canvasRefs.current[id]?.importJson({ nodes, edges });
  };

  const openTaskTab = (job) => {
    if (!job) return;
    const id = job.id;
    const title = job.title || id;
    const exists = openTabs.some(t => t.id === id);
    if (exists) { setActiveTabId(id); return; }
    setOpenTabs(prev => [...prev, { id, title, _server: job._server }]);
    setActiveTabId(id);
    setTimeout(() => {
      if (job._server) {
        loadFlowServer(id, /*toTab*/ true);
      } else {
        loadFlowToTab(id);
      }
    }, 0);
  };

  const [showGrid, setShowGrid] = useState(true);
  const [connectMode, setConnectMode] = useState(true);
  const [dirty, setDirty] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [saved, setSaved] = useState(listSaved());
  const [showGroupModal, setShowGroupModal] = useState(false);

  // === Resizable splitter state (left tree <-> canvas) ===
  const MIN_LEFT = 220;
  const MAX_LEFT = 900;
  const [leftWidth, setLeftWidth] = useState(() => {
    const v = parseInt(localStorage.getItem('GPCLOPRBT01_leftWidth'));
    if (Number.isFinite(v)) {
      return Math.min(MAX_LEFT, Math.max(MIN_LEFT, v));
    }
    return 280;
  });
  const draggingRef = useRef(false);
  const startXRef = useRef(0);
  const startWidthRef = useRef(0);
  const onDragStart = (e) => {
    draggingRef.current = true;
    startXRef.current = e.clientX;
    startWidthRef.current = leftWidth;
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  };
  const onDrag = (e) => {
    if (!draggingRef.current) return;
    const dx = e.clientX - startXRef.current;
    let next = startWidthRef.current + dx;
    if (next < MIN_LEFT) next = MIN_LEFT;
    if (next > MAX_LEFT) next = MAX_LEFT;
    setLeftWidth(next);
  };
  const onDragEnd = () => {
    if (!draggingRef.current) return;
    draggingRef.current = false;
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
    localStorage.setItem('GPCLOPRBT01_leftWidth', String(Math.round(leftWidth)));
  };
  useEffect(() => {
    const move = (e) => onDrag(e);
    const up = () => onDragEnd();
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
    return () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
    };
  }, [leftWidth]);

  // === misc / canvas helpers ===
  const fileInputRef = useRef(null);
  const exportJSON = ()=>{
    const json = canvasRef.current?.exportJson();
    const blob = new Blob([json], {type: "application/json"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = (currentId || "flow") + ".json";
    a.click(); URL.revokeObjectURL(url);
  };
  const importJSON = ()=> fileInputRef.current?.click();
  const onFileChange = (e)=>{
    const f = e.target.files?.[0]; if(!f) return;
    const reader = new FileReader();
    reader.onload = ()=>{
      try { canvasRef.current?.importJson(reader.result); message.success("불러오기 완료"); }
      catch { message.error("JSON 형식 오류"); }
    };
    reader.readAsText(f); e.target.value = "";
  };
  const clearExceptStart = ()=>{
    const state = canvasRef.current?.getState?.() || {};
    const existing = Array.isArray(state.nodes) ? state.nodes.find(n => n?.img === IMG.taskStart || n?.label === '시작') : null;
    const startNode = existing ? { ...existing } : { id: 'n_init', type: 'image', img: IMG.taskStart, label: '시작', x: 200, y: 200, w: 86, h: 86 };
    canvasRef.current?.setState?.({ nodes: [startNode], edges: [] });
    setCurrentId(null);
    setDirty(true);
    message.success('초기화 완료: 새 저장만 가능합니다.');
  };

  useEffect(()=>{
    const t = setTimeout(()=>{
      const state = canvasRef.current?.getState?.();
      if(!state || (Array.isArray(state.nodes) && state.nodes.length === 0)){
        const node = { id: "n_init", type: "image", img: IMG.taskStart, label: "시작", x: 200, y: 200, w: 86, h: 86 };
        canvasRef.current?.setState?.({ nodes: [node], edges: [] });
      }
    }, 0);
    return ()=> clearTimeout(t);
  }, []);

  // Save current active tab (server)
  const saveUpdate = ()=>{
    const id = activeTabId || currentId || null;
    if(!id){ message.info('저장할 작업이 없습니다.'); return; }
    const state =
      (activeTabId && canvasRefs.current?.[activeTabId]?.getState)
        ? canvasRefs.current[activeTabId].getState()
        : (canvasRef.current?.getState ? canvasRef.current.getState() : null);

    const nodes = state?.nodes ?? [];
    const edges = state?.edges ?? [];
    const grpXmlContn = JSON.stringify({ nodes, edges });

    const row = { taskGrpId: id, grpXmlContn };

    fetch('/api/admin/savebatchflow', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ updates: [row] })
    })
      .then(res => { if(!res.ok) throw new Error(`HTTP ${res.status}`); return (typeof res.json==='function') ? res.json() : null; })
      .then(() => { setDirty(false); message.success('저장되었습니다.'); })
      .catch(err => { console.error(err); message.error('저장 실패: ' + (err?.message || 'unknown')); });
  };

  const loadFlowToTab = (id)=>{
    const raw = localStorage.getItem("flow:"+id); if(!raw) return;
    try {
      const obj = JSON.parse(raw);
      importToTab(id, { nodes: obj.nodes ?? [], edges: obj.edges ?? [] });
      setCurrentId(id); setDirty(false);
    } catch { message.error("저장 파일이 손상되었습니다."); }
  };

  const loadFlowServer = async (taskGrpId, toTab=false) => {
    try {
      const url = `/api/admin/getbatchflow?taskGrpId=${encodeURIComponent(taskGrpId)}`;
      const res = await fetch(url, { headers: { 'Accept':'application/json' } });
      if(!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      let payload = (data && (data.grpXmlContn ?? data)) ?? {};
      if (typeof payload === 'string') {
        try { payload = JSON.parse(payload); } catch { payload = {}; }
      }
      let nodes = payload?.nodes ?? payload?.value?.nodes ?? [];
      let edges = payload?.edges ?? payload?.value?.edges ?? [];
      const isEmpty = (!Array.isArray(nodes) || nodes.length === 0) &&
                      (!Array.isArray(edges) || edges.length === 0);

      if (isEmpty) {
        const img = IMG?.taskStart;
        const startNode = {
          id: `n_init_${taskGrpId}`,
          type: img ? "image" : "circle",
          img,
          label: "시작",
          x: 200, y: 200, w: 86, h: 86
        };
        nodes = [startNode];
        edges = [];
      }

      const json = { nodes: Array.isArray(nodes) ? nodes : [], edges: Array.isArray(edges) ? edges : [] };
      toTab ? importToTab(taskGrpId, json) : canvasRef.current?.importJson(json);
    } catch (err) {
      console.error(err);
      message.error('작업 불러오기 실패: ' + (err?.message || 'unknown'));
    }
  };

  // === Server lists ===
  const [batchGroups, setBatchGroups] = useState([]);
  const [batchGroupsLoaded, setBatchGroupsLoaded] = useState(false);
  const fetchGroups = async ()=>{
    try{
      const param = { SYS_TP_CD : "STO" }; // 조회 조건 객체(Map 형태)로
      const { name, table } = await http.post('/admin/getbatchgroup',param,{ shape: 'datatable' });

      setBatchGroups(Array.isArray(table) ? table : []);
      setBatchGroupsLoaded(true);
      
    }catch(err){
      console.error(err);
      message.error('배치그룹 재조회 실패: ' + (err?.message || 'unknown'));
    }
  };

  const [fileMaps, setFileMaps] = useState([]);
  const [fileMapsLoaded, setFileMapsLoaded] = useState(false);
  const fetchFileMaps = async () => {
    try {
      const res = await fetch('/api/admin/getfilemaps', { headers: { 'Accept': 'application/json' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const list = await res.json();
      setFileMaps(Array.isArray(list) ? list : []);
      setFileMapsLoaded(true);
    } catch (err) {
      console.error(err);
      message.error('파일맵 조회 실패: ' + (err?.message || 'unknown'));
    }
  };

  const [storedProcs, setStoredProcs] = useState([]);
  const [storedProcsLoaded, setStoredProcsLoaded] = useState(false);
  const fetchStoredProcs = async () => {
    try {
      const res = await fetch('/api/admin/getstoredprocs', { headers: { 'Accept': 'application/json' } });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const list = await res.json();
      setStoredProcs(Array.isArray(list) ? list : []);
      setStoredProcsLoaded(true);
    } catch (err) {
      console.error(err);
      message.error('프로시저 조회 실패: ' + (err?.message || 'unknown'));
    }
  };

  // === Group folder create/rename/delete ===
  const [editingGroupId, setEditingGroupId] = useState(null);
  const [editingGroupName, setEditingGroupName] = useState('');

  const createGroup = () => {
    const tempId = 'tmp_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,6);
    setBatchGroups(prev => [
      ...prev,
      {
        taskGrpId: tempId,
        taskGrpNm: '새 폴더',
        upTaskGrpId: selectedGroupId ?? null,
        taskGrpTpCd: '02',
        sortOrd: 0,
        _state: 'I'
      }
    ]);
    setSelectedGroupId(tempId);
    setEditingGroupId(tempId);
    setEditingGroupName('');
  };

  const commitGroupRename = async (id) => {
    const name = (editingGroupName || '').trim() || '새 폴더';
    const cur = (batchGroups || []).find(g => String(g.taskGrpId) === String(id));
    const parentId = cur ? (cur.upTaskGrpId ?? null) : (selectedGroupId ?? null);
    const isInsert = String(id).startsWith('tmp_') || cur?._state === 'I';

    const row = {
      taskGrpId: isInsert ? null : id,
      taskGrpNm: name,
      upTaskGrpId: parentId,
      taskGrpTpCd: '02',
      sortOrd: 0,
      recordState: isInsert ? 'I' : 'U'
    };
    const payload = isInsert
      ? { inserts: [row], updates: [], deletes: [] }
      : { inserts: [], updates: [row], deletes: [] };

    try {
      const res = await fetch('/api/admin/savebatchgroup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      await fetchGroups(); // sync with server ids
    } catch (err) {
      console.error(err);
      message.error('디렉토리 저장 실패: ' + (err?.message || 'unknown'));
    } finally {
      setEditingGroupId(null);
      setEditingGroupName('');
    }
  };

  const deleteFolder = ()=>{
    if(!selectedGroupId){
      message.info('삭제할 폴더를 먼저 선택하세요');
      return;
    }
    const id = selectedGroupId;

    // 자식(폴더/작업) 존재 여부를 서버 리스트에서 검사
    const hasChild = (batchGroups || []).some(c => (c.upTaskGrpId ?? null) === id);
    if (hasChild) {
      message.warning('하위 디렉토리나 작업이 존재하여 삭제할 수 없습니다.');
      return;
    }

    // 임시 폴더는 클라이언트에서만 제거
    if (String(id).startsWith('tmp_')) {
      setBatchGroups(prev => prev.filter(g => g.taskGrpId !== id));
      setSelectedGroupId(null);
      message.success('삭제되었습니다.');
      return;
    }

    Modal.confirm({
      title: '폴더 삭제',
      content: '선택한 폴더를 삭제하시겠습니까?',
      okText: '삭제', cancelText: '취소',
      async onOk(){
        try{
          const deletes = [{ taskGrpId: id, recordState: 'D' }];
          const res = await fetch('/api/admin/savebatchgroup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ inserts: [], updates: [], deletes })
          });
          if(!res.ok) throw new Error(`HTTP ${res.status}`);
          await fetchGroups();
          setSelectedGroupId(null);
          message.success('삭제되었습니다.');
        }catch(err){
          console.error(err);
          message.error('삭제 실패: ' + (err?.message || 'unknown'));
          throw err;
        }
      }
    });
  };

  // === Tree renderers ===
  const renderBatchGroupTree = (parentId = null, depth = 0, visited = new Set()) => {
    debugger;
    const pid = parentId ?? null;
    const rows = (batchGroups || []).filter(r => (r.UP_TASK_GRP_ID ?? null) === pid);
    return rows.map(r => {
      const id = r.TASK_GRP_ID;
      if (!id) return null;

      if (visited.has(id)) {
        return (
          <div key={`grp_cycle_${id}`} style={{ paddingLeft: (depth + 1) * 16, color: '#c00' }}>
            (순환: {String(id)} → {String(r.UP_TASK_GRP_ID)})
          </div>
        );
      }
      const nextVisited = new Set(visited); nextVisited.add(id);
      const hasChild = (batchGroups || []).some(c => (c.UP_TASK_GRP_ID ?? null) === id);
      const tp = r?.TASK_GRP_TP_CD;
      const iconSrc = tp === '01' ? IMG.group
                    : tp === '02' ? IMG.folder
                    : (hasChild ? IMG.folder : IMG.group);
      const isDraggable = tp !== '02';

      const onDragStart = (e) => {
        try {
          const payload = JSON.stringify({ type: "image", img: iconSrc, label: r.TASK_GRP_NM ?? String(id) });
          e.dataTransfer.setData("application/x-flow-node", payload);
          e.dataTransfer.setData("text/plain", r.TASK_GRP_NM ?? String(id));
        } catch {}
      };

      return (
        <div key={`group_${id}`}>
          <div
            draggable={isDraggable}
            onDragStart={isDraggable ? onDragStart : undefined}
            onClick={() => setSelectedGroupId(id)}
            onDoubleClick={() => {
              if (r.TASK_GRP_TP_CD === '01') {
                openTaskTab({ id: String(id), title: r.TASK_GRP_NM || String(id), _server: true });
              } else if (r.TASK_GRP_TP_CD === '02') {
                setEditingGroupId(id);
                setEditingGroupName(r.TASK_GRP_NM || '');
              }
            }}
            style={{
              paddingLeft: depth * 16,
              height: 28,
              display: 'grid',
              gridTemplateColumns: '18px 1fr',
              alignItems: 'center',
              columnGap: 6,
              fontSize: 13,
              lineHeight: '20px',
              cursor: isDraggable ? 'grab' : 'default',
              background: selectedGroupId === id ? 'rgba(22,119,255,0.15)' : 'transparent'
            }}
            title={String(id)}
            onMouseEnter={(e)=>{ if(selectedGroupId !== id) e.currentTarget.style.background = '#f6f9ff'; }}
            onMouseLeave={(e)=>{ if(selectedGroupId !== id) e.currentTarget.style.background = 'transparent'; }}
          >
            <span><img src={iconSrc} alt="" style={{ width: 16, height: 16, display: 'block' }} /></span>
            {editingGroupId === id ? (
              <Input
                size="small"
                autoFocus
                value={editingGroupName}
                onChange={(e)=> setEditingGroupName(e.target.value)}
                onBlur={()=> commitGroupRename(id)}
                onKeyDown={(e)=>{ if(e.key==='Enter') commitGroupRename(id); if(e.key==='Escape'){ setEditingGroupId(null); setEditingGroupName(''); } }}
                style={{ minWidth: 80 }}
              />
            ) : (
              <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                {r.TASK_GRP_NM ?? id}
              </span>
            )}
          </div>
          {hasChild && renderBatchGroupTree(id, depth + 1, nextVisited)}
        </div>
      );
    });
  };

  const renderFileMapTree = (parentId = null, depth = 0, visited = new Set()) => {
    const pid = parentId ?? null;
    const rows = (fileMaps || []).filter(r => (r.upFileMapId ?? null) === pid);
    return rows.map(r => {
      const id = r.fileMapId;
      if (!id) return null;

      if (visited.has(id)) {
        return (
          <div key={`fmap_cycle_${id}`} style={{ paddingLeft: (depth + 1) * 16, color: '#c00' }}>
            (순환: {String(id)} → {String(r.upFileMapId)})
          </div>
        );
      }
      const nextVisited = new Set(visited); nextVisited.add(id);
      const hasChild = (fileMaps || []).some(c => (c.upFileMapId ?? null) === id);
      const tp = r?.mapTpCd;
      const iconSrc = tp === '00' ? IMG.folder
                     : tp === '01' ? IMG.fileImport
                     : tp === '02' ? IMG.fileExport
                     : (hasChild ? IMG.folder : IMG.fileImport);
      const isDraggable = tp !== '00';

      const onDragStart = (e) => {
        try {
          const payload = JSON.stringify({ type: "image", img: iconSrc, label: r.mapInfoNm ?? String(id) });
          e.dataTransfer.setData("application/x-flow-node", payload);
          e.dataTransfer.setData("text/plain", r.mapInfoNm ?? String(id));
        } catch {}
      };

      return (
        <div key={`fmap_${id}`}>
          <div
            draggable={isDraggable}
            onDragStart={isDraggable ? onDragStart : undefined}
            onClick={() => setSelectedFileMapId(id)}
            style={{
              paddingLeft: depth * 16,
              height: 28,
              display: 'grid',
              gridTemplateColumns: '18px 1fr',
              alignItems: 'center',
              columnGap: 6,
              fontSize: 13,
              lineHeight: '20px',
              cursor: isDraggable ? 'grab' : 'default',
              background: selectedFileMapId === id ? 'rgba(22,119,255,0.15)' : 'transparent'
            }}
            title={String(id)}
            onMouseEnter={(e)=>{ if(selectedFileMapId !== id) e.currentTarget.style.background = '#f6f9ff'; }}
            onMouseLeave={(e)=>{ if(selectedFileMapId !== id) e.currentTarget.style.background = 'transparent'; }}
          >
            <span><img src={iconSrc} alt="" style={{ width: 16, height: 16, display: 'block' }} /></span>
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {r.mapInfoNm ?? id}
            </span>
          </div>
          {hasChild && renderFileMapTree(id, depth + 1, nextVisited)}
        </div>
      );
    });
  };

  const renderProcTree = (parentId = null, depth = 0, visited = new Set()) => {
    const pid = parentId ?? null;
    const rows = (storedProcs || []).filter(r => (r.upProcId ?? null) === pid);
    return rows.map(r => {
      const id = r.procId;
      if (!id) return null;
      if (visited.has(id)) {
        return (
          <div key={`proc_cycle_${id}`} style={{ paddingLeft: (depth + 1) * 16, color: '#c00' }}>
            (순환: {String(id)} → {String(r.upProcId)})
          </div>
        );
      }
      const nextVisited = new Set(visited); nextVisited.add(id);
      const hasChild = (storedProcs || []).some(c => (c.upProcId ?? null) === id);
      const tp = r?.procTpCd;
      const iconSrc = tp === '01' ? IMG.proc
                     : tp === '02' ? IMG.folder
                     : (hasChild ? IMG.folder : IMG.proc);
      const isDraggable = tp !== '02';

      const onDragStart = (e) => {
        try {
          const payload = JSON.stringify({ type: "image", img: iconSrc, label: r.procNm ?? String(id) });
          e.dataTransfer.setData("application/x-flow-node", payload);
          e.dataTransfer.setData("text/plain", r.procNm ?? String(id));
        } catch {}
      };

      return (
        <div key={`proc_${id}`}>
          <div
            draggable={isDraggable}
            onDragStart={isDraggable ? onDragStart : undefined}
            onClick={() => setSelectedProcId(id)}
            style={{
              paddingLeft: depth * 16,
              height: 28,
              display: 'grid',
              gridTemplateColumns: '18px 1fr',
              alignItems: 'center',
              columnGap: 6,
              fontSize: 13,
              lineHeight: '20px',
              cursor: isDraggable ? 'grab' : 'default',
              background: selectedProcId === id ? 'rgba(22,119,255,0.15)' : 'transparent'
            }}
            title={String(id)}
            onMouseEnter={(e)=>{ if(selectedProcId !== id) e.currentTarget.style.background = '#f6f9ff'; }}
            onMouseLeave={(e)=>{ if(selectedProcId !== id) e.currentTarget.style.background = 'transparent'; }}
          >
            <span><img src={iconSrc} alt="" style={{ width: 16, height: 16, display: 'block' }} /></span>
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {r.procNm ?? id}
            </span>
          </div>
          {hasChild && renderProcTree(id, depth + 1, nextVisited)}
        </div>
      );
    });
  };

  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  useEffect(()=>{
    const onPan = (e)=> setPan(e.detail);
    const svg = document.querySelector("svg");
    if (svg) svg.addEventListener("flowcanvas-pan", onPan);
    return () => { if (svg) svg.removeEventListener("flowcanvas-pan", onPan); };
  }, []);

  const tabs = [
    { key: "group", label: "배치그룹", children: (
      <div>
        <div style={{ display:'flex', gap:3, justifyContent:'flex-end' }}>
          <Button style={{ width: 22, height: 22, fontSize: 10, color: "#fff", background:"#0000CD", padding: 0 }} onClick={createGroup}>＋</Button>
          <Button style={{ width: 22, height: 22, fontSize: 10, color: "#fff", background:"#FF0000", padding: 0 }} onClick={deleteFolder}>－</Button>
        </div>
        <div style={{ padding: 8, overflow: 'auto', height: '100%' }}>
          <div>{renderBatchGroupTree(null, 0)}</div>
        </div>
      </div>
    )},
    { key: "file", label: "파일입출력", children: (
      <div style={{ padding: 8, overflow: 'auto', height: '100%' }}>
        <div>{renderFileMapTree(null, 0)}</div>
      </div>
    )},
    { key: "proc", label: "프로시저", children: (
      <div style={{ padding: 8, overflow: 'auto', height: '100%' }}>
        <div>{renderProcTree(null, 0)}</div>
      </div>
    )},
  ];

  return (
    <>
      <div style={{ display: "grid", gridTemplateColumns: `${leftWidth}px 6px 1fr`, height: "calc(100vh - 80px)", gap: 12 }}>
        <div style={{ borderRight: "1px solid #eee", overflow: "hidden", display: "flex", flexDirection: "column" }}>
          <div style={{ flex: 1, overflow: "auto" }}>
            <Tabs
              items={tabs}
              activeKey={activeExplorerTab}
              onChange={(k)=>{
                setActiveExplorerTab(k);
                if(k==='group'){
                  setSelectedFileMapId(null);
                  setSelectedProcId(null);
                  fetchGroups && fetchGroups();
                }
                if(k==='file'){
                  setSelectedGroupId(null);
                  setSelectedProcId(null);
                  fetchFileMaps && fetchFileMaps();
                }
                if(k==='proc'){
                  setSelectedGroupId(null);
                  setSelectedFileMapId(null);
                  fetchStoredProcs && fetchStoredProcs();
                }
              }}
            />
          </div>
        </div>

        {/* splitter (draggable) */}
        <div
          onMouseDown={onDragStart}
          style={{
            cursor: 'col-resize',
            width: 6,
            background: draggingRef.current ? '#eef5ff' : '#f5f5f5',
            borderLeft: '1px solid #e8e8e8',
            borderRight: '1px solid #e8e8e8',
            height: '100%'
          }}
        />

        <div style={{ display: "flex", flexDirection: "column", height: "100%" }}>
          <div style={{ padding: 8, borderBottom: "1px solid #eee", display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <Space>
              <Button onClick={()=>setZoom(z=>Math.min(2.5, +(z + 0.1).toFixed(2)))}>＋</Button>
              <Button onClick={()=>{ setZoom(1); setPan({x:0, y:0}); }}>◎</Button>
              <Button onClick={()=>setZoom(z=>Math.max(0.4, +(z - 0.1).toFixed(2)))}>－</Button>
            </Space>
            <div style={{ flex: 1 }} />
            <Space wrap>
              <Checkbox checked={connectMode} onChange={(e)=>setConnectMode(e.target.checked)}>연결 모드</Checkbox>
              <Checkbox checked={showGrid} onChange={(e)=>setShowGrid(e.target.checked)}>격자</Checkbox>
              <Button onClick={exportJSON}>JSON 내보내기</Button>
              <Button onClick={importJSON}>불러오기</Button>
              <Button onClick={clearExceptStart}>Initial</Button>
            </Space>
            <input ref={fileInputRef} type="file" accept="application/json" onChange={onFileChange} hidden />
          </div>

          <div style={{ position: 'relative', flex: 1, minHeight: 0 }}>
            <Tabs
              type="editable-card"
              hideAdd
              items={openTabs.map(t => ({
                key: t.id,
                label: t.title || t.id,
                children: (
                  <div style={{ position:'relative', height: '100%' }}>
                    <FlowCanvas
                      ref={el => { if (el) { const m = canvasRefs.current || {}; m[t.id] = el; canvasRefs.current = m; } }}
                      showGrid={showGrid}
                      connectMode={connectMode}
                      onChange={()=>setDirty(true)}
                      zoom={zoom}
                      pan={pan}
                    />
                  </div>
                )
              }))}
              activeKey={activeTabId || undefined}
              onChange={(k)=> setActiveTabId(k)}
              onEdit={(targetKey, action) => {
                if (action === 'remove') {
                  setOpenTabs(prev => prev.filter(t => t.id !== targetKey));
                  if (activeTabId === targetKey) {
                    setActiveTabId(prev => {
                      const rest = openTabs.filter(t => t.id !== targetKey);
                      return rest.length ? rest[rest.length - 1].id : null;
                    });
                  }
                  const m = { ...(canvasRefs.current || {}) };
                  delete m[targetKey];
                  canvasRefs.current = m;
                }
              }}
            />
            <div style={{ position:'absolute', right: 16, bottom: 16 }}>
              <Button type="primary" onClick={saveUpdate}>Save</Button>
            </div>
          </div>

        </div>
      </div>

      <GPCLOPRBT01P1
        open={showGroupModal}
        onCancel={()=>setShowGroupModal(false)}
        parentName={'' /* not used in current flow */}
        onSave={(vals)=>{
          const id = 'fld_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,6);
          const name = vals?.groupName || '새 폴더';
          const arr = JSON.parse(localStorage.getItem('flow:__folders') || '[]');
          arr.push({
            id, name, parentId: selectedGroupId || null,
            meta: { ...vals, createdAt: new Date().toISOString() }
          });
          localStorage.setItem('flow:__folders', JSON.stringify(arr));
          message.success('로컬 폴더 메타가 저장되었습니다.');
          setShowGroupModal(false);
        }}
      />
    </>
  );
}
