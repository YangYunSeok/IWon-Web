// src/screens/GPCL/OPR/Menu/GPCLOPRMN01S1.js
import React, { useEffect, useMemo, useRef, useState, useCallback } from 'react';
import { Card, Input, Select, Button, Space, message, Form, InputNumber, Row, Col } from 'antd';
import { SearchOutlined, PictureOutlined } from '@ant-design/icons';
import EditableTable from '@/components/EditableTable.jsx';
import EditableTree from '@/components/EditableTree.jsx';

// 서버호출
import { http } from '@/libs/TaskHttp';

/* flat → tree */
function buildTreeFromFlat(flat = []) {
  const byId = new Map();
  for (const m of flat) {
    const exist = byId.get(m.MENU_ID);
    const node = exist || { key: m.MENU_ID, children: [] };
    node.title = m.MENU_NM || m.MENU_ID;
    Object.assign(node, m);
    if (m.recordState) node.recordState = m.recordState;
    if (!exist) byId.set(m.MENU_ID, node);
  }
  const roots = [];
  for (const m of flat) {
    const node = byId.get(m.MENU_ID);
    const up = (m.UP_MENU_ID || '').trim();
    const parent = up && byId.get(up);
    if (!parent || parent === node) roots.push(node);
    else (parent.children ||= []).push(node);
  }
  const sortRec = (nodes = []) => {
    nodes.sort((a, b) => {
      const ao = Number.isFinite(a.MENU_ORD) ? a.MENU_ORD : 0;
      const bo = Number.isFinite(b.MENU_ORD) ? b.MENU_ORD : 0;
      if (ao !== bo) return ao - bo;
      return String(a.title).localeCompare(String(b.title), undefined, { numeric: true, sensitivity: 'base' });
    });
    nodes.forEach(n => n.children?.length && sortRec(n.children));
  };
  sortRec(roots);
  return roots;
}
function findNodeByKey(nodes, key) {
  if (!nodes || !key) return null;
  for (const n of nodes) {
    if (String(n.key) === String(key)) return n;
    const f = n.children?.length && findNodeByKey(n.children, key);
    if (f) return f;
  }
  return null;
}
function mapNodeToDetail(n) {
  if (!n) return null;
  return {
    menuId: n.menuId ?? n.key ?? '',
    menuIdManual: n.menuIdNum ?? '',
    menuNm: n.menuNm ?? n.title ?? '',
    menuEnNm: n.menuEngNm ?? n.menuEnNm ?? '',
    helpTxt: n.helpUrl ?? '',
    orderNo: Number(n.menuOrd ?? 0),
    screenNo: n.screnNo ?? '',
    linkProgram: n.progmId ?? '',
    topMenuYn: n.upMenuId ? 'N' : 'Y',
    viewTransInfo: n.screnParmContn ?? '',
    openType: n.openTpCd ?? 'EXPAND',
    useYn: n.useYn ?? 'Y',
    menuImage: n.menuImgId ?? '',
  };
}
function mapNodeToGrids(n) {
  const programs = Array.isArray(n?.programs) ? n.programs.map((r, i) => ({ key: r.programId ?? String(i), ...r })) : [];
  const authorities = Array.isArray(n?.authorities) ? n.authorities.map((r, i) => ({ key: r.authCode ?? String(i), ...r })) : [];
  return { programs, authorities };
}

export default function GPCLOPRMN01S1() {
  const [tree, setTree] = useState([]);
  const [treeLoading, setTreeLoading] = useState(false);
  const [selectedMenuId, setSelectedMenuId] = useState(null);
  const treeRef = useRef(null);

  const [detail, setDetail] = useState({
    menuId: '', menuIdManual: '', menuNm: '', menuEnNm: '', helpTxt: '',
    orderNo: 0, screenNo: '', linkProgram: '', topMenuYn: 'N',
    viewTransInfo: '', openType: 'EXPAND', useYn: 'Y', menuImage: '',
  });
  const [detailInitial, setDetailInitial] = useState(null);
  const [savingDetail, setSavingDetail] = useState(false);

  const [programs, setPrograms] = useState([]);
  const [authorities, setAuthorities] = useState([]);
  const [savingPrograms, setSavingPrograms] = useState(false);
  const [savingAuthorities, setSavingAuthorities] = useState(false);
  const programRef = useRef(null);
  const authRef = useRef(null);

  // 화면 높이 기반 (상단 42%, 하단 58%)
  const [vh, setVh] = useState(typeof window !== 'undefined' ? window.innerHeight : 900);
  useEffect(() => {
    const onResize = () => setVh(window.innerHeight);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  const VERTICAL_PADDING = 220;
  const contentH = Math.max(600, vh - VERTICAL_PADDING);
  const TOP_RATIO = 0.42;
  const topBoxH = Math.max(220, Math.floor(contentH * TOP_RATIO));
  const bottomBoxH = Math.max(260, contentH - topBoxH);
  const TREE_OVERHEAD = 70;
  const TABLE_OVERHEAD = 140;
  const treeHeight   = Math.max(350, topBoxH - TREE_OVERHEAD);
  const tableScrollY = Math.max(220, bottomBoxH - TABLE_OVERHEAD);

  // 최초 1회 트리 로드
  useEffect(() => {
    (async () => {
      try {
        setTreeLoading(true);

      const param = { SYS_TP_CD : "STO" }; // 조회 조건을 JS 객체(Map 형태)로
      const { name, table } = await http.post('/admin/getmenus',param,{ shape: 'datatable' });

      setTree(table);
      const first = table?.[0];
      if (first) {
          setSelectedMenuId(first.key);
          const d = mapNodeToDetail(first); if (d) { setDetail(d); setDetailInitial(d); }
          const g = mapNodeToGrids(first); setPrograms(g.programs); setAuthorities(g.authorities);
      }
      } catch (e) { console.error(e); message.error('메뉴 트리를 불러오지 못했습니다.'); }
      finally { setTreeLoading(false); }
    })();
  }, []);

  const applyFromTree = useCallback((key) => {
    const node = findNodeByKey(tree, key); if (!node) return;
    const d = mapNodeToDetail(node); if (d) { setDetail(d); setDetailInitial(d); }
    const g = mapNodeToGrids(node); setPrograms(g.programs); setAuthorities(g.authorities);
  }, [tree]);
  useEffect(() => { if (selectedMenuId) applyFromTree(selectedMenuId); }, [selectedMenuId, applyFromTree]);
  useEffect(() => { if (selectedMenuId) applyFromTree(selectedMenuId); }, [tree, selectedMenuId, applyFromTree]);

  /** ===== 컬럼 정의(공통코드 화면과 동일한 패턴) ===== */
  const programColumns = useMemo(() => ([
    { title: 'System',       dataIndex: 'systemCd',  key: 'systemCd',  width: 100, editor: 'text' },
    { title: 'Program ID',   dataIndex: 'programId', key: 'programId', width: 160, editor: 'text', readOnly: true },
    { title: 'Program Name', dataIndex: 'programNm', key: 'programNm', width: 220, editor: 'text' },
    { title: 'Url',          dataIndex: 'url',       key: 'url',                     editor: 'text' },
  ]), []);

  const authColumns = useMemo(() => ([
    { title: 'Authority', dataIndex: 'authCode', key: 'authCode', width: 140, editor: 'text', readOnly: true },
    { title: '버튼 설명', dataIndex: 'authDesc', key: 'authDesc',               editor: 'text' },
  ]), []);

  /** ===== 저장 ===== */
  const isDetailDirty = () => JSON.stringify(detail) !== JSON.stringify(detailInitial);
  const handleSaveDetail = async () => {
    if (!isDetailDirty()) { message.info('변경된 내역이 없습니다.'); return; }
    try {
      setSavingDetail(true);
      const res = await fetch('/api/admin/savemenu', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(detail),
      });
      console.log('메뉴저장 로그==============================')
      console.log(res);

      if (!res.ok) throw new Error('메뉴 상세 저장 실패');
      await res.json().catch(() => ({}));
      setDetailInitial(detail);
      message.success('메뉴 상세가 저장되었습니다.');
    } catch (e) { console.error(e); message.error(e.message || '저장 중 오류가 발생했습니다.'); }
    finally { setSavingDetail(false); }
  };
  const handleSavePrograms = async () => {
    const payload = programRef.current?.getCudPayload?.() || { inserts: [], updates: [], deletes: [] };
    if (!payload.inserts?.length && !payload.updates?.length && !payload.deletes?.length) { message.info('변경된 내역이 없습니다.'); return; }
    try {
      setSavingPrograms(true);
      const res = await fetch('/api/menu/savePrograms', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ menuId: selectedMenuId, ...payload }),
      });
      if (!res.ok) throw new Error('프로그램 저장 실패');
      await res.json().catch(() => ({}));
      message.success('프로그램이 저장되었습니다.');
    } catch (e) { console.error(e); message.error(e.message || '저장 중 오류가 발생했습니다.'); }
    finally { setSavingPrograms(false); }
  };
  const handleSaveAuthorities = async () => {
    const payload = authRef.current?.getCudPayload?.() || { inserts: [], updates: [], deletes: [] };
    if (!payload.inserts?.length && !payload.updates?.length && !payload.deletes?.length) { message.info('변경된 내역이 없습니다.'); return; }
    try {
      setSavingAuthorities(true);
      const res = await fetch('/api/menu/saveAuthorities', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ menuId: selectedMenuId, ...payload }),
      });
      if (!res.ok) throw new Error('권한 버튼 저장 실패');
      await res.json().catch(() => ({}));
      message.success('권한 버튼이 저장되었습니다.');
    } catch (e) { console.error(e); message.error(e.message || '저장 중 오류가 발생했습니다.'); }
    finally { setSavingAuthorities(false); }
  };

  /** ===== 레이아웃 ===== */
  return (
    // 오른쪽 밀림/가로 스크롤 방지
    <div style={{ position: 'relative', left: 0, width: '100%', minWidth: 0, maxWidth: '100%', overflowX: 'hidden' }}>
      {/* 상단 (트리 / 상세) */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0, 0.9fr) minmax(0, 1.45fr)',
          gap: 12,
          marginBottom: 12,
        }}
      >
        <Card size="small" title="Menu" bodyStyle={{ padding: 8 }} style={{ minWidth: 0 }}>
          <EditableTree
            ref={treeRef}
            treeData={tree}
            onDataChange={setTree}
            keyField="key"
            titleField="title"
            childrenField="children"
            flagField="recordState"
            height={treeHeight}
            loading={treeLoading}
            onSelectKey={setSelectedMenuId}
            bordered
          />
        </Card>

        <Card size="small" title="Detail" bodyStyle={{ padding: 8 }} style={{ minWidth: 0 }}>
          <Form size="small" colon={false} labelAlign="right" labelCol={{ flex: '120px' }} wrapperCol={{ flex: 'auto' }}>
            <Row gutter={8}>
              <Col span={12}><Form.Item label="Menu ID"><Input value={detail.menuId} disabled /></Form.Item></Col>
              <Col span={12}><Form.Item label="Menu ID (직접입력)"><Input value={detail.menuIdManual} onChange={e=>setDetail({...detail, menuIdManual:e.target.value})} /></Form.Item></Col>
            </Row>
            <Row gutter={8}>
              <Col span={12}><Form.Item label="메뉴명"><Input value={detail.menuNm} onChange={e=>setDetail({...detail, menuNm:e.target.value})} /></Form.Item></Col>
              <Col span={12}><Form.Item label="영문메뉴명"><Input value={detail.menuEnNm} onChange={e=>setDetail({...detail, menuEnNm:e.target.value})} /></Form.Item></Col>
            </Row>
            <Row gutter={8}>
              <Col span={12}><Form.Item label="도움말"><Input value={detail.helpTxt} onChange={e=>setDetail({...detail, helpTxt:e.target.value})} /></Form.Item></Col>
              <Col span={12}><Form.Item label="Order"><InputNumber style={{width:'100%'}} value={detail.orderNo} onChange={v=>setDetail({...detail, orderNo:Number(v||0)})} /></Form.Item></Col>
            </Row>
            <Row gutter={8}>
              <Col span={12}>
                <Form.Item label="Screen Number">
                  <Space.Compact style={{ width: '100%' }}>
                    <Input value={detail.screenNo} onChange={e=>setDetail({...detail, screenNo:e.target.value})} />
                    <Button icon={<SearchOutlined />} />
                  </Space.Compact>
                </Form.Item>
              </Col>
              <Col span={12}><Form.Item label="연결프로그램"><Input value={detail.linkProgram} onChange={e=>setDetail({...detail, linkProgram:e.target.value})} /></Form.Item></Col>
            </Row>
            <Row gutter={8}>
              <Col span={12}>
                <Form.Item label="Menu Image">
                  <Space.Compact style={{ width: '100%' }}>
                    <Input value={detail.menuImage} onChange={e=>setDetail({...detail, menuImage:e.target.value})} placeholder="이미지 경로/URL" />
                    <Button icon={<PictureOutlined />}>Image</Button>
                  </Space.Compact>
                </Form.Item>
              </Col>
              <Col span={12}>
                <Form.Item label="최상위 메뉴">
                  <Select value={detail.topMenuYn} onChange={v=>setDetail({...detail, topMenuYn:v})}
                          options={[{value:'Y',label:'Yes'},{value:'N',label:'No'}]} />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={8}>
              <Col span={12}><Form.Item label="화면전환정보"><Input value={detail.viewTransInfo} onChange={e=>setDetail({...detail, viewTransInfo:e.target.value})} /></Form.Item></Col>
              <Col span={12}>
                <Form.Item label="Open 유형">
                  <Select value={detail.openType} onChange={v=>setDetail({...detail, openType:v})}
                          options={[{value:'EXPAND',label:'Expand'},{value:'POPUP',label:'Popup'},{value:'TAB',label:'Tab'}]} />
                </Form.Item>
              </Col>
            </Row>
            <Row gutter={8}>
              <Col span={12} />
              <Col span={12}>
                <Form.Item label="사용여부">
                  <Select value={detail.useYn} onChange={v=>setDetail({...detail, useYn:v})}
                          options={[{value:'Y',label:'Yes'},{value:'N',label:'No'}]} />
                </Form.Item>
              </Col>
            </Row>
          </Form>
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
            <Button type="primary" onClick={handleSaveDetail} loading={savingDetail}>Save</Button>
          </div>
        </Card>
      </div>

      {/* 하단 (프로그램 / 권한) */}
      <div
        style={{
          display: 'grid',
          gridTemplateColumns: 'minmax(0, 7fr) minmax(0, 3fr)',
          gap: 12,
        }}
      >
        <Card size="small" title="Program List" bodyStyle={{ padding: 8 }} style={{ minWidth: 0 }}>
          <EditableTable
            ref={programRef}
            rowKey="programId"
            columns={programColumns}
            data={programs}
            onDataChange={setPrograms}
            tableWidth="100%"
            scrollX={900}
            scrollY={tableScrollY}
            enableRowSelection
            totalCount={programs.length}
            totalLabel="Total"
            showRowEditAction
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
            <Button type="primary" onClick={handleSavePrograms} loading={savingPrograms}>Save</Button>
          </div>
        </Card>

        <Card
          size="small"
          title="Program Authority Button"
          extra={<span style={{ color: '#d4380d', fontWeight: 600 }}>Authority</span>}
          bodyStyle={{ padding: 8 }}
          style={{ minWidth: 0 }}
        >
          <EditableTable
            ref={authRef}
            rowKey="authCode"
            columns={authColumns}
            data={authorities}
            onDataChange={setAuthorities}
            tableWidth="100%"
            scrollX={600}
            scrollY={tableScrollY}
            enableRowSelection
            totalCount={authorities.length}
            totalLabel="Total"
            showRowEditAction
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
            <Button type="primary" onClick={handleSaveAuthorities} loading={savingAuthorities}>Save</Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
