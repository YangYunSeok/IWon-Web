import React, { useEffect, useMemo, useState, useRef } from 'react';
import { Card, Input, Select, Button, Space, message, Table } from 'antd';

// 콤보박스
//import CommonSelect from '../../../../components/CommonSelect';
//import CommonRadio from '../../../../components/CommonRadio';


import EditableTable from '@/components/EditableTable.jsx';
import CommonSelect  from '@/components/CommonSelect.jsx';
import CommonRadio   from '@/components/CommonRadio.jsx';


export default function GPCLOPRTESTS1() {
  // 검색바 상태
  const [grpNm, setGrpNm] = useState('');
  const [grpType, setGrpType] = useState('ALL'); // UI 필터 (백엔드 파라미터 아님)
  const [status, setStatus] = useState('Y'); // 초기값 'Y'
  
  // 누락된 상태 변수들 추가
  const [groups, setGroups] = useState([]);
  const [loadingGroups, setLoadingGroups] = useState(false);
  const [selectedGrpId, setSelectedGrpId] = useState(null);

  const getGroups = async () => {
    try {
      setLoadingGroups(true);
      const q = grpNm ? `?grpNm=${encodeURIComponent(grpNm)}` : '';
      const res = await fetch(`/api/admin/getgroups${q}`);

      console.log(res);

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const list = await res.json();

      console.log(list);

      // 프론트 단 그룹유형 필터
      const filtered = (grpType && grpType !== 'ALL')
        ? list.filter(g => (g.grpTypeCd || '').toUpperCase() === grpType)
        : list;

      const mapped = filtered.map((g, idx) => ({
        key: g.grpCdId || String(idx),
        ...g,
      }));
      setGroups(mapped);

      // 최초 로드 시 선택 없으면 첫 행 기준으로 하단 조회
      if (!selectedGrpId && mapped.length > 0) {
        setSelectedGrpId(mapped[0].grpCdId ?? mapped[0].key);
      }
    } catch (e) {
      console.error('[공통코드] 그룹 조회 실패', e);
      message.error('그룹 목록을 불러오지 못했습니다.');
    } finally {
      setLoadingGroups(false);
    }
  };

  return (
    <div>
      {/* 검색 바 */}
      <Card size="small" title="Select Box" style={{ marginBottom: 8 }}>
        <Space align="center" wrap>
          <Space.Compact>
            <Input
              value={grpNm}
              onChange={(e) => setGrpNm(e.target.value)}
              onPressEnter={getGroups}
              placeholder="그룹코드명"
              style={{ width: 200 }}
              performanceMode="large"
            />
            <CommonSelect
              grpCdId="GRP_TP_CD" // 상태코드 그룹
              value={grpType}
              onChange={setGrpType}
              includeAll={true}
              allLabel="-- All --"
              performanceMode="large"
              width={160}
            />
          </Space.Compact>
          <Button auth="Search" type="primary" onClick={getGroups}>Search</Button>
        </Space>

        <div style={{ marginTop: 16 }}>
          <p>그룹명: <strong>{grpNm || '(비어있음)'}</strong></p>
          <p>그룹타입: <strong>{grpType}</strong></p>
          <p>조회된 그룹 수: <strong>{groups.length}개</strong></p>
        </div>
      </Card>

      {groups.length > 0 && (
        <Card size="small" title={`조회 결과 (${groups.length}개)`}>
          <Table
            dataSource={groups}  // 모든 데이터
            size="small"
            pagination={false}   // 페이징 없이
            scroll={{ y: 200 }}  // 200px 높이에서 스크롤
            columns={[
              {
                title: '그룹ID',
                dataIndex: 'grpCdId',
                key: 'grpCdId',
                width: 120,
              },
              {
                title: '그룹명',
                dataIndex: 'grpNm',
                key: 'grpNm',
                width: 200,
              },
              {
                title: '타입',
                dataIndex: 'grpTypeCd',
                key: 'grpTypeCd',
                width: 100,
              },
              {
                title: '사용여부',
                dataIndex: 'useYn',
                key: 'useYn',
                width: 80,
              },
            ]}
          />
        </Card>
      )}

      {/* Radio Button 테스트 */}
      <Card size="small" title="Radio Button" style={{ marginBottom: 16 }}>
        <Space direction="vertical" style={{ width: '100%' }}>
          <div style={{ marginBottom: 2 }}>
            <label>상태 (문자열 가로 방향): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={['활성', '비활성', '대기']}
            />
          </div>
          
          <div style={{ marginBottom: 2 }}>
            <label>상태 (문자열 세로 방향): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={['활성', '비활성', '대기']}
              direction="vertical"
            />
          </div>

          <div style={{ marginBottom: 2 }}>
            <label>상태 (객체 배열): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={[
                { label: '활성', value: 'Y' },
                { label: '비활성', value: 'N' },
                { label: '대기', value: 'W' }
              ]}
            />
          </div>

          <div style={{ marginBottom: 2 }}>
            <label>상태 (버튼 스타일): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={[
                { label: '활성', value: 'Y' },
                { label: '비활성', value: 'N' },
                { label: '대기', value: 'W' }
              ]}
              buttonStyle={true}
            />
          </div>

          
        </Space>
        
        {/* 현재 값 표시 */}
        <div style={{ marginTop: 16 }}>
          <p>선택된 상태: <strong>{status}</strong></p>
        </div>
      </Card>
    </div>
  );
}
