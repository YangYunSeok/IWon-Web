import React, { useEffect, useState } from 'react';
import { Card, Input, Select, Space, message } from 'antd';

import GDataGrid from '@/components/GDataGrid.jsx';
import GDateEditCell from '@/components/GDateEditCell.jsx';
import GMessageBox from '@/components/GMessageBox';

import { Grid } from '@mui/material';
import { Stack } from '@mui/material';
import { Button } from '@mui/material';

// 서버호출/유틸
import { http } from '@/libs/TaskHttp';
import { changes, toValueOptions } from '@/libs/Utils';
import { cacheCode } from '@/libs/DataUtils';
import { cacheMsgs } from '@/libs/DataUtils';

export default function GPCLOPRCD01S1() {
  // ===== Cache 코드 =====
  const [grpTypeCd, setGrpTypeCd] = useState([]);

  // ===== 검색/그리드 상태 =====
  const [grpNm, setGrpNm] = useState('');
  const [grpTpCd, setGrpTpCd] = useState('ALL');
  const [groups, setGroups] = useState([]);
  const [items, setItems] = useState([]);
  const [loadingGroups, setLoadingGroups] = useState(false);
  const [loadingItems, setLoadingItems] = useState(false);
  const [selectedGrpId, setSelectedGrpId] = useState(null);

  // 저장 로딩
  const [savingGroup, setSavingGroup] = useState(false);
  const [savingCode, setSavingCode] = useState(false);

  const rowYesMo = [
    { value: 'Y', label: 'Yes' },
    { value: 'N', label: 'No'  },
  ];

  // ===== Cache 선조회 (초기 한 번) =====
  useEffect(() => {
    (async () => {
      try {
        const keys = ['GRP_TP_CD', 'SINGL_CURR_YN'];
        const caches = await cacheCode(keys);   // { GRP_TP_CD: [...] }
        setGrpTypeCd(caches.GRP_TP_CD ?? []);
      } catch (e) {
        message.error('[공통코드] Cache 데이터 조회 실패');
      }
    })();
  }, []);

  // ===== 데이터 조회 =====
  const getGroups = async () => {
    try {
      setLoadingGroups(true);
      const param = { GRP_NM : grpNm, GRP_TYPE_CD : grpTpCd }; // 조회 조건을 JS 객체(Map 형태)로
      const { name, table } = await http.post('/admin/getgroups',param,{ shape: 'datatable' });
      //const { tables } = await http.post('/admin/getcommon',param,{ shape: 'dataset' });
      //const group = tables.GROUP;
      setGroups(table);
      if (table && table.length > 0) {
        setSelectedGrpId(table[0]);
      }
    } catch (e) {
      console.error('[공통코드] 그룹 조회 실패', e);
      message.error('그룹 목록을 불러오지 못했습니다.');
    } finally {
      setLoadingGroups(false);
    }
  };

  const getItems = async (param) => {
    if (!param) { setItems([]); return; }
    try {
      setLoadingItems(true);
      const { name, table } = await http.post('/admin/getcodes', param, { shape: 'datatable' });
      setItems(table);
    } catch (e) {
      console.error('[공통코드] 항목 조회 실패', e);
      message.error('공통코드 목록을 불러오지 못했습니다.');
    } finally {
      setLoadingItems(false);
    }
  };

  useEffect(() => { getGroups(); }, []);
  useEffect(() => { getItems(selectedGrpId); }, [selectedGrpId]);

  // ===== 저장 =====
  const saveGroup = async () => {
    const data = changes(groups);

    if (data.length === 0) {
      await GMessageBox.Show('MGE00890', 'Ok', 'warning', 'Infomation');
      return;
    }

    const r = await GMessageBox.Show('MGE00890', 'YesNo', 'warning', 'Warning');
    // r: 'ok' | 'cancel' | 'yes' | 'no'
    if (r === 'no') {
      return;
    }


    try {
      setSavingGroup(true);
      await http.post('/admin/savegroup', data, { shape: 'datarow' });
      message.success('공통코드그룹이 저장되었습니다.');
      getGroups();
    } catch (e) {
      console.error(e);
      message.error(e.message || '공통코드그룹 저장 중 오류가 발생했습니다.');
    } finally {
      setSavingGroup(false);
    }
  };

  const saveCode = async () => {
    // 기존 코드 흐름 유지 (예: codeRef 사용시 그대로)
    message.info('코드 저장 로직은 별도 구현 영역입니다.');
  };

  // ===== 신규행 템플릿 =====
  const addGroupRow = () => ({
    ROW_STATE: 'I',
    GRP_CD_ID: `_NEW_${Date.now()}`,
    GRP_NM: '',
    GRP_CD_DSC: '',
    GRP_TYPE_CD: '01',
    MEM_CREAT_OBJ_YN: 'Y',
    VALID_STRT_DD: '20240101',
    VALID_END_DD: '99991231',
  });

  const addItemRow = () => ({
    ROW_STATE: 'I',
    CD_VAL: `_NEW_${Date.now()}`,
    CD_VAL_NM: '',
    USE_YN: 'Y',
  });

  // ===== 컬럼 =====
  const groupColumns = [
    { headerName: '공통코드그룹'  , headerAlign: 'center', field: 'GRP_CD_ID'       ,                       width: 200, editable: true },
    { headerName: '그룹명'        , headerAlign: 'center', field: 'GRP_NM'          ,                       width: 300, editable: true },
    { headerName: '설명'          , headerAlign: 'center', field: 'GRP_CD_DSC'      ,                       width: 400, editable: true },
    { headerName: '그룹유형'      , headerAlign: 'center', field: 'GRP_TYPE_CD'     , type:'singleSelect',  width: 120, editable: true, valueOptions: toValueOptions(grpTypeCd, 'CD_VAL', 'CD_VAL_NM') },
    { headerName: 'Cache대상'     , headerAlign: 'center', field: 'MEM_CREAT_OBJ_YN', type:'singleSelect',  width: 110, editable: true, valueOptions: rowYesMo },
    { headerName: '적용일'        , headerAlign: 'center', field: 'VALID_STRT_DD'   ,                       width: 120, editable: true, displayAsYmd: true, renderEditCell:(p)=><GDateEditCell {...p} /> },
    { headerName: '만료일'        , headerAlign: 'center', field: 'VALID_END_DD'    ,                       width: 120, editable: true, displayAsYmd: true, renderEditCell:(p)=><GDateEditCell {...p} /> },
  ];

  const itemColumns = [
    { headerName: '공통코드'      , headerAlign: 'center', field: 'CD_VAL'          ,                       width: 120, editable: true },
    { headerName: '공통코드명'    , headerAlign: 'center', field: 'CD_VAL_NM'       ,                       width: 160, editable: true },
    { headerName: '공통코드영문명', headerAlign: 'center', field: 'CD_VAL_ENG_NM'   ,                       width: 180, editable: true },
    { headerName: '설명'          , headerAlign: 'center', field: 'CD_VAL_DSC'      ,                                                   editable: true },
    { headerName: '상위코드명'    , headerAlign: 'center', field: 'UP_CD_VAL_NM'    ,                       width: 140, editable: true },
    { headerName: '정렬순서'      , headerAlign: 'center', field: 'SORT_ORD'        ,                       width: 100, editable: true, align: 'right' },
    { headerName: '추가문자1'     , headerAlign: 'center', field: 'CD_ADD_INFO_VAL1',                       width: 120, editable: true },
    { headerName: '추가문자2'     , headerAlign: 'center', field: 'CD_ADD_INFO_VAL2',                       width: 120, editable: true },
    { headerName: '추가문자3'     , headerAlign: 'center', field: 'CD_ADD_INFO_VAL3',                       width: 120, editable: true },
    { headerName: '추가숫자1'     , headerAlign: 'center', field: 'CD_ADD_INFO_NO1' ,                       width: 100, editable: true, align: 'right' },
    { headerName: '추가숫자2'     , headerAlign: 'center', field: 'CD_ADD_INFO_NO2' ,                       width: 100, editable: true, align: 'right' },
    { headerName: '추가숫자3'     , headerAlign: 'center', field: 'CD_ADD_INFO_NO3' ,                       width: 100, editable: true, align: 'right' },
    { headerName: '사용여부'      , headerAlign: 'center', field: 'USE_YN'          , type:'singleSelect',  width: 110, editable: true, valueOptions: rowYesMo },
  ];

  return (
    <div>
      <Stack>
        <Stack direction="row" spacing={2}>
          <Grid container spacing={2}>
            <Grid size={5}>
              <Input
                value={grpNm}
                onChange={(e) => setGrpNm(e.target.value)}
                onPressEnter={getGroups}
                placeholder="그룹코드명"
                style={{ width: 200, height: 25 }}
              />
            </Grid>
            <Grid size="grow">
              <Button auth="Search" type="primary" onClick={getGroups}>SEARCH</Button>
            </Grid>
          </Grid>
        </Stack>

        {/* 상단: 공통코드그룹 */}
        <Stack>
          <GDataGrid
            title="공통코드그룹"
            rows={groups}
            columns={groupColumns}
            Buttons={[true, true, true, true]}
            columnHeaderHeight={30}
            rowHeight={25}
            checkboxSelection
            height={350}
            pagination={false}
            hideFooter
            disableRowSelectionOnClick
            onRowsChange={setGroups}
            onRowClick={(params) => getItems(params.row)}
            createNewRow={addGroupRow}
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
            <Button auth="Save" type="primary" onClick={saveGroup} loading={savingGroup} width={100}>
              Save
            </Button>
          </div>
        </Stack>

        <Stack height={10} />

        {/* 하단: 공통코드 */}
        <Stack>
          <GDataGrid
            title="공통코드"
            rows={items}
            columns={itemColumns}
            Buttons={[true, true, true, true]}
            columnHeaderHeight={30}
            rowHeight={25}
            height={300}
            pagination={false}
            hideFooter
            checkboxSelection
            disableRowSelectionOnClick
            createNewRow={addItemRow}
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
            <Button auth="Save" type="primary" onClick={saveCode} loading={savingCode}>
              Save
            </Button>
          </div>
        </Stack>
      </Stack>
    </div>
  );
}
 