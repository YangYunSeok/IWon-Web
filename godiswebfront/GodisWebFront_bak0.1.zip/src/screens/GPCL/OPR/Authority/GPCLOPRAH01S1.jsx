import React, { useEffect, useMemo, useState, useRef } from "react";
import { Card, Space, Button, message } from "antd";
import EditableTreeTable from "@/components/EditableTreeTable";
import EditableTable from '@/components/EditableTable';

// 서버호출
import { http } from '@/libs/TaskHttp';

/**
 * GPCLOPRAH01S1 - 역할 정의 & 메뉴/버튼 권한
 * 상단: EditableTable (역할 정의)
 * 하단: EditableTreeTable (트리 + 권한 체크박스 등 다양한 에디터)
 */
export default function GPCLOPRAH01S1() {
  const [roles, setRoles] = useState([]);
  const [treeRows, setTreeRows] = useState([]);
  const [roleEditingKey, setRoleEditingKey] = useState(null);
  const [loading, setLoading] = useState(false);       // 공통 버튼 로딩
  const [loadingRoles, setLoadingRoles] = useState(false); // 상단 그리드 로딩
  const [loadingMenus, setLoadingMenus] = useState(false);

  // === Save 버튼용 상태 ===
  const [savingRole, setSavingRole] = useState(false);
  const [savingMenu, setSavingMenu] = useState(false);

  // === 공통컴포넌트 ref ===
  const roleRef = useRef(null);
  const menuRef = useRef(null);

  // ===== 역할 목록 조회 =====
  const getRoles = async () => {
    try {
      setLoadingRoles(true);

      const param = { SYS_TP_CD : "STO" }; // 조회 조건을 JS 객체(Map 형태)로
      const { name, table } = await http.post('/admin/getroles',param,{ shape: 'datatable' });

      setRoles(table);
    
    } catch (e) {
      console.error('[역할정의] 역할 조회 실패', e);
      message.error('역할 목록을 불러오지 못했습니다.');
    } finally {
      setLoadingRoles(false);
    }
  };

  useEffect(() => { getRoles(); }, []);

  /** ========== Save: 공통컴포넌트의 I/U/D만 전송 (getCudPayload 사용) ========== */
  const saveRole = async () => {
    const payload = roleRef.current?.getCudPayload?.() || { inserts: [], updates: [], deletes: [] };
    const empty = (!payload.inserts?.length && !payload.updates?.length && !payload.deletes?.length);
    if (empty) {
      message.info('변경된 내역이 없습니다.');
      return;
    }
    try {
      setSavingRole(true);

      const res = await fetch('/api/admin/saverole', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('공통코드그룹 저장 실패');
      await res.json().catch(() => ({}));
      message.success('역할이 저장되었습니다.');
      getRoles();
    } catch (e) {
      console.error(e);
      message.error(e.message || '역할 저장 중 오류가 발생했습니다.');
    } finally {
      setSavingRole(false);
    }
  };

  /** ========== Save: 공통컴포넌트의 I/U/D만 전송 (getCudPayload 사용) ========== */
  const saveMenu = async () => {
    const payload = menuRef.current?.getCudPayload?.() || { inserts: [], updates: [], deletes: [] };
    const empty = (!payload.inserts?.length && !payload.updates?.length && !payload.deletes?.length);
    if (empty) {
      message.info('변경된 내역이 없습니다.');
      return;
    }
    try {
      setSavingRole(true);
      const res = await fetch('/api/admin/saverolemenu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('공통코드그룹 저장 실패');
      await res.json().catch(() => ({}));
      message.success('공통코드그룹이 저장되었습니다.');
    } catch (e) {
      console.error(e);
      message.error(e.message || '공통코드그룹 저장 중 오류가 발생했습니다.');
    } finally {
      setSavingMenu(false);
    }
  };

  // 상단 컬럼
  const roleColumns = useMemo(() => [
    { title:"사용자유형" , dataIndex:"USR_TP_CD"    , key: 'USR_TP_CD'   , width:110, align:"center" },
    { title:"역할명"     , dataIndex:"ROLE_NM"      , key: 'ROLE_NM'     , width:180, editor:{ type:"text" } },
    { title:"역할 영문명", dataIndex:"ROLE_ENG_NM"  , key: 'ROLE_ENG_NM' , width:220, editor:{ type:"text" } },
    { title:"설명"       , dataIndex:"roleDsc"      , key: 'roleDsc'     , width:360, editor:{ type:"text" } },
  ], []);

  // 하단 권한 컬럼
  const rightsColumns = useMemo(() => {
    const chk = (title, dataIndex) => ({
      title, dataIndex, width:90, align:"center",
      editor:{ type:"checkbox", cascade:{ down:true } }
    });
    return [
      { title:"Menu", dataIndex:"menu", width:260, fixed:"left", editor:{ type:"text", disabled:true } },
      { title:"All", dataIndex:"all", width:70, align:"center", editor:{ type:"checkbox", cascade:{ down:true } } },
      chk("Accept","accept"),
      chk("Add","add"),
      chk("Authority","authority"),
      chk("Cancel","cancel"),
      chk("Compile","compile"),
      chk("Confirm","confirm"),
      chk("Copy","copy"),
      chk("Create","create"),
      chk("Delete","delete"),
      chk("Deploy","deploy"),
      chk("Download","download"),
      chk("Exec","exec"),
    ];
  }, []);

  const handleSearch = async () => {
    setLoading(true);
    try {
      // TODO: GET /api/authority/roles, GET /api/authority/menu-rights
      message.success("검색 완료 (샘플)");
    } catch (e) {
      console.error(e);
      message.error("검색 실패");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Space direction="vertical" size={12} style={{ width: "100%" }}>
      <Card size="small" title="역할 정의" extra={
        <Space>
          <Button auth="Search" onClick={getRoles}>Search</Button>
        </Space>
      }>
        <EditableTable
          ref={roleRef}
          rowKey="roleId"
          columns={roleColumns}
          showRowEditAction
          editingRowKey={roleEditingKey}
          onStartEdit={setRoleEditingKey}
          data={roles}
          onChange={setRoles}
          scrollX={1000}
          scrollY={300}
          enableRowSelection={true}
          tableStyle={{ opacity: loadingRoles ? 0.6 : 1 }}
          totalCount={roles.length}
          totalLabel="Total"
          bordered
        />
        {/* ← 그리드 우측 하단 Save */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
          <Button auth="Save" type="primary" onClick={saveRole} loading={savingRole}>
            Save
          </Button>
        </div>
      </Card>

      <Card size="small" title="메뉴/버튼/권한">
        <EditableTreeTable
          rowKey="key"
          columns={rightsColumns}
          value={treeRows}
          onChange={setTreeRows}
          scroll={{ x:'max-content', y:380 }}
        />
        {/* ← 그리드 우측 하단 Save */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
          <Button auth="Save" type="primary" onClick={saveMenu} loading={savingRole}>
            Save
          </Button>
        </div>
      </Card>
    </Space>
  );
}