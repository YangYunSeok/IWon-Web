import dayjs from 'dayjs';
import React, { useState, useEffect, useRef, useMemo, useCallback, useImperativeHandle } from 'react';
import { Table, Input, Button, Select, DatePicker, InputNumber } from 'antd';
import {
  PlusOutlined,
  MinusOutlined,
  UndoOutlined,
  PlusCircleOutlined,
  MinusCircleOutlined,
  EditOutlined,
} from '@ant-design/icons';

/** ========= 리사이즈 핸들 설정 ========= */
const HANDLE_WIDTH = 10;
const HANDLE_OFFSET_PX = (-HANDLE_WIDTH - 2) / 2;

/* ===== 직전 값 보관 훅 ===== */
function usePrevious(value) {
  const ref = React.useRef();
  React.useEffect(() => { ref.current = value; }, [value]);
  return ref.current;
}

/* ===== 입력 최적화: 로컬 편집 셀 ===== */
const EditableTextCell = React.memo(function EditableTextCell({ value, onCommit }) {
  const [local, setLocal] = useState(value ?? '');
  useEffect(() => { setLocal(value ?? ''); }, [value]);
  return (
    <Input
      size="small"
      value={local}
      onChange={(e) => setLocal(e.target.value)}
      onBlur={() => onCommit(local)}
      onPressEnter={() => onCommit(local)}
    />
  );
});

const EditableNumberCell = React.memo(function EditableNumberCell({ value, onCommit }) {
  const [local, setLocal] = useState(value ?? 0);
  useEffect(() => { setLocal(value ?? 0); }, [value]);
  return (
    <InputNumber
      size="small"
      value={local}
      style={{ width: '100%', textAlign: 'right' }}
      onChange={(val) => setLocal(typeof val === 'number' ? val : 0)}
      onBlur={() => onCommit(typeof local === 'number' ? local : 0)}
      onPressEnter={() => onCommit(typeof local === 'number' ? local : 0)}
    />
  );
});

/* ===== 헤더 셀 오버레이: 경계선 전용 리사이즈 핸들 ===== */
const ResizableHeaderCell = React.memo(function ResizableHeaderCell(props) {
  const { children, onResizeStart, resizable, className, style, ...rest } = props;
  return (
    <th
      {...rest}
      className={className ? `${className} resizable-th` : 'resizable-th'}
      style={{ position: 'relative', ...style }}
    >
      {children}
      {resizable && (
        <div
          onMouseDown={(e) => { e.stopPropagation(); onResizeStart?.(e); }}
          onClick={(e) => e.stopPropagation()}
          style={{
            position: 'absolute',
            top: 0,
            right: HANDLE_OFFSET_PX,
            width: HANDLE_WIDTH,
            height: '100%',
            cursor: 'col-resize',
            zIndex: 10,
          }}
        />
      )}
    </th>
  );
});

/** ================= CUD 헬퍼 =================
 *  - __order는 사용/보관하지 않습니다.
 *  - recordState(I/U/D)는 각 행에 그대로 두고, 페이로드에도 포함합니다.
 */
export const buildCudPayload = (rows = [], flagField = 'recordState') => {
  const get = (r) => String(r?.[flagField] ?? '').toUpperCase();
  const cloneOne = (r) => ({ ...r }); // recordState 포함하여 그대로 복제
  const inserts = rows.filter(r => get(r) === 'I').map(cloneOne);
  const updates = rows.filter(r => get(r) === 'U').map(cloneOne);
  const deletes = rows.filter(r => get(r) === 'D').map(cloneOne);
  return { inserts, updates, deletes };
};

/**
 * EditableTable
 * - 내부에서 I/U/D 플래그를 표준화하여 관리합니다.
 * - flagField 기본값은 'recordState'이며, 필요 시 mirrorFlagField(예: '_status')로 동기화 가능합니다.
 * - 부모는 ref.getCudPayload()로 저장 페이로드를 쉽게 만들 수 있습니다.
 * - __order는 사용하지 않습니다.
 */
const EditableTable = React.forwardRef(function EditableTable({
  performanceMode = false, // 유지만, 실제론 항상 최적화 적용
  columns,
  data,
  onDataChange,
  tableWidth,
  tableStyle,
  scrollX,
  scrollY,
  rowKey = 'key',
  editingRowKey = null,
  onStartEdit,
  showRowEditAction = false,
  enableRowSelection = false,
  rowSelectionProps,
  onRow,
  totalCount,
  totalLabel = 'Total',

  /** === 플래그 관련 옵션 === */
  flagField = 'recordState',
  mirrorFlagField = null,
}, ref) {
  // ===== helpers: get row key from prop =====
  const getRowKey = useCallback((row) => {
    if (!row) return undefined;
    if (typeof rowKey === 'function') return rowKey(row);
    if (typeof rowKey === 'string' && rowKey) return row?.[rowKey];
    return row?.key ?? row?.id;
  }, [rowKey]);

  // flag getter/setter
  const getFlag = useCallback((row) => String(row?.[flagField] ?? '').toUpperCase(), [flagField]);
  const setFlag = useCallback((row, next) => {
    const updated = { ...row, [flagField]: next };
    if (mirrorFlagField) updated[mirrorFlagField] = next;
    return updated;
  }, [flagField, mirrorFlagField]);

  // ===== 공통 상태 =====
  const [tableData, setTableData] = useState(() => (Array.isArray(data) ? data.map(r => ({ ...r })) : []));
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const [sortConfig, setSortConfig] = useState({ dataIndex: null, order: null });
  const originalDataRef = useRef([]);
  const isLocalUpdateRef = useRef(false);
  const suppressNextDataSyncRef = useRef(false);

  // React 18 비긴급 업데이트 (폴백)
  const startTransition = React.startTransition ?? ((fn) => fn());

  // ===== data 동기화 =====
  useEffect(() => {
    const clone = (items) => (items || []).map((it) => ({ ...it }));
    if (suppressNextDataSyncRef.current) {
      suppressNextDataSyncRef.current = false;
      return;
    }
    const incoming = clone(data || []);
    setTableData(incoming);
    originalDataRef.current = clone(incoming);
    setSortConfig({ dataIndex: null, order: null });
    // 외부에서 데이터가 재주입되면 EditMode 자동 해제
    if (onStartEdit && editingRowKey != null) {
        onStartEdit(null);
    }
  }, [data]);

  useEffect(() => {
    if (onDataChange && isLocalUpdateRef.current) {
      suppressNextDataSyncRef.current = true;
      onDataChange(tableData);
      isLocalUpdateRef.current = false;
    }
  }, [tableData, onDataChange]);

  // ===== 편집 커밋 =====
  const markDirty = useCallback((arr, keyVal) =>
    arr.map((r) => {
      if (getRowKey(r) !== keyVal) return r;
      const curr = getFlag(r);
      const nextFlag = curr === 'I' ? 'I' : 'U'; // 신규면 I 유지, 그 외는 U
      return setFlag(r, nextFlag);
    })
  , [getRowKey, getFlag, setFlag]);

  const commitCellChange = useCallback((rowKeyVal, dataIndex, value) => {
    isLocalUpdateRef.current = true;
    startTransition(() => {
      setTableData((prev) => {
        let changed = false;
        const next = prev.map((r) => {
          if (getRowKey(r) === rowKeyVal) {
            if (r[dataIndex] === value) return r;
            changed = true;
            return { ...r, [dataIndex]: value };
          }
          return r; // 참조 유지
        });
        return changed ? markDirty(next, rowKeyVal) : prev;
      });
    });
  }, [getRowKey, markDirty, startTransition]);

  // ===== 추가/삭제/되돌리기 =====
  const handleAdd = useCallback(() => {
    isLocalUpdateRef.current = true;
    const newKey = `NEW_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const emptyRow = {};
    (columns || []).forEach((c) => {
      if (!c?.dataIndex) return;
      emptyRow[c.dataIndex] = (c.editor === 'number') ? 0 : '';
    });
    if (typeof rowKey === 'string' && rowKey) emptyRow[rowKey] = newKey;
    else emptyRow.key = newKey;

    const newRow = setFlag({ ...emptyRow }, 'I'); // __order 제거
    startTransition(() => setTableData((prev) => [...prev, newRow]));
    if (onStartEdit) onStartEdit(String(newKey));
  }, [columns, rowKey, setFlag, startTransition]);

  const handleDelete = useCallback(() => {
    if (selectedRowKeys.length === 0) return;
    isLocalUpdateRef.current = true;
    startTransition(() => {
      setTableData((prev) => {
        const updated = prev.map((row) => {
          const k = getRowKey(row);
          if (selectedRowKeys.includes(k)) {
            if (getFlag(row) === 'I') return null;   // 신규는 즉시 제거
            return setFlag(row, 'D');                // 그 외는 D 마킹
          }
          return row;
        });
        return updated.filter(Boolean);
      });
      setSelectedRowKeys([]);
    });
  }, [selectedRowKeys, getRowKey, getFlag, setFlag, startTransition]);

  const handleUndo = useCallback(() => {
    isLocalUpdateRef.current = true;
    startTransition(() => {
      setTableData((prev) => {
        const origMap = new Map((originalDataRef.current || []).map(r => [getRowKey(r), { ...r }]));
        const selected = new Set(selectedRowKeys);
        const next = [];
        for (const row of prev) {
          const k = getRowKey(row);
          if (!selected.has(k)) { next.push(row); continue; }
          if (getFlag(row) === 'I') { continue; } // 신규는 제거
          const orig = origMap.get(k);
          if (orig) next.push({ ...orig });
        }
        return next;
      });
      setSelectedRowKeys([]);
    });
  }, [selectedRowKeys, getRowKey, getFlag, startTransition]);

  // ===== 선택 =====
  const rowSelection = useMemo(() => {
    if (!enableRowSelection) return undefined;        // off면 컬럼 숨김
    return {
      selectedRowKeys,
      onChange: (keys) => setSelectedRowKeys(keys),
      columnWidth: rowSelectionProps?.columnWidth ?? 36,
      ...rowSelectionProps,
    };
  }, [enableRowSelection, selectedRowKeys, rowSelectionProps]);

  // ===== 상태 컬럼 =====
  const STATE_COL_WIDTH = 50;
  const stateColumn = {
    title: '상태',
    dataIndex: flagField,       // recordState 표시
    key: flagField,
    width: STATE_COL_WIDTH,
    align: 'center',
    render: (state) => {
      if (state === 'I') return <PlusCircleOutlined style={{ color: '#1890ff' }} />;
      if (state === 'D') return <MinusCircleOutlined style={{ color: '#ff4d4f' }} />;
      if (state === 'U') return <EditOutlined style={{ color: '#fa8c16' }} />;
      return null;
    },
  };

  // ===== 리사이즈 상태 =====
  const MIN_COL_WIDTH = 60;
  const isResizingRef = useRef(false);
  const [colWidths, setColWidths] = useState(() => {
    const init = {};
    (columns || []).forEach(c => { if (c?.dataIndex) init[c.dataIndex] = c.width || 120; });
    return init;
  });

  useEffect(() => {
    setColWidths(prev => {
      const next = { ...prev };
      (columns || []).forEach(c => {
        if (!c?.dataIndex) return;
        if (next[c.dataIndex] == null) next[c.dataIndex] = c.width || 120;
      });
      return next;
    });
  }, [columns]);

  // 리사이즈 시작
  const startResize = useCallback((e, dataIndex) => {
    if (e.button !== 0) return;
    isResizingRef.current = true;
    e.preventDefault();

    const startX = e.pageX ?? e.clientX;
    const startWidth = (colWidths[dataIndex] ?? 120);
    let raf = null;

    const onMove = (ev) => {
      const pageX = ev.pageX ?? ev.clientX;
      const delta = pageX - startX;
      const next = Math.max(MIN_COL_WIDTH, startWidth + delta);
      if (!raf) {
        raf = requestAnimationFrame(() => {
          setColWidths((prev) => ({ ...prev, [dataIndex]: next }));
          raf = null;
        });
      }
    };
    const onUp = () => {
      window.removeEventListener('mousemove', onMove, true);
      window.removeEventListener('mouseup', onUp, true);
      if (raf) cancelAnimationFrame(raf);
      isResizingRef.current = false;
      document.body.style.userSelect = '';
    };

    document.body.style.userSelect = 'none';
    window.addEventListener('mousemove', onMove, true);
    window.addEventListener('mouseup', onUp, true);
  }, [colWidths]);

  // ===== 편집 행 판정(문자열 정규화) =====
  const isEditing = useCallback(
    (record) => String(getRowKey(record)) === (editingRowKey == null ? '' : String(editingRowKey)),
    [getRowKey, editingRowKey]
  );

  // ===== Row edit action column (pencil) =====
  const actionColumn = useMemo(() => !showRowEditAction ? null : ({
    title: '',
    key: '__row_edit__',
    width: 36,
    fixed: 'left',
    render: (_, record) => {
      const keyVal = getRowKey(record);
      const editing = isEditing(record);
      return (
        <span
          onClick={(e) => {
            e.stopPropagation();
            if (!onStartEdit) return;
            const nextKey = editing ? null : String(keyVal);
            onStartEdit(nextKey); // 클릭 즉시 활성/비활성
          }}
          style={{ cursor: 'pointer' }}
          title={editing ? '편집 해제' : '편집'}
        >✏️</span>
      );
    }
  }), [showRowEditAction, getRowKey, isEditing, onStartEdit]);

  // ===== Select 옵션 정규화 =====
  const normalizedColumns = useMemo(() => {
    const normalizeOptions = (opts) =>
      (opts || []).map((o) => (typeof o === 'string' ? { label: o, value: o } : o));
    return (columns || []).map((col) => ({
      ...col,
      __options: col.editor === 'select' ? normalizeOptions(col.options) : undefined,
    }));
  }, [columns]);

  // ===== 컬럼 구성 =====
  const editableColumns = useMemo(() => {
    return (normalizedColumns || []).map((col) => {
      if (!col || !col.dataIndex) return col;
      const dataIndex = col.dataIndex;
      const width = (colWidths[dataIndex] ?? col.width ?? 120);

      // 인라인 에디터 (로컬 셀 활용)
      const renderCell = (text, record) => {
        const __rowKeyVal = getRowKey(record);
        const isEditingRow = (editingRowKey != null && String(__rowKeyVal) === String(editingRowKey));

        const isKeyCol = (typeof rowKey === 'string' && rowKey) ? dataIndex === rowKey : false;
        const __isNew = getFlag(record) === 'I';
        if (!isEditingRow || col.readOnly || (isKeyCol && !__isNew)) {
          return <span>{record[dataIndex]}</span>;
        }

        const v = record[dataIndex];
        if (col.editor === 'number') {
          return (
            <EditableNumberCell
              value={v}
              onCommit={(val) => commitCellChange(getRowKey(record), dataIndex, val)}
            />
          );
        }
        if (col.editor === 'select') {
          const opts = col.__options || [];
          return (
            <Select
              size="small"
              value={v}
              options={opts}
              onChange={(val) => commitCellChange(getRowKey(record), dataIndex, val)}
              style={{ width: '100%' }}
            />
          );
        }
        if (col.editor === 'date') {
          return (
            <DatePicker
              size="small"
              value={v ? dayjs(v) : null}
              onChange={(d) => commitCellChange(getRowKey(record), dataIndex, d ? d.format('YYYY-MM-DD') : '')}
              style={{ width: '100%' }}
            />
          );
        }

        return (
          <EditableTextCell
            value={v}
            onCommit={(val) => commitCellChange(getRowKey(record), dataIndex, val)}
          />
        );
      };

      return {
        ...col,
        width,
        align: col.align || (col.editor === 'number' ? 'right' : (col.editor === 'date' ? 'center' : 'left')),
        sorter: true,
        sortOrder: sortConfig.dataIndex === dataIndex ? sortConfig.order : null,
        sortDirections: ['ascend', 'descend'],
        onHeaderCell: () => ({
          resizable: true,
          onResizeStart: (evt) => startResize(evt, dataIndex),
        }),
        render: renderCell,
      };
    });
  }, [normalizedColumns, colWidths, sortConfig, editingRowKey, getRowKey, commitCellChange, startResize]);

  // ===== 정렬 비교기 / 뷰 데이터 =====
  const comparator = useMemo(() => {
    const sc = sortConfig;
    if (!sc.dataIndex || !sc.order) return null;  // 정렬 해제 시 비용 없음
    const di = sc.dataIndex;
    const asc = sc.order === 'ascend';
    return (a, b) => {
      const av = a[di];
      const bv = b[di];
      if (av == null && bv == null) return 0;
      if (av == null) return -1;
      if (bv == null) return 1;
      if (typeof av === 'number' && typeof bv === 'number') return asc ? av - bv : bv - av;
      const ad = Date.parse(av);
      const bd = Date.parse(bv);
      if (!isNaN(ad) && !isNaN(bd)) return asc ? ad - bd : bd - ad;
      const r = String(av).localeCompare(String(bv), undefined, { numeric: true, sensitivity: 'base' });
      return asc ? r : -r;
    };
  }, [sortConfig]);

  const viewData = useMemo(() => {
    if (!comparator) return tableData; // 정렬 없으면 원본 참조 유지(입력 순서 유지)
    const arr = tableData.slice(0);
    return arr.sort(comparator);
  }, [tableData, comparator]);

  // ===== 셀 단위 리렌더 가드(현재/직전 편집행 즉시 반영) =====
  const prevEditingRowKey = usePrevious(editingRowKey);
  const optimizedColumns = useMemo(() => {
    const guard = (dataIndex) => (record, prev) => {
      const k = getRowKey(record), pk = getRowKey(prev);
      if (
        String(k)  === String(editingRowKey) || String(pk) === String(editingRowKey) ||
        String(k)  === String(prevEditingRowKey) || String(pk) === String(prevEditingRowKey)
      ) {
        return true;
      }
      if (!dataIndex) return true;
      return record?.[dataIndex] !== prev?.[dataIndex];
    };
    return (editableColumns || []).map(col => ({
      ...col,
      shouldCellUpdate: guard(col.dataIndex),
    }));
  }, [editableColumns, editingRowKey, prevEditingRowKey, getRowKey]);

  // ===== 컬럼 합치기 =====
  const fullColumns = useMemo(
    () => [stateColumn, ...(actionColumn ? [actionColumn] : []), ...(optimizedColumns || editableColumns)],
    [stateColumn, actionColumn, optimizedColumns, editableColumns]
  );

  // ===== 총 폭 계산 =====
  const totalWidth = useMemo(() => {
    let sum = STATE_COL_WIDTH;
    (columns || []).forEach((c) => {
      if (!c?.dataIndex) return;
      sum += (colWidths[c.dataIndex] ?? c.width ?? 120);
    });
    return sum;
  }, [columns, colWidths]);

  const scrollXEffective = useMemo(() => {
    const ext = Number.isFinite(scrollX) ? Number(scrollX) : 0;
    return Math.max(ext, totalWidth);
  }, [scrollX, totalWidth]);

  // ===== AntD Table components =====
  const components = useMemo(() => ({
    header: { cell: ResizableHeaderCell },
  }), []);

  /** ===== 외부로 편리한 API 제공 (ref) ===== */
  useImperativeHandle(ref, () => ({
    /** 현재 테이블 데이터 (recordState 포함) */
    getData: () => tableData.slice(0),
    /** I/U/D 기준 CUD 페이로드 (recordState 포함) */
    getCudPayload: () => buildCudPayload(tableData, flagField),
    /** 변경된 행 목록만 반환 (recordState 포함) */
    getChangedRows: () => tableData.filter(r => ['I','U','D'].includes(getFlag(r))).map(r => ({ ...r })),
  }), [tableData, flagField, getFlag]);

  return (
    <div style={{ width: tableWidth, ...tableStyle }}>
      <div style={{ display:'flex', marginBottom:6 }}>
        <div style={{ width:'100px', textAlign:'left' }}>{totalLabel} ({totalCount})</div>
        <div style={{ flex:1, textAlign: 'right' }}>
          <Button size='small' icon={<PlusOutlined />} onClick={handleAdd} style={{ marginRight: 8 }} />
          <Button size='small' icon={<MinusOutlined />} onClick={handleDelete} style={{ marginRight: 8 }} disabled={selectedRowKeys.length === 0} />
          <Button size='small' icon={<UndoOutlined />} onClick={handleUndo} />
        </div>
      </div>
      <Table
        components={components}
        rowKey={rowKey}
        rowSelection={rowSelection}
        columns={fullColumns}
        dataSource={viewData}
        size="small"
        rowClassName={() => 'compact-row'}
        pagination={false}
        bordered
        /** ✅ 가상 스크롤 활성화 (AntD v5+) */
        virtual
        sticky
        scroll={{ x: scrollXEffective, ...(scrollY ? { y: scrollY } : {}) }}
        tableLayout="fixed"
        onRow={onRow}
        onChange={(_, __, sorter) => {
          const s = Array.isArray(sorter) ? sorter[0] : sorter;
          const di = s?.field ?? s?.columnKey ?? s?.column?.dataIndex ?? null;
          const ord = s?.order ?? null;
          setSortConfig({ dataIndex: di, order: ord });
        }}
     />
    </div>
  );
});

export default EditableTable;
