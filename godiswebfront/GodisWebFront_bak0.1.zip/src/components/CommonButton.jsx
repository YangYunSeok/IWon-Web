// CommonButton.jsx
import * as React from 'react';
import { Box, IconButton, Tooltip, Button } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import ReplayIcon from '@mui/icons-material/Replay';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';
import SaveIcon from '@mui/icons-material/Save';

/**
 * 공통 버튼 컴포넌트
 * @param {Object} props
 * @param {boolean} props.showAdd - 추가 버튼 표시 여부
 * @param {boolean} props.showDelete - 삭제 버튼 표시 여부
 * @param {boolean} props.showRevert - 되돌리기 버튼 표시 여부
 * @param {boolean} props.showExcel - 엑셀 버튼 표시 여부
 * @param {boolean} props.showSave - 저장 버튼 표시 여부
 * @param {Function} props.onAdd - 추가 버튼 클릭 핸들러
 * @param {Function} props.onDelete - 삭제 버튼 클릭 핸들러
 * @param {Function} props.onRevert - 되돌리기 버튼 클릭 핸들러
 * @param {Function} props.onExcel - 엑셀 버튼 클릭 핸들러
 * @param {Function} props.onSave - 저장 버튼 클릭 핸들러
 * @param {boolean} props.saveLoading - 저장 버튼 로딩 상태
 * @param {Object} props.sx - 추가 스타일
 */
export default function CommonButton({
  showAdd = true,
  showDelete = true,
  showRevert = true,
  showExcel = true,
  showSave = false,
  onAdd,
  onDelete,
  onRevert,
  onExcel,
  onSave,
  saveLoading = false,
  sx,
}) {
  return (
    <Box sx={{ display: 'flex', gap: 0.5, ...sx }}>
      {showAdd && onAdd && (
        <Tooltip title="추가">
          <IconButton size="small" onClick={onAdd} sx={btnAdd}>
            <AddIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      {showDelete && onDelete && (
        <Tooltip title="삭제표시 / 해제 (I는 제거)">
          <IconButton size="small" onClick={onDelete} sx={btnDelete}>
            <RemoveIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      {showRevert && onRevert && (
        <Tooltip title="되돌리기">
          <IconButton size="small" onClick={onRevert} sx={btnRevert}>
            <ReplayIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      {showExcel && onExcel && (
        <Tooltip title="엑셀 다운로드 (CSV)">
          <IconButton size="small" onClick={onExcel} sx={btnExcel}>
            <FileDownloadOutlinedIcon fontSize="small" />
          </IconButton>
        </Tooltip>
      )}
      {showSave && onSave && (
        <Tooltip title="저장">
          <span>
            <Button
              size="small"
              variant="contained"
              onClick={onSave}
              disabled={saveLoading}
              startIcon={<SaveIcon fontSize="small" />}
              sx={btnSave}
            >
              Save
            </Button>
          </span>
        </Tooltip>
      )}
    </Box>
  );
}

/* ===== 버튼 스타일 (export) ===== */
export const btnAdd = {
  bgcolor: 'error.main',
  color: '#fff',
  borderRadius: 1,
  width: 25,
  height: 25,
  p: 0,
  minWidth: 0,
  '& .MuiSvgIcon-root': { fontSize: 14 },
  '&:hover': { bgcolor: 'error.dark' },
};

export const btnDelete = {
  bgcolor: 'error.main',
  color: '#fff',
  borderRadius: 1,
  width: 25,
  height: 25,
  p: 0,
  minWidth: 0,
  '& .MuiSvgIcon-root': { fontSize: 14 },
  '&:hover': { bgcolor: 'error.dark' },
};

export const btnRevert = {
  bgcolor: 'error.main',
  color: '#fff',
  borderRadius: 1,
  width: 25,
  height: 25,
  p: 0,
  minWidth: 0,
  '& .MuiSvgIcon-root': { fontSize: 14 },
  '&:hover': { bgcolor: 'error.dark' },
};

export const btnExcel = {
  bgcolor: '#fff',
  color: '#0f8b3d',
  border: '1.5px solid #0f8b3d',
  borderRadius: 1,
  width: 27,
  height: 27,
  p: 0,
  minWidth: 0,
  '& .MuiSvgIcon-root': { fontSize: 14 },
  '&:hover': { bgcolor: '#f5fff8' },
};

export const btnSave = {
  bgcolor: 'primary.main',
  color: '#fff',
  borderRadius: 1,
  height: 27,
  px: 1.5,
  minWidth: 70,
  fontSize: 12,
  fontWeight: 600,
  '& .MuiSvgIcon-root': { fontSize: 14 },
  '&:hover': { bgcolor: 'primary.dark' },
};