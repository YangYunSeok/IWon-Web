// GDataGrid.jsx — 상태(I/U/D) + (+/–/되돌리기/엑셀) + __rid 내부키 + 날짜표시 자동 포맷
import * as React from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { Box, IconButton, Tooltip, Typography } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import ReplayIcon from '@mui/icons-material/Replay';
import FileDownloadOutlinedIcon from '@mui/icons-material/FileDownloadOutlined';

/* ------- 타이틀 아이콘 ------- */
function SparkBadge({ size = 18, color = '#1976d2' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
      <defs>
        <linearGradient id="gbg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={color} />
          <stop offset="100%" stopColor="#42a5f5" />
        </linearGradient>
      </defs>
      <circle cx="12" cy="12" r="10" fill="url(#gbg)" />
      <path d="M12 4.5l1.4 3.4 3.6.3-2.8 2.3.9 3.5-3.1-1.9-3.1 1.9.9-3.5-2.8-2.3 3.6-.3L12 4.5z"
        fill="white" opacity="0.9" />
      <path d="M5 9c2-3.2 6.5-4.6 10-3.3" fill="none" stroke="white" strokeOpacity="0.3" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  );
}

const INTERNAL_KEY = '__rid';     // 내부 고정 키
const STATE_FIELD  = 'ROW_STATE'; // I/U/D 기본값

/* ===== 날짜 표시 유틸: Date | "YYYYMMDD" | "YYYY-MM-DD" -> "YYYY-MM-DD" ===== */
function ymdDashed(v) {
  if (v == null) return '';
  // Date 객체
  if (v instanceof Date && !isNaN(v.getTime())) {
    const y = v.getFullYear();
    const m = String(v.getMonth() + 1).padStart(2, '0');
    const d = String(v.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const s = String(v);
  // 이미 하이픈 들어있으면 숫자만 추출해 재조립
  const digits = s.replace(/\D/g, '');
  if (digits.length === 8) {
    return `${digits.slice(0,4)}-${digits.slice(4,6)}-${digits.slice(6,8)}`;
  }
  return s;
}

/* ===== 컴포넌트 ===== */
export default function GDataGrid({
  /* 타이틀 */
  title,
  showTitle = true,
  titleSx,
  titleIcon,
  titleIconSize = 18,
  titleIconColor,

  /* 레이아웃 */
  height = 520,

  /* 버튼(한 속성) — 배열/문자열/객체 지원 */
  Buttons, // [add, delete, revert, excel] | "1 1 1 0" | {add,delete,revert,excel}
  showTopButtons = true,       // 하위 호환
  showExcelButton = true,      // 하위 호환

  /* 상태 컬럼/편집 제어 */
  enableRowState = true,       // 상태컬럼 활성화 (기본 on)
  stateField = STATE_FIELD,    // 'I' | 'U' | 'D' 저장 필드명

  /** 새 행 템플릿(선택) — 제공하면 내부 기본값에 병합됩니다 */
  createNewRow,                // () => partialRow
  /** rows 변경 콜백(선택/컨트롤드) */
  onRowsChange,

  /* CSV */
  excelFileName = 'export.csv',

  /* 기존 DataGrid props */
  rows,
  columns = [],
  ...rest
}) {
  /* ----- 버튼 플래그 정규화 ----- */
  const btnFlags = React.useMemo(
    () => normalizeButtons(Buttons, showExcelButton),
    [Buttons, showExcelButton]
  );
  const flags = showTopButtons
    ? btnFlags
    : { add:false, delete:false, revert:false, excel:false };

  /* ----- __rid 생성/주입 유틸 ----- */
  const genRid = React.useCallback(
    (prefix='RID') => `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`,
    []
  );

  const ensureRid = React.useCallback((row, i=0, prefix='ROW') => {
    if (!row) return row;
    if (row[INTERNAL_KEY]) return row;
    return { ...row, [INTERNAL_KEY]: genRid(prefix) };
  }, [genRid]);

  const ensureRidArray = React.useCallback((arr, prefix='ROW') =>
    (Array.isArray(arr) ? arr : []).map((r, i) => ensureRid(r, i, prefix)), [ensureRid]);

  /* ----- 로컬 rows 상태 (언컨트롤드 fallback) + __rid 주입 ----- */
  const [localRaw, setLocalRaw] = React.useState(() => ensureRidArray(rows ?? [], 'INIT'));
  React.useEffect(() => { if (rows) setLocalRaw(ensureRidArray(rows, 'PROP')); }, [rows, ensureRidArray]);

  // 항상 __rid가 있는 배열만 DataGrid에 넣음
  const dataForGrid = React.useMemo(() => ensureRidArray(localRaw, 'GRID'), [localRaw, ensureRidArray]);

  const setRowsSafe = (updater) => {
    const next = typeof updater === 'function' ? updater(dataForGrid) : updater;
    const withRid = ensureRidArray(next, 'SET');
    if (onRowsChange) onRowsChange(withRid);
    else setLocalRaw(withRid);
  };

  /* ----- 선택 모델 저장(반드시 __rid 기준) ----- */
  const selectionRef = React.useRef([]);
  const toArray = (m) => Array.isArray(m) ? m : Array.from((m && m.ids) || []);
  const handleSelectionV6 = (m) => {
    selectionRef.current = toArray(m);        // m은 getRowId 결과(__rid) 집합
    rest.onRowSelectionModelChange?.(m);
  };
  const handleSelectionV5 = (m) => {
    selectionRef.current = toArray(m);
    rest.onSelectionModelChange?.(m);
  };

  /* ----- 새 행 추가 / 삭제표시 / 되돌리기 ----- */
  const clearSelection = () => {
    selectionRef.current = [];
    rest.onRowSelectionModelChange?.([]);
    rest.onSelectionModelChange?.([]);
  };

  const doAdd = () => {
    const base = { [INTERNAL_KEY]: genRid('NEW'), [stateField]: 'I' };
    const extra = (typeof createNewRow === 'function') ? (createNewRow() || {}) : {};
    const newRow = { ...base, ...extra, [INTERNAL_KEY]: base[INTERNAL_KEY], [stateField]: 'I' };
    setRowsSafe(prev => [newRow, ...prev]);
    clearSelection();
  };

  const doDeleteMark = () => {
    const ids = selectionRef.current; // __rid 배열
    if (!ids?.length) return;

    setRowsSafe(prev => prev.flatMap(r => {
      if (!ids.includes(r[INTERNAL_KEY])) return [r];
      const curState = r[stateField];
      if (curState === 'I') return [];           // 새로 추가된(I) 것은 완전 제거
      return [{ ...r, [stateField]: 'D' }];      // 그 외는 D로 표시
    }));
    clearSelection();
  };

  const doRevert = () => {
    const ids = selectionRef.current; // __rid 배열
    if (!ids?.length) return;
    setRowsSafe(prev => prev.map(r => {
      if (!ids.includes(r[INTERNAL_KEY])) return r;
      if (r[stateField] === 'I') return null; // I: 추가 취소 = 제거
      if (r[stateField] === 'U' || r[stateField] === 'D') {
        const { [stateField]: _, ...restRow } = r;
        return restRow; // 상태 되돌리기
      }
      return r;
    }).filter(Boolean));
    clearSelection();
  };

  /* ----- 편집 시 U 표시(processRowUpdate) + 즉시 rows 반영 ----- */
  const processRowUpdate = (incomingNewRow, oldRow) => {
    if (oldRow?.[stateField] === 'D') return oldRow; // D는 편집 불가

    let nextRow = incomingNewRow;
    if (enableRowState) {
      if (oldRow?.[stateField] !== 'I' && hasRowChanged(incomingNewRow, oldRow)) {
        nextRow = { ...incomingNewRow, [stateField]: 'U' };
      }
    }

    setRowsSafe(prev =>
      prev.map(r => (r[INTERNAL_KEY] === nextRow[INTERNAL_KEY] ? nextRow : r))
    );
    return nextRow;
  };

  /* ----- 상태 컬럼 구성 ----- */
  const statusCol = enableRowState ? [{
    field: stateField,
    headerName: '',
    width: 36,
    sortable: false,
    filterable: false,
    disableColumnMenu: true,
    align: 'center',
    headerAlign: 'center',
    renderCell: (p) => <StateBadge value={p.value} />,
  }] : [];

  /* ----- 컬럼 병합 + 날짜 표시 자동 포맷터 주입 ----- */
const mergedColumns = React.useMemo(() => {
    const hasStateField = columns.some(c => c.field === stateField);
    const base = hasStateField ? columns : [...statusCol, ...columns];

    const withFormatters = base.map(col => {
      const wantsYmd = col.displayAsYmd === true || col.type === 'date';

      if (!wantsYmd) return col;

      // 보기 모드에서 항상 YYYY-MM-DD로 그리기 (값이 'YYYYMMDD'거나 Date여도 안전)
      const renderCell =
        typeof col.renderCell === 'function'
          ? col.renderCell
          : (params) => {
              const raw =
                params?.value ??
                (params?.row ? params.row[col.field] : undefined);
              const text = ymdDashed(raw);
              return <span>{text}</span>;
            };

      // CSV/내부값 포맷을 위한 valueFormatter (있으면 존중)
      const valueFormatter =
        typeof col.valueFormatter === 'function'
          ? col.valueFormatter
          : ({ value, row }) => ymdDashed(value ?? row?.[col.field]);

      // ⚠️ MUI의 date 내부 파서와 충돌 피하려면 type은 문자열로 두는 게 안전
      const safeType = col.displayAsYmd ? 'string' : col.type;

      return { ...col, type: safeType, renderCell, valueFormatter };
    });

    return withFormatters;
  }, [columns, stateField]);

  /* ----- CSV Export (상태/내부키 제외) ----- */
  const exportToCSV = () => {
    const data = dataForGrid;
    if (!data?.length || !mergedColumns?.length) return;
    const visibleCols = mergedColumns.filter(c =>
      !!c.field && c.hide !== true && c.field !== stateField && c.field !== INTERNAL_KEY
    );

    const header = visibleCols.map(c => safeCSV(c.headerName ?? c.field)).join(',');
    const body = data.map(r => visibleCols.map(c => safeCSV(readValue(r, c))).join(','));
    const csv = ['\uFEFF' + header, ...body].join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = excelFileName.endsWith('.csv') ? excelFileName : `${excelFileName}.csv`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  };

  /* ----- 버튼 핸들러: 외부 콜백 우선, 없으면 기본 동작 ----- */
  const onAdd    = rest.onAddClick    || doAdd;
  const onDelete = rest.onDeleteClick || doDeleteMark;
  const onRevert = rest.onRevertClick || doRevert;

  /* ----- 렌더 ----- */
  const showTopBar =
    (showTitle && !!title) ||
    (flags.add || flags.delete || flags.revert || flags.excel);

  return (
    <Box sx={{ width:'100%', height:Number.isFinite(height)?height:520, display:'flex', flexDirection:'column' }}>
      {showTopBar && (
        <Box sx={{ display:'flex', alignItems:'center', justifyContent:'space-between', gap:1, p:1, pt:0 }}>
          {showTitle && !!title ? (
            <Box sx={{ display:'flex', alignItems:'center', gap:1 }}>
              <Box sx={{ display:'inline-flex', alignItems:'center' }}>
                {titleIcon ? titleIcon : <SparkBadge size={titleIconSize} color={titleIconColor || '#1976d2'} />}
              </Box>
              <Typography variant="subtitle1" sx={{ fontWeight:700, color:'text.primary', ...titleSx }}>
                {title}
              </Typography>
            </Box>
          ) : <span />}

          <Box sx={{ display:'flex', gap:0.5 }}>
            {flags.add && (
              <Tooltip title="추가">
                <IconButton size="small" onClick={onAdd} sx={btnSxRed}>
                  <AddIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            {flags.delete && (
              <Tooltip title="삭제표시 / 해제 (I는 제거)">
                <IconButton size="small" onClick={onDelete} sx={btnSxRed}>
                  <RemoveIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            {flags.revert && (
              <Tooltip title="되돌리기">
                <IconButton size="small" onClick={onRevert} sx={btnSxRed}>
                  <ReplayIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
            {flags.excel && (
              <Tooltip title="엑셀 다운로드 (CSV)">
                <IconButton size="small" onClick={exportToCSV} sx={btnSxExcel}>
                  <FileDownloadOutlinedIcon fontSize="small" />
                </IconButton>
              </Tooltip>
            )}
          </Box>
        </Box>
      )}

      <Box sx={{ flex:1, minHeight:0 }}>
        <DataGrid
          {...rest}
          /** ※ 외부 getRowId를 무시하고 내부 __rid를 강제 사용 */
          getRowId={(row) => row[INTERNAL_KEY]}
          rows={dataForGrid}
          columns={mergedColumns}
          autoHeight={false}
          processRowUpdate={processRowUpdate}
          isCellEditable={(params) => params.row?.[stateField] !== 'D'} // D 행 편집 금지
          getRowClassName={(params) => rowClassName(params.row?.[stateField])}
          onRowSelectionModelChange={handleSelectionV6}
          onSelectionModelChange={handleSelectionV5}
          experimentalFeatures={{ newEditingApi: true }}
        />
      </Box>

      {/* 상태별 스타일 */}
      <style>{`
        .row-state-I { background: #f1fff4; }    /* 연녹 */
        .row-state-U { background: #fff9ec; }    /* 연주황 */
        .row-state-D { background: #fff0f0; }    /* 연분홍 + strike */
        .row-state-D .MuiDataGrid-cell { text-decoration: line-through; color: #b71c1c; }
      `}</style>
    </Box>
  );
}

/* ===== 상태 뱃지 표시 ===== */
function StateBadge({ value }) {
  if (value === 'I') return <BadgeDot bg="#2e7d32" label="I" title="Inserted" />;
  if (value === 'U') return <BadgeDot bg="#ef6c00" label="U" title="Updated" />;
  if (value === 'D') return <BadgeDot bg="#c62828" label="D" title="Deleted" />;
  return null;
}
function BadgeDot({ bg, label, title }) {
  return (
    <span title={title} style={{
      display:'inline-flex', alignItems:'center', justifyContent:'center',
      width:20, height:20, borderRadius:6, background:bg, color:'#fff',
      fontSize:11, fontWeight:700, lineHeight:'20px'
    }}>{label}</span>
  );
}

/* ===== 유틸 ===== */
function hasRowChanged(a, b) {
  const omit = new Set([ STATE_FIELD, INTERNAL_KEY ]);
  const ka = Object.keys(a || {}).filter(k => !omit.has(k));
  const kb = Object.keys(b || {}).filter(k => !omit.has(k));
  if (ka.length !== kb.length) return true;
  for (const k of ka) {
    if (a[k] instanceof Date && b[k] instanceof Date) {
      if (a[k].getTime() !== b[k].getTime()) return true;
    } else if (a[k] !== b[k]) return true;
  }
  return false;
}
function safeCSV(v) {
  if (v === null || v === undefined) return '';
  let s = String(v);
  if (/^[=+\-@]/.test(s)) s = "'" + s;
  if (/[",\r\n]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}
function readValue(row, col) {
  if (typeof col.valueGetter === 'function') {
    try { return col.valueGetter({ row, field: col.field, value: row[col.field] }); } catch {}
  }
  const val = row[col.field];
  if (typeof col.valueFormatter === 'function') {
    try { return col.valueFormatter({ value: val, row, field: col.field }); } catch {}
  }
  return val;
}
function normalizeButtons(Buttons, legacyExcelDefault) {
  const defaults = { add:true, delete:true, revert:true, excel:legacyExcelDefault ?? true };
  if (Buttons == null) return defaults;
  if (Array.isArray(Buttons)) {
    const [a,d,r,e] = Buttons;
    return { add:a ?? true, delete:d ?? true, revert:r ?? true, excel:e ?? (legacyExcelDefault ?? true) };
  }
  if (typeof Buttons === 'string') {
    const [a,d,r,e] = Buttons.trim().split(/\s+/).map(t => /^(true|1|y|yes)$/i.test(t));
    return { add:a ?? true, delete:d ?? true, revert:r ?? true, excel:e ?? (legacyExcelDefault ?? true) };
  }
  if (typeof Buttons === 'object') {
    return {
      add: Buttons.add ?? true,
      delete: Buttons.delete ?? true,
      revert: Buttons.revert ?? true,
      excel: Buttons.excel ?? (legacyExcelDefault ?? true)
    };
  }
  return defaults;
}
function rowClassName(state) {
  if (state === 'I') return 'row-state-I';
  if (state === 'U') return 'row-state-U';
  if (state === 'D') return 'row-state-D';
  return '';
}

/* ===== 버튼 스타일 ===== */
const btnSxRed = {
  bgcolor: 'error.main',
  color: '#fff',
  borderRadius: 1,
  width: 25,
  height: 25,
  p: 0,
  minWidth: 0,
  '& .MuiSvgIcon-root': { fontSize: 14 },
  '&:hover': { bgcolor: 'error.dark' },
};
const btnSxExcel = {
  bgcolor: '#fff',
  color: '#0f8b3d',
  border: '1.5px solid #0f8b3d',
  borderRadius: 1,
  width: 27,
  height: 27,
  p: 0,
  minWidth: 0,
  '& .MuiSvgIcon-root': { fontSize: 14 },
  '&:hover': { bgcolor: '#f5fff8' },
};
