import { useState } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Typography,
} from "@mui/material";
import PushHistoryFilter from "./PushHistoryFilter";
import PushHistoryTable from "./PushHistoryTable";

export default function PushHistoryDialog({ open, onClose }) {
  const [filters, setFilters] = useState({
    startDate: "",
    endDate: "",
    includeMsg: true,
  });
  const [data, setData] = useState([]);

  const handleSearch = async () => {
    // 👉 실제 백엔드 API 호출 자리 (filters 사용)
    // const res = await fetch('/api/push/history?start=...&end=...&includeMsg=...');
    // const json = await res.json();
    // setData(json.rows);

    // 데모 데이터
    setData([
      { id: 1, sender: "시스템", msg: "테스트 푸시", time: "2025-10-27 09:30" },
    ]);
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
      <DialogTitle>
        <Typography variant="h6">PUSH 내역 조회</Typography>
      </DialogTitle>

      {/* 라벨 위로 떠오를 때 클리핑 방지 */}
      <DialogContent sx={{ overflow: "visible", pt: 2 }}>
        <Box sx={{ mb: 2 }}>
          <PushHistoryFilter
            filters={filters}
            setFilters={setFilters}
            onSearch={handleSearch}
          />
        </Box>
        <PushHistoryTable rows={data} />
      </DialogContent>

      <DialogActions>
        <Button onClick={onClose} variant="outlined">
          닫기
        </Button>
      </DialogActions>
    </Dialog>
  );
}
