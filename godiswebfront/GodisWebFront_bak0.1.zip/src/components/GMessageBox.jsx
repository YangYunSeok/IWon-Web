// src/components/GMessageBox.jsx
import React from 'react';
import ReactDOM from 'react-dom';
import { createRoot } from 'react-dom/client';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Stack, Typography, Box
} from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import WarningAmberOutlinedIcon from '@mui/icons-material/WarningAmberOutlined';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';

/* ----------------- 모듈 전역 저장소 ----------------- */
let MESSAGE_MAP = {};                 // { [code]: "문구 {0}" }
let MESSAGE_RESOLVER = null;          // async (code) => string

/** 서버에서 List<Map<String,Object>> 형태로 받은 데이터를 바로 주입 */
export function primeMessageMap(list, { codeKey = 'MSG_CD', textKey = 'MSG_NM' } = {}) {
  if (!Array.isArray(list)) return;
  const next = {};
  for (const row of list) {
    const code = row?.[codeKey];
    const text = row?.[textKey];
    if (code && typeof text === 'string') next[String(code)] = text;
  }
  MESSAGE_MAP = next;
}

/** 이미 key-value 형태면 그대로 넣기 */
export function setMessageMap(mapObj = {}) {
  MESSAGE_MAP = { ...mapObj };
}

/** 원한다면 원격 조회용 리졸버도 플러그인 */
export function setMessageResolver(fn) {
  MESSAGE_RESOLVER = typeof fn === 'function' ? fn : null;
}

/* ----------------- 유틸 ----------------- */
function fmt(text, args = []) {
  if (!text) return '';
  let out = String(text);
  args.forEach((v, i) => { out = out.replace(new RegExp(`\\{${i}\\}`, 'g'), v ?? ''); });
  return out;
}

async function resolveMessage({ message, code, args, messageMap, messageResolver }) {
  if (message) return fmt(message, args);

  // 우선순위: props.messageResolver > props.messageMap > 전역 MESSAGE_RESOLVER > 전역 MESSAGE_MAP
  if (code) {
    if (typeof messageResolver === 'function') {
      const t = await messageResolver(code);
      return fmt(t ?? code, args);
    }
    if (messageMap && messageMap[code]) {
      return fmt(messageMap[code], args);
    }
    if (typeof MESSAGE_RESOLVER === 'function') {
      const t = await MESSAGE_RESOLVER(code);
      return fmt(t ?? code, args);
    }
    if (MESSAGE_MAP[code]) {
      return fmt(MESSAGE_MAP[code], args);
    }
    return code; // fallback
  }
  return '';
}

const PRESETS = {
  Ok: ['ok'],
  OkCancel: ['ok', 'cancel'],
  YesNo: ['yes', 'no'],
  YesNoCancel: ['yes', 'no', 'cancel'],
};

function labelOf(key, labels) {
  const defaults = { ok: 'OK', cancel: 'Cancel', yes: 'Yes', no: 'No' };
  return (labels && labels[key]) || defaults[key] || key;
}

function IconByType({ type = 'info' }) {
  const sx = { fontSize: 28 };
  if (type === 'warning') return <WarningAmberOutlinedIcon color="warning" sx={sx} />;
  if (type === 'error')   return <ErrorOutlineOutlinedIcon color="error" sx={sx} />;
  if (type === 'success') return <CheckCircleOutlineOutlinedIcon color="success" sx={sx} />;
  return <InfoOutlinedIcon color="info" sx={sx} />;
}

/* ----------------- 컴포넌트 ----------------- */
export default function GMessageBox(props) {
  const {
    open,
    onClose,
    title,
    message,
    code,
    args,
    messageMap,
    messageResolver,
    buttons = 'Ok',
    buttonLabels,
    type = 'info',
    maxWidth = 'xs',
    keepMounted = true,
  } = props;

  const [text, setText] = React.useState('');

  React.useEffect(() => {
    let alive = true;
    (async () => {
      const t = await resolveMessage({ message, code, args, messageMap, messageResolver });
      if (alive) setText(t);
    })();
    return () => { alive = false; };
  }, [open, message, code, JSON.stringify(args)]);

  const btnKeys = Array.isArray(buttons) ? buttons : (PRESETS[buttons] || PRESETS.Ok);

  const handleKeyDown = (e) => {
    if (!open) return;
    if (e.key === 'Enter') {
      const prefer = btnKeys.includes('ok') ? 'ok' : btnKeys[0];
      onClose?.(prefer);
    } else if (e.key === 'Escape') {
      const esc = btnKeys.includes('cancel') ? 'cancel' : btnKeys.includes('no') ? 'no' : null;
      if (esc) onClose?.(esc);
    }
  };

  return (
    <Dialog
      open={open}
      onClose={() => onClose?.('cancel')}
      onKeyDown={handleKeyDown}
      maxWidth={maxWidth}
      fullWidth
      keepMounted={keepMounted}
    >
      <DialogTitle sx={{ py: 1.25 }}>
        <Stack direction="row" spacing={1.25} alignItems="center">
          <IconByType type={type} />
          <Typography variant="subtitle1" fontWeight={700}>
            {title || (code ? code : type.toUpperCase())}
          </Typography>
        </Stack>
      </DialogTitle>

      <DialogContent dividers sx={{ pt: 1.5, pb: 2 }}>
        <Box sx={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: 14.5 }}>
          {text}
        </Box>
      </DialogContent>

      <DialogActions
        sx={{
          px: 2, py: 1,
          display: 'flex',
          justifyContent: 'center',   // ✅ 가운데 정렬
          gap: 1.5,                    // (선택) 버튼 간격
        }}
      >
        {btnKeys.map((k) => (
          <Button
            key={k}
            variant={k === 'ok' || k === 'yes' ? 'contained' : 'outlined'}
            color={k === 'ok' || k === 'yes' ? (props.type === 'error' ? 'error' : 'primary') : 'inherit'}
            onClick={() => onClose?.(k)}
            autoFocus={k === btnKeys[0]}
            sx={{ minWidth: 76 }}
          >
            {labelOf(k, buttonLabels)}
          </Button>
        ))}
      </DialogActions>
    </Dialog>
  );
}

/* ----------------- 전역 Show API (원하는 호출 형태) ----------------- */
/** GMessageBox.Show('MGE00890','YesNo','warning',['TS360']) */
function showMessageBox(code, buttons = 'Ok', type = 'info', args = [], extra = {}) {
  // 컨테이너 준비
  let container = document.getElementById('__gmsg_container__');
  if (!container) {
    container = document.createElement('div');
    container.id = '__gmsg_container__';
    document.body.appendChild(container);
  }

  const root = createRoot(container);

  return new Promise((resolve) => {
    const handleClose = (result) => {
      resolve(result);
      root.unmount();
      // container.remove();  // 여러 번 쓰려면 제거하지 말고 재사용해도 됨
    };

    root.render(
      <GMessageBox
        open
        onClose={handleClose}
        code={code}
        args={args}
        buttons={buttons}
        type={type}
        {...extra}
      />
    );
  });
}

// default export에 정적 메서드로 붙여서 GMessageBox.Show(...) 형태 지원
GMessageBox.Show = showMessageBox;
