import React, {
  useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState, forwardRef
} from 'react';
import { Tree, Button, Space, Input, message } from 'antd';
import {
  PlusOutlined, PlusSquareOutlined, MinusOutlined, UndoOutlined,
  EditOutlined, MinusCircleOutlined, PlusCircleOutlined, FolderOpenOutlined
} from '@ant-design/icons';

/** 트리 -> 리스트 평탄화 */
const flatten = (nodes = [], keyField = 'key', childrenField = 'children', out = []) => {
  for (const n of nodes || []) {
    out.push(n);
    if (n[childrenField]?.length) flatten(n[childrenField], keyField, childrenField, out);
  }
  return out;
};

/** CUD payload 생성 (recordState 유지) */
export const buildTreeCudPayload = (nodes = [], flagField = 'recordState', keyField = 'key', childrenField = 'children') => {
  const all = flatten(nodes, keyField, childrenField);
  const flag = (r) => String(r?.[flagField] ?? '').toUpperCase();
  const clone = (r) => ({ ...r }); // recordState 포함
  return {
    inserts: all.filter(r => flag(r) === 'I').map(clone),
    updates: all.filter(r => flag(r) === 'U').map(clone),
    deletes: all.filter(r => flag(r) === 'D').map(clone),
  };
};

const EditableTree = forwardRef(function EditableTree({
  treeData,
  onDataChange,
  keyField = 'key',
  titleField = 'title',
  childrenField = 'children',
  flagField = 'recordState',
  mirrorFlagField = null,
  height = 320,
  loading = false,
  onSelectKey,              // (key) => void
}, ref) {

  /** ====== 상태 ====== */
  const [data, setData] = useState(() => Array.isArray(treeData) ? treeData.map(n => ({ ...n })) : []);
  const [selectedKeys, setSelectedKeys] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState([]);
  const [editingKey, setEditingKey] = useState(null);
  const isLocalRef = useRef(false);
  const origRef = useRef([]);

  /** ====== 동기화 ====== */
  useEffect(() => {
    if (isLocalRef.current) { isLocalRef.current = false; return; }
    const clone = (nodes = []) => nodes.map(n => ({
      ...n,
      [childrenField]: n[childrenField]?.length ? clone(n[childrenField]) : [],
    }));
    const incoming = clone(treeData || []);
    setData(incoming);
    origRef.current = clone(incoming);
  }, [treeData, childrenField]);

  useEffect(() => {
    if (onDataChange && isLocalRef.current) {
      onDataChange(data);
      isLocalRef.current = false;
    }
  }, [data, onDataChange]);

  /** ====== 유틸 ====== */
  const getFlag = useCallback((node) => String(node?.[flagField] ?? '').toUpperCase(), [flagField]);
  const setFlag = useCallback((node, v) => {
    const next = { ...node, [flagField]: v };
    if (mirrorFlagField) next[mirrorFlagField] = v;
    return next;
  }, [flagField, mirrorFlagField]);

  const mapTree = useCallback((nodes, mapper) => {
    return (nodes || []).map(n => {
      const mapped = mapper(n);
      const kids = mapped[childrenField]?.length ? mapTree(mapped[childrenField], mapper) : [];
      if (kids !== mapped[childrenField]) mapped[childrenField] = kids;
      return mapped;
    });
  }, [childrenField]);

  const updateNodeByKey = useCallback((nodes, key, updater) => {
    return (nodes || []).map(n => {
      if (String(n[keyField]) === String(key)) {
        return updater(n);
      }
      if (n[childrenField]?.length) {
        const ch = updateNodeByKey(n[childrenField], key, updater);
        if (ch !== n[childrenField]) return { ...n, [childrenField]: ch };
      }
      return n;
    });
  }, [keyField, childrenField]);

  const findNode = useCallback((nodes, key) => {
    for (const n of nodes || []) {
      if (String(n[keyField]) === String(key)) return n;
      const f = findNode(n[childrenField], key);
      if (f) return f;
    }
    return null;
  }, [keyField, childrenField]);

  /** ====== 조작 ====== */
  const handleAddRoot = () => {
    isLocalRef.current = true;
    const k = `NEW_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const newNode = setFlag({ [keyField]: k, [titleField]: 'New Menu', [childrenField]: [] }, 'I');
    setData(prev => [...prev, newNode]);
    setExpandedKeys(prev => Array.from(new Set([...prev, k])));
    setSelectedKeys([k]);
    setEditingKey(k);
  };

  const handleAddChild = () => {
    const pKey = selectedKeys[0];
    if (!pKey) { message.info('부모 메뉴를 선택하세요.'); return; }
    isLocalRef.current = true;
    const k = `NEW_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const child = setFlag({ [keyField]: k, [titleField]: 'New Child', [childrenField]: [] }, 'I');
    setData(prev => updateNodeByKey(prev, pKey, (node) => {
      const kids = (node[childrenField] || []).concat(child);
      return { ...node, [childrenField]: kids };
    }));
    setExpandedKeys(prev => Array.from(new Set([...prev, pKey])));
    setSelectedKeys([k]);
    setEditingKey(k);
  };

  const markDeleteRecursive = (node) => {
    const f = getFlag(node);
    if (f === 'I') return null; // 신규는 제거
    const kids = (node[childrenField] || []).map(markDeleteRecursive).filter(Boolean);
    return setFlag({ ...node, [childrenField]: kids }, 'D');
  };

  const handleDelete = () => {
    if (selectedKeys.length === 0) return;
    isLocalRef.current = true;
    setData(prev => {
      const walk = (nodes) => {
        const next = [];
        for (const n of nodes || []) {
          if (selectedKeys.includes(n[keyField])) {
            const res = markDeleteRecursive(n);
            if (res) next.push(res);
          } else {
            const kids = n[childrenField]?.length ? walk(n[childrenField]) : [];
            next.push(kids !== n[childrenField] ? { ...n, [childrenField]: kids } : n);
          }
        }
        return next;
      };
      return walk(prev);
    });
    setSelectedKeys([]);
  };

  const handleUndo = () => {
    if (selectedKeys.length === 0) return;
    isLocalRef.current = true;
    setData(prev => {
      const origMap = new Map(flatten(origRef.current, keyField, childrenField).map(n => [String(n[keyField]), { ...n }]));
      const walk = (nodes) => {
        const next = [];
        for (const n of nodes || []) {
          const k = String(n[keyField]);
          if (selectedKeys.includes(k)) {
            const orig = origMap.get(k);
            if (orig) next.push(orig); // 복원
            // orig 없으면 신규였던 것 → 제거 (push 안함)
          } else {
            const kids = n[childrenField]?.length ? walk(n[childrenField]) : [];
            next.push(kids !== n[childrenField] ? { ...n, [childrenField]: kids } : n);
          }
        }
        return next;
      };
      return walk(prev);
    });
    setSelectedKeys([]);
  };

  const commitTitle = (key, value) => {
    isLocalRef.current = true;
    setData(prev => updateNodeByKey(prev, key, (node) => {
      if (node[titleField] === value) return node;
      const curr = getFlag(node);
      const nextFlag = curr === 'I' ? 'I' : 'U';
      return setFlag({ ...node, [titleField]: value }, nextFlag);
    }));
    setEditingKey(null);
  };

  /** ====== 렌더링 ====== */
  const totalCount = useMemo(() => flatten(data, keyField, childrenField).length, [data, keyField, childrenField]);

  const allKeys = useMemo(() => flatten(data, keyField, childrenField).map(n => n[keyField]), [data, keyField, childrenField]);

  const renderTitle = (node) => {
    const k = node[keyField];
    const f = getFlag(node);
    const icon = f === 'I' ? <PlusCircleOutlined style={{ color: '#1677ff', marginRight: 6 }} />
      : f === 'U' ? <EditOutlined style={{ color: '#fa8c16', marginRight: 6 }} />
      : f === 'D' ? <MinusCircleOutlined style={{ color: '#ff4d4f', marginRight: 6 }} />
      : <FolderOpenOutlined style={{ color: '#8c8c8c', marginRight: 6 }} />;

    if (editingKey === k) {
      return (
        <Input
          size="small"
          autoFocus
          defaultValue={node[titleField]}
          onBlur={(e) => commitTitle(k, e.target.value)}
          onPressEnter={(e) => commitTitle(k, e.currentTarget.value)}
          onKeyDown={(e) => { if (e.key === 'Escape') setEditingKey(null); }}
          style={{ width: 200 }}
        />
      );
    }
    return (
      <span onDoubleClick={() => setEditingKey(k)} title="더블클릭하여 이름 편집">
        {icon}{node[titleField]}
      </span>
    );
  };

  /** ====== ref API ====== */
  useImperativeHandle(ref, () => ({
    getData: () => data,
    getCudPayload: () => buildTreeCudPayload(data, flagField, keyField, childrenField),
    getChangedNodes: () => flatten(data, keyField, childrenField).filter(n => ['I','U','D'].includes(getFlag(n))),
    expandAll: () => setExpandedKeys(allKeys),
    collapseAll: () => setExpandedKeys([]),
  }), [data, flagField, keyField, childrenField, allKeys, getFlag]);

  return (
    <div>
      <div style={{ display: 'flex', marginBottom: 6 }}>
        <div style={{ width: 100 }}>Total ({totalCount})</div>
        <div style={{ flex: 1, textAlign: 'right' }}>
          <Space size={6}>
            <Button size="small" icon={<PlusOutlined />} onClick={handleAddRoot} />
            <Button size="small" icon={<PlusSquareOutlined />} onClick={handleAddChild} disabled={!selectedKeys.length} />
            <Button size="small" icon={<MinusOutlined />} onClick={handleDelete} disabled={!selectedKeys.length} />
            <Button size="small" icon={<UndoOutlined />} onClick={handleUndo} disabled={!selectedKeys.length} />
            <Button size="small" onClick={() => setExpandedKeys(allKeys)}>Expand</Button>
            <Button size="small" onClick={() => setExpandedKeys([])}>Collapse</Button>
          </Space>
        </div>
      </div>

      <div style={{ height, overflow: 'auto', opacity: loading ? 0.6 : 1 }}>
        <Tree
          showLine
          treeData={mapTree(data, (n) => ({ ...n, title: renderTitle(n), key: n[keyField] }))}
          selectedKeys={selectedKeys}
          expandedKeys={expandedKeys}
          onExpand={setExpandedKeys}
          onSelect={(keys) => {
            setSelectedKeys(keys);
            if (keys?.length && onSelectKey) onSelectKey(keys[0]);
          }}
          height={height}
        />
      </div>
    </div>
  );
});

export default EditableTree;
