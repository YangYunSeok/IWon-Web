import React, { useMemo } from 'react';
export default function MenuTree({ data=[], onClick, filter='' }) {
  const filtered = useMemo(() => {
    const q = filter.trim().toLowerCase();
    if (!q) return data;
    return data.filter(n => {
      const id = String(n.menuId ?? n.menuCd ?? n.id ?? '').toLowerCase();
      const name = String(n.menuNm ?? n.name ?? '').toLowerCase();
      return id.includes(q) || name.includes(q);
    });
  }, [data, filter]);
  return (
    <div className="tree">
      {filtered.map(n => {
        const key = String(n.menuId ?? n.menuCd ?? n.id ?? '');
        const name = String(n.menuNm ?? n.name ?? '');
        return (
          <div key={key} className="tree-item" onClick={() => onClick?.(n)} title={`${key} ${name}`}>
            <span className="code">{key}</span>{name}
          </div>
        );
      })}
      {filtered.length === 0 && <div style={{opacity:.6}}>검색 결과가 없습니다.</div>}
    </div>
  );
}
