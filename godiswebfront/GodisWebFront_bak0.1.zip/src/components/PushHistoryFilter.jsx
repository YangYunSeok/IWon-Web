import { Box, FormControlLabel, Checkbox, Button } from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

export default function PushHistoryFilter({ filters, setFilters, onSearch }) {
  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: { xs: "1fr", sm: "180px 180px auto" },
          columnGap: 2,
          rowGap: 1,
          alignItems: "center",
        }}
      >
        {/* 시작일 */}
        <DatePicker
          label="시작일"
          format="YYYY-MM-DD"
          value={filters.startDate ? dayjs(filters.startDate) : null}
          onChange={(value) =>
            setFilters((f) => ({
              ...f,
              startDate: value ? value.format("YYYY-MM-DD") : "",
            }))
          }
          slotProps={{
            textField: {
              size: "small",
              label: "시작일",
              variant: "outlined",
              sx: { width: 180 },
              InputLabelProps: { shrink: true }, // 라벨 안정 표시
            },
          }}
        />

        {/* 종료일 */}
        <DatePicker
          label="종료일"
          format="YYYY-MM-DD"
          value={filters.endDate ? dayjs(filters.endDate) : null}
          onChange={(value) =>
            setFilters((f) => ({
              ...f,
              endDate: value ? value.format("YYYY-MM-DD") : "",
            }))
          }
          slotProps={{
            textField: {
              size: "small",
              label: "종료일",
              variant: "outlined",
              sx: { width: 180 },
              InputLabelProps: { shrink: true },
            },
          }}
        />

        {/* 검색 버튼 (1행 3열) */}
        <Box
          sx={{
            gridColumn: { xs: "1 / -1", sm: "3" },
            gridRow: "1",
            justifySelf: "start",
          }}
        >
          <Button variant="contained" onClick={onSearch} sx={{ height: 36 }}>
            검색
          </Button>
        </Box>

        {/* 체크박스 (버튼 아래: 2행 3열) */}
        <Box
          sx={{
            gridColumn: { xs: "1 / -1", sm: "3" },
            gridRow: "2",
            justifySelf: "start",
          }}
        >
          <FormControlLabel
            control={
              <Checkbox
                size="small"
                checked={filters.includeMsg}
                onChange={(e) =>
                  setFilters((f) => ({ ...f, includeMsg: e.target.checked }))
                }
              />
            }
            label="수신메시지 포함 Total(0)"
            sx={{
              my: 0,
              "& .MuiTypography-root": { fontSize: 12 },
            }}
          />
        </Box>
      </Box>
    </LocalizationProvider>
  );
}
