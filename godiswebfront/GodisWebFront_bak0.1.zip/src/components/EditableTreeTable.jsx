import React, { useMemo, useState, useCallback } from "react";
import { Table, Checkbox, Input, Select, DatePicker, InputNumber, Tooltip } from "antd";

/**
 * EditableTreeTable
 * Ant Design Table custom cell 컴포넌트는 "ReactNode"를 반환해야 합니다.
 * (이전 버전에서 `{children, props}` 객체를 반환하여 발생한 에러를 수정)
 */
export default function EditableTreeTable({
  rowKey = "key",
  columns = [],
  value = [],
  onChange,
  readOnly = false,
  sticky = true,
  scroll = { x: 'max-content', y: 420 },
}) {
  const [internal, setInternal] = useState(value);
  const data = value ?? internal;

  const setData = useCallback((next) => {
    setInternal(next);
    onChange && onChange(next);
  }, [onChange]);

  const findAndUpdate = useCallback((nodes, matchKey, updater) => {
    return nodes.map(n => {
      if (String(n[rowKey]) === String(matchKey)) {
        return updater({ ...n });
      }
      if (Array.isArray(n.children) && n.children.length) {
        return { ...n, children: findAndUpdate(n.children, matchKey, updater) };
      }
      return n;
    });
  }, [rowKey]);

  const updateNode = useCallback((key, updater) => {
    setData(findAndUpdate(data, key, updater));
  }, [data, setData, findAndUpdate]);

  const cascadeDown = useCallback((node, field, checked) => {
    const next = { ...node, [field]: checked };
    if (Array.isArray(node.children) && node.children.length) {
      next.children = node.children.map(ch => cascadeDown(ch, field, checked));
    }
    return next;
  }, []);

  // columns -> onCell 주입
  const antColumns = useMemo(() => {
    return columns.map(col => {
      const { editor, tooltip } = col;
      return {
        ...col,
        onCell: (record) => ({
          record,
          dataIndex: col.dataIndex,
          editor,
          tooltip,
          readOnly,
          updateNode,
          rowKey,
        }),
      };
    });
  }, [columns, readOnly, updateNode, rowKey]);

  // 실제 <td>를 반환해야 함
  const EditableCell = (props) => {
    const { children, record, dataIndex, editor, tooltip, readOnly, updateNode, rowKey, ...restProps } = props;
    const cellValue = record?.[dataIndex];

    // 편집 불가 또는 에디터 미지정 → 원래 children 렌더
    if (!editor || readOnly) {
      return <td {...restProps}>{children}</td>;
    }

    const disabled = typeof editor.disabled === "function" ? !!editor.disabled(record) : !!editor.disabled;
    const onValueChange = (nextValue) => {
      updateNode(record[rowKey], (node) => {
        let updated = { ...node, [dataIndex]: nextValue };
        if (editor.type === "checkbox" && editor.cascade) {
          const cfg = typeof editor.cascade === "object" ? editor.cascade : { down: true, up: false };
          if (cfg.down) updated = cascadeDown(updated, dataIndex, !!nextValue);
        }
        return updated;
      });
    };

    let inputNode = null;
    switch (editor.type) {
      case "text":
        inputNode = (
          <Input
            size="small"
            value={cellValue ?? ""}
            disabled={disabled}
            onChange={(e) => onValueChange(e.target.value)}
          />
        );
        break;
      case "number":
        inputNode = (
          <InputNumber
            size="small"
            value={cellValue}
            disabled={disabled}
            onChange={(v) => onValueChange(v)}
            style={{ width: "100%" }}
          />
        );
        break;
      case "select": {
        const opts = typeof editor.options === "function" ? editor.options(record) : (editor.options || []);
        inputNode = (
          <Select
            size="small"
            value={cellValue}
            onChange={onValueChange}
            disabled={disabled}
            options={opts}
            style={{ width: "100%" }}
          />
        );
        break;
      }
      case "date":
        inputNode = (
          <DatePicker
            size="small"
            value={cellValue}
            onChange={onValueChange}
            disabled={disabled}
            style={{ width: "100%" }}
          />
        );
        break;
      case "checkbox":
        inputNode = (
          <div style={{ textAlign: "center" }}>
            <Checkbox
              checked={!!cellValue}
              onChange={(e) => onValueChange(e.target.checked)}
              disabled={disabled}
            />
          </div>
        );
        break;
      case "custom":
        inputNode = editor.render ? editor.render(cellValue, record, onValueChange) : (cellValue ?? "");
        break;
      default:
        inputNode = (cellValue ?? "");
    }

    const maybeWrapped = (tooltip || editor.tooltip)
      ? <Tooltip title={typeof (tooltip || editor.tooltip) === 'function' ? (tooltip || editor.tooltip)(record) : (tooltip || editor.tooltip)}>{inputNode}</Tooltip>
      : inputNode;

    return <td {...restProps}>{maybeWrapped}</td>;
  };

  return (
    <Table
      rowKey={rowKey}
      columns={antColumns}
      dataSource={data}
      pagination={false}
      size="small"
      components={{ body: { cell: EditableCell } }}
      expandable={{ defaultExpandAllRows: true }}
      sticky={sticky}
      scroll={scroll}
      bordered
    />
  );
}