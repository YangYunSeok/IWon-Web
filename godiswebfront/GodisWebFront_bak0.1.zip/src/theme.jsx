// src/theme.jsx
import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: '#1976d2' },
    secondary: { main: '#9c27b0' },
  },
  typography: {
    fontFamily: [
      'Noto Sans KR','Roboto','Apple SD Gothic Neo',
      'Segoe UI','Helvetica','Arial','sans-serif'
    ].join(','),
  },
  components: {
    MuiButton: {
      defaultProps: { disableElevation: true },
    },
    MuiDataGrid: {
      styleOverrides: {
        // ✅ DataGrid는 root에서 내부 클래스 선택자가 가장 확실합니다.
        root: {
          '& .MuiDataGrid-columnHeaders': {
            backgroundColor: '#f4f6fb',
            color: '#1976d2',        // ✅ 오타 수정(해시 하나)
          },
          '& .MuiDataGrid-columnHeaderTitle': {
            fontWeight: 700,
          },
          '& .MuiDataGrid-columnSeparator': {
            display: 'none',
          },
        },
      },
    },
  },
});

export default theme;