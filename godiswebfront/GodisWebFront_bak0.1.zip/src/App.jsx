import React, { useState, useEffect, useMemo } from 'react';
import { Layout, Menu, Tree, Tabs, Select, Tooltip, Space, message, Card, Switch } from 'antd';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';

import '@/css/styles.css';
import '@/css/App.css';

// MUI Theme imports
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

import PageHost from '@/pages/PageHost.jsx';
import Placeholder from '@/pages/Placeholder.jsx';
import { usePerm } from '@/authz/PermissionStore.jsx';
// 서버호출
import { http } from '@/libs/TaskHttp';

// Import icons for user actions and menu items
import {
  LogoutOutlined,
  UserOutlined,
  LockOutlined,
  HomeOutlined,
  DatabaseOutlined,
  FormOutlined,
  ProjectOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import { ContactSupportOutlined } from '@mui/icons-material';

const { Header, Content, Sider } = Layout;

function buildTreeData(data) {
  return data.map(item => {
    let titleContent;
    if (item.code) {
      titleContent = (
        <span>
          <span className="menu-num">{item.code}</span>
          <span className="menu-label">{item.title}</span>
        </span>
      );
    } else {
      titleContent = item.title;
    }
    const node = {
      title: titleContent,
      key: item.key,
      titleText: (typeof item.title === 'string' ? item.title : (item.menuNm || '')),
      butnId: item.butnId ?? item.BUTN_ID ?? '',
      menuId: item.menuId ?? item.key,
    };
    if (item.children) {
      node.children = buildTreeData(item.children);
    }
    if (item.component) {
      node.component = item.component;
    }
    return node;
  });
}

/**
 * Create content element for a tree node on demand.
 * Avoids stale state and ensures the correct CLSS_NM/label are used.
 */
function createContent(node) {
  const titleText = node?.titleText || node?.menuNm || (typeof node?.title === 'string' ? node.title : '');
  const clssNm = node?.clssNm || node?.CLSS_NM || node?.className;
  return clssNm
    ? <PageHost clssNm={clssNm} title={titleText} />
    : <Placeholder title={titleText} />;
}

/**
 * The main application component. It wires together a horizontal menu bar,
 * a side tree that displays submenus, and a tabbed content area for showing
 * selected pages. The state of opened tabs and the active tab key are
 * managed here.
 */
export default function App() {
  // MUI theme state (light/dark)
  const [mode, setMode] = useState('light');
  const theme = useMemo(() => createTheme({
    palette: { mode },
    typography: {
      // 한글 가독성 개선 시 여기에 폰트 패밀리 지정 가능
      // fontFamily: ['Noto Sans KR', 'Roboto', 'Apple SD Gothic Neo', 'Segoe UI', 'Helvetica', 'Arial', 'sans-serif'].join(','),
    },
  }), [mode]);

  // TODO: 인증정보사용
  const { user, setUser } = useAuth();
  const navigate = useNavigate();

  const { setActive } = usePerm();
  const [menuData, setMenuData] = useState([]);
  const [openTopMenu, setOpenTopMenu] = useState(null);
  const [tabs, setTabs] = useState([]);
  const [activeKey, setActiveKey] = useState(null);
  const [sidebarWidth, setSidebarWidth] = useState(260);
  const [isResizing, setIsResizing] = useState(false);

  useEffect(() => {
    async function fetchMenus() {
      // TODO: 로그인 사용자 ID없을시 종료
      if(!user?.userId) {
        navigate('/login');
        return;
      }
      try {
        const param = { SYS_TP_CD: "STO", USR_ID: user.userId};
        const { name, table } = await http.post('/webcom/getmain',param,{ shape: 'datatable'});
        const idToNode = {};

        console.log('Menu table data:', table);
        
        table.forEach(item => {
          const hasProgram = item.PROGM_ID && String(item.PROGM_ID).trim().length > 0;
          const codeValue = hasProgram && item.SCREN_NO ? item.SCREN_NO : undefined;
          idToNode[item.MENU_ID] = {
            key: item.MENU_ID,
            title: item.MENU_NM,
            butnId: item.BUTN_ID || '',
            progmId: item.PROGM_ID,
            screnNo: item.SCREN_NO,
            clssNm: item.CLSS_NM,
            children: [],
            component: null,
          };
        });
        table.forEach(item => {
          const node = idToNode[item.MENU_ID];
          if (item.CLSS_NM && String(item.CLSS_NM).trim().length > 0) {
            node.component = <PageHost clssNm={item.CLSS_NM} title={item.MENU_NM} />;
          } else {
            node.component = <Placeholder title={item.MENU_NM} />;
          }
          if (item.UP_MENU_ID && idToNode[item.UP_MENU_ID]) {
            idToNode[item.UP_MENU_ID].children.push(node);
          }
        });
        const roots = [];
        table.forEach(item => {
          if (item.LV === 1) {
            const node = idToNode[item.MENU_ID];
            const title = item.MENU_NM;
            let icon;
            if (title.includes('Home') || title.includes('대시보드') || title.includes('홈')) {
              icon = <HomeOutlined />;
            } else if (title.includes('기초') || title.includes('자산')) {
              icon = <DatabaseOutlined />;
            } else if (title.includes('청약') || title.includes('배정')) {
              icon = <FormOutlined />;
            } else if (title.includes('배치') || title.includes('운영')) {
              icon = <ProjectOutlined />;
            } else if (title.includes('관리')) {
              icon = <SettingOutlined />;
            } else {
              icon = <FormOutlined />;
            }
            node.icon = icon;
            roots.push(node);
          }
        });
        setMenuData(roots);
        if (roots.length > 0) {
          setOpenTopMenu(roots[0].key);
        }
      } catch (error) {
        console.error('Failed to load menus', error);
      }
    }
    fetchMenus();
  }, [user?.userId, navigate]);

  const handleTopMenuClick = ({ key }) => {
    setOpenTopMenu(key);
  };

  const handleTreeSelect = (selectedKeys, info) => {
    if (!info.node) return;
    const { key, children } = info.node;
    try { const n = info.node; setActive(String(n.key || n.menuId || ''), n.butnId); } catch(e) {}
    if (!children || (Array.isArray(children) && children.length === 0)) {
      const existing = tabs.find(tab => tab.key === key);
      if (existing) {
        setActiveKey(existing.key);
      } else {
        const newTab = { key, title: info.node.title, content: info.node.component, node: info.node };
        setTabs([...tabs, newTab]);
        setActiveKey(key);
      }
    }
  };

  const removeTab = (targetKey) => {
    const newTabs = tabs.filter(tab => tab.key !== targetKey);
    if (newTabs.length === 0) {
      setTabs([]);
      setActiveKey(null);
    } else {
      if (activeKey === targetKey) {
        const lastIndex = tabs.findIndex(tab => tab.key === targetKey) - 1;
        const newActive = newTabs[lastIndex >= 0 ? lastIndex : 0].key;
        setActiveKey(newActive);
      }
      setTabs(newTabs);
    }
  };

  const treeData = buildTreeData(
    (menuData.find(item => item.key === openTopMenu)?.children) || []
  );

  function getLeafNodes(data, leaves = []) {
    data.forEach(item => {
      if (item.children && item.children.length > 0) {
        getLeafNodes(item.children, leaves);
      } else if (item.component) {
        leaves.push({ key: item.key, code: item.code || '', title: item.title });
      }
    });
    return leaves;
  }
  const leafNodes = getLeafNodes(menuData);

  const selectOptions = leafNodes.map(item => ({
    label: `${item.code ? item.code + ' ' : ''}${item.title}`,
    value: item.key,
  }));

  const openTabByKey = (value) => {
    function findItem(data, key) {
      for (const item of data) {
        if (item.key === key) return item;
        if (item.children) {
          const found = findItem(item.children, key);
          if (found) return found;
        }
      }
      return null;
    }
    const item = findItem(menuData, value);
    if (item) {
      try { setActive(String(item.menuId || item.key || ''), item.butnId); } catch(e) {}
      const exists = tabs.find(t => t.key === item.key);
      if (exists) {
        setActiveKey(exists.key);
      } else {
        const newTab = { key: item.key, title: item.title, content: createContent(item), node: item };
        setTabs([...tabs, newTab]);
        setActiveKey(item.key);
      }
    }
  };

  const handleMouseDown = () => setIsResizing(true);
  const handleMouseMove = (e) => {
    if (isResizing) {
      const newWidth = Math.min(400, Math.max(180, e.clientX));
      setSidebarWidth(newWidth);
    }
  };
  const handleMouseUp = () => { if (isResizing) setIsResizing(false); };

  const handleLogout = async () => {
    const confirm = window.confirm('정말 로그아웃 하시겠습니까?');
    if (!confirm) return;

    try {
      await http.post('/auth/logout'); // POST /api/auth/logout 호출
      setUser(null);                   // 전역 사용자 상태 초기화
      navigate('/login', {replace: true});// 로그인 페이지로 이동
    } catch (err) {
      console.error('Logout failed', err);
    }
  }
  const handleUserInfo = async () => {
    if (user) {
      // message.info(
      //   `사용자 정보:\nID: ${user.userId}\n이름: ${user.userNm}\n그룹: ${user.usrGrpNm}`
      // );
      message.open({
        content: (
          <span style={{ whiteSpace: "pre-line" }}>
            {`사용자 정보:\nID: ${user.userId}\n이름: ${user.userNm}\n소속: ${user.usrGrpNm}`}
          </span>
        ),
        duration: 3, // 메시지 사라지는 시간 (초)
      });
    } else {
      message.error("사용자 정보가 없습니다. 로그인 상태를 확인하세요.");
    }
  }
  const handleLock = () => message.info('화면 잠금 기능이 호출되었습니다.');

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Layout style={{ minHeight: '100vh' }}>
        {/* Header containing the horizontal top menu and user action icons */}
        <Header style={{ padding: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%' }}>
            {/* Top navigation menu */}
            <Menu
              mode="horizontal"
              selectedKeys={openTopMenu ? [openTopMenu] : []}
              onClick={handleTopMenuClick}
              style={{ flex: 1 }}
            >
              {menuData.map(item => (
                <Menu.Item key={item.key} icon={item.icon}>{item.title}</Menu.Item>
              ))}
            </Menu>
            {/* User action icons aligned to the right */}
            <Space style={{ marginLeft: 20, marginRight: 16 }} align="right">
              <Tooltip title={`테마 전환 (${mode === 'light' ? 'Light' : 'Dark'})`}>
                <Switch
                  checked={mode === 'dark'}
                  onChange={(checked) => setMode(checked ? 'dark' : 'light')}
                  style={{ marginRight: 8 }}
                />
              </Tooltip>
              <Tooltip title="화면 잠금">
                <LockOutlined onClick={handleLock} style={{ color: '#ffffff', fontSize: 18, cursor: 'pointer' }} />
              </Tooltip>
              <Tooltip title="사용자 정보">
                <UserOutlined onClick={handleUserInfo} style={{ color: '#ffffff', fontSize: 18, cursor: 'pointer' }} />
              </Tooltip>
              <Tooltip title="로그아웃">
                <LogoutOutlined onClick={handleLogout} style={{ color: '#ffffff', fontSize: 18, cursor: 'pointer' }} />
              </Tooltip>
            </Space>
          </div>
        </Header>

        {/* Main body with resizable sidebar and content */}
        <div
          style={{ display: 'flex', flex: 1, height: 'calc(100vh - 64px)' }}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {/* Sidebar including search and tree */}
          <div
            className="side-tree"
            style={{ width: sidebarWidth, overflowY: 'auto', padding: '8px' }}
          >
            {/* Search/select to open pages directly */}
            <Select
              showSearch
              allowClear
              placeholder="메뉴 검색"
              style={{ width: '100%', marginBottom: 8 }}
              options={selectOptions}
              onChange={openTabByKey}
              filterOption={(input, option) =>
                option?.label?.toString().toLowerCase().includes(input.toLowerCase())
              }
            />
            {/* Tree menu */}
            <Tree
              treeData={treeData}
              onSelect={handleTreeSelect}
              defaultExpandAll
            />
          </div>

          {/* Resizer handle between sidebar and content */}
          <div
            style={{ width: 4, cursor: 'col-resize', background: '#e0e0e0' }}
            onMouseDown={handleMouseDown}
          />

          {/* Content area with tabs */}
          <div id="app-content-root" style={{ flex: 1, overflow: 'hidden', height: '100%'}}>
            <Card
              bodyStyle={{ padding: 0 }}
              style={{ height: '100%', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', borderRadius: 6, background: '#fff' }}
            >
              <Tabs
                hideAdd
                type="editable-card"
                onChange={(key) => {
                  setActiveKey(key);
                  try {
                    const t = tabs.find(t => t.key === key);
                    if (t && t.node) {
                      setActive(String(t.node.menuId || t.node.key || ''), t.node.butnId);
                    }
                  } catch(e) {}
                }}
                activeKey={activeKey || ''}
                onEdit={(targetKey, action) => {
                  if (action === 'remove') {
                    removeTab(targetKey);
                  }
                }}
              >
                {tabs.map(tab => (
                  <Tabs.TabPane tab={tab.title} key={tab.key} closable>
                    <div style={{ height: '100%' }}>
                      {tab.content}
                    </div>
                  </Tabs.TabPane>
                ))}
              </Tabs>
            </Card>
          </div>
        </div>
      </Layout>
    </ThemeProvider>
  );
}