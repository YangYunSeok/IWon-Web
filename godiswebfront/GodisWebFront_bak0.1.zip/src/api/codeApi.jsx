import axios from 'axios';

export const getGroups = async (params = {}) => {
  try {
    const response = await axios.post('/api/admin/getgroups', params);
    return response.data;
  } catch (error) {
    console.error('그룹 조회 실패:', error);
    return [];
  }
};

export const getItems = async (grpCdId) => {
  try {
    const response = await axios.post('/api/admin/getcodes', {
      GRP_CD_ID: grpCdId  // 대문자로 변경
    });
    return response.data;
  } catch (error) {
    console.error('공통코드 항목 조회 실패:', error);
    return [];
  }
};