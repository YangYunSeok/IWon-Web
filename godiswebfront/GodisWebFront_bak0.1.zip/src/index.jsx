import React from 'react';
import { createRoot } from 'react-dom/client';
import axios from 'axios';
import { AuthProvider } from '@/context/AuthContext.jsx';
import { BrowserRouter, useNavigate } from 'react-router-dom';
// ✅ 원래 있던 전역 스타일들 그대로 유지
import 'antd/dist/reset.css';
import '@/css/App.css';
// 서버호출
import { http } from '@/libs/TaskHttp';

// ✅ 원래 있던 전역 Provider들 그대로 유지
import { PermissionProvider } from '@/authz/PermissionStore';
import PermissionEnforcer from '@/authz/PermissionEnforcer.jsx';
import { useAuth } from '@/context/AuthContext.jsx';

// 메인 앱 (원래 진입 컴포넌트: App 혹은 MainShell 등)
import App from '@/App';

// 로그인 컴포넌트
import Login from '@/login.jsx';

function AuthGate() {
  
  const navigate = useNavigate();
  const {setUser} = useAuth();
  const [status, setStatus] = React.useState({ loading: true, loggedIn: false });

  React.useEffect(() => {
    const checkSession = async () => {
      try {
        const res = await http.post('/auth/session', {});

        if(!res || !res.success) {
          setUser(null);
          navigate('/login');
          setStatus({ loading: false, loggedIn: false });
        } else {
          setUser(res.user);             // 사용자 정보 설정
          setStatus({ loading: false, loggedIn: true });
        }
      } catch (error) {
        console.error(error);
        setUser(null);
        setStatus({ loading: false, loggedIn: false });
        navigate('/login');
      }
    };
    checkSession();
  }, [setUser, navigate]);

  if (status.loading) return <div>Loading...</div>;

  if (!status.loggedIn) {
    return <Login onSuccess={() => setStatus({ loading: false, loggedIn: true })} />;
  }

  return <App />;
}

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    {/*✅ AuthProvider로 인증정보 관리 추가 */}
    <AuthProvider>
      <PermissionProvider>
        <PermissionEnforcer>
          <AuthGate />
        </PermissionEnforcer>
      </PermissionProvider>
    </AuthProvider>
  </BrowserRouter>
);