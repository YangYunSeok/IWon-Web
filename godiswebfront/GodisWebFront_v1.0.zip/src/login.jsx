import React, { useState } from 'react';
import axios from 'axios';
import { useAuth } from '@/context/AuthContext.jsx';
import { useTheme } from '@mui/material/styles';
// 서버호출
import { http } from '@/libs/TaskHttp';
import { useNavigate } from 'react-router-dom';

export default function Login({ onSuccess }) {
  const theme = useTheme();
  const { setUser } = useAuth();
  const navigate = useNavigate();
  const [id, setId] = useState('');
  const [pw, setPw] = useState('');
  const [show, setShow] = useState(false);
  const [err, setErr] = useState('');

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!id || !pw) { setErr('아이디와 비밀번호를 입력하세요.'); return; }

     try {
      const param = { username: id, password: pw };
      const res = await http.post('/auth/login', param, {});

      if (!res || !res.success) {
        setErr(`로그인 실패: ${res.message}`);
        return;
      } else {
        setUser(res.user);
        navigate('/')
        onSuccess?.();
      }
    } catch (error) {
      console.error(error);
      setErr('서버와 연결할 수 없습니다.');
    }
  };

  return (
    <div style={styles.wrap}>
      <div style={styles.card}>
        <div style={styles.left}>
          <h1 style={styles.welcome}>WELCOME</h1>
          <div style={styles.headline}>Meta Domix Studio</div>
          <p style={styles.desc}>로그인 후 메인 화면으로 이동합니다.</p>
        </div>
        <div style={styles.right}>
          <div style={styles.panel}>
            <div style={styles.title}>Sign in</div>
            <form onSubmit={onSubmit}>
              <label style={styles.label}>User Name</label>
              <input
                style={styles.input}
                placeholder="User Name"
                value={id}
                onChange={(e)=>setId(e.target.value)}
                autoComplete="username"
              />
              <label style={{...styles.label, marginTop:12}}>Password</label>
              <div style={styles.passwordRow}>
                <input
                  style={{...styles.input, margin:0, flex:1, border:'none'}}
                  type={show ? 'text' : 'password'}
                  placeholder="Password"
                  value={pw}
                  onChange={(e)=>setPw(e.target.value)}
                  autoComplete="current-password"
                />
                <button type="button" onClick={()=>setShow(!show)} style={styles.showBtn}>
                  {show ? 'HIDE' : 'SHOW'}
                </button>
              </div>
              <div style={styles.row}>
                <label style={{display:'flex',alignItems:'center',gap:8}}>
                  <input type="checkbox" /> Remember me
                </label>
                <a href="#" style={styles.link}>Forgot Password?</a>
              </div>
              <button type="submit" style={styles.submit}>Sign in</button>
              <div style={styles.err}>{err}</div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  wrap: {minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',background:'#eef3f9'},
  card: {width:'min(1000px,92vw)',background:'#6750A4',borderRadius:18,boxShadow:'0 20px 50px rgba(0,0,0,0.15)',display:'grid',gridTemplateColumns:'1.2fr 1fr',overflow:'hidden'},
  left: {padding:'48px 40px',color:'#fff'},
  welcome:{margin:0,letterSpacing:2,fontSize:36,fontWeight:800},
  headline:{marginTop:10,opacity:.95,fontWeight:700},
  desc:{marginTop:14,opacity:.9,lineHeight:1.6,maxWidth:520},
  right:{display:'flex',alignItems:'center',justifyContent:'center',padding:'30px'},
  panel:{background:'#fff',borderRadius:14,padding:'26px 22px',width:'100%',maxWidth:360,boxShadow:'0 10px 30px rgba(0,0,0,.12)'},
  title:{fontSize:24,fontWeight:800,marginBottom:12,color:'#6750A4'},
  label:{display:'block',fontSize:12,color:'#678',margin:'4px 0'},
  input:{width:'100%',height:42,border:'1px solid #d9e2ef',borderRadius:8,padding:'0 12px',outline:'none'},
  passwordRow:{display:'flex',alignItems:'center',border:'1px solid #d9e2ef',borderRadius:8,overflow:'hidden'},
  showBtn:{height:42,padding:'0 12px',border:'none',background:'transparent',cursor:'pointer',color:'#6750A4',fontWeight:700},
  row:{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:10,fontSize:13},
  link:{color:'#6750A4',textDecoration:'none',fontWeight:700},
  submit:{marginTop:14,width:'100%',height:44,border:'none',borderRadius:8,background:'#6750A4',color:'#fff',fontWeight:800,letterSpacing:.3,cursor:'pointer'},
  err:{marginTop:8,color:'#c22',fontSize:12,minHeight:18}
};