// src/theme/muiThemeFromTokens.js
import { createTheme } from '@mui/material/styles';
import tokens from './tokens.json';

// ----- 유틸 -----
const get = (obj, path) =>
  path.split('.').reduce((o, k) => (o && o[k] != null ? o[k] : undefined), obj);

const tv = (obj) => {
  if (obj == null) return undefined;
  if (typeof obj === 'object') {
    if ('$value' in obj) return obj.$value;
    if ('value' in obj) return obj.value;
  }
  return obj;
};

const resolveRef = (all, raw) => {
  const v = tv(raw);
  if (typeof v !== 'string') return v;
  const m = v.match(/^\{(.+)\}$/);
  if (!m) return v; // 이미 hex 또는 일반 문자열
  const ref = get(all, m[1]);
  return tv(ref) ?? v;
};

const must = (name, v) => {
  if (v == null || v === '') {
    throw new Error(`[muiThemeFromTokens] Missing required token: ${name}`);
  }
  return v;
};

// ----- 공개 함수 -----
export function createMuiThemeFromTokens(mode = 'light') {
  const semantic = get(tokens, `${mode}.semantic`) || {};

  const primaryMain   = must(`${mode}.semantic.primaryMain`,   resolveRef(tokens, semantic.primaryMain));
  const onPrimary     = resolveRef(tokens, semantic.onPrimary);
  const bgCanvas      = must(`${mode}.semantic.bgCanvas`,      resolveRef(tokens, semantic.bgCanvas));
  const bgSurface     = must(`${mode}.semantic.bgSurface`,     resolveRef(tokens, semantic.bgSurface));
  const textPrimary   = must(`${mode}.semantic.textPrimary`,   resolveRef(tokens, semantic.textPrimary));
  const textSecondary = must(`${mode}.semantic.textSecondary`, resolveRef(tokens, semantic.textSecondary));
  const divider       = resolveRef(tokens, semantic.divider);
  const gridHeaderBg = resolveRef(tokens, semantic.gridHeaderBg);
  const gridHeaderText = resolveRef(tokens, semantic.gridHeaderText);

  const radiusMd = tv(get(tokens, 'global.radius.md')) ?? 12;

  const theme = createTheme({
    palette: {
      mode,
      primary: {
        main: primaryMain,
        ...(onPrimary ? { contrastText: onPrimary } : {}),
      },
      background: {
        default: bgCanvas,
        paper: bgSurface,
      },
      text: {
        primary: textPrimary,
        secondary: textSecondary,
      },
       dataGrid: {
         headerBg: gridHeaderBg,
         headerText: gridHeaderText,
       },


      ...(divider ? { divider } : {}),
    },
    shape: { borderRadius: Number(radiusMd) || 12 },
  });

  // onPrimary 없으면 대비색 자동계산
  if (!theme.palette.primary.contrastText) {
    theme.palette.primary.contrastText =
      theme.palette.getContrastText(theme.palette.primary.main);
  }

  return theme;
}
