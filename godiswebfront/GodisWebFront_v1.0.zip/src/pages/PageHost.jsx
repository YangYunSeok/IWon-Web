import React, { useEffect, useState } from 'react';

/**
 * PageHost: DB의 clssNm을 점(.) 기준 디렉터리로 바꿔
 * src/screens/<...>/<File>.js 를 동적으로 로드하여 렌더합니다.
 * (다른 파일은 건드리지 않습니다.)
 */
function toRelPathFromScreens(clssNm) {
  let s = (clssNm || '').trim();
  if (!s) return null;
  if (s.toLowerCase().endsWith('.jsx')) s = s.slice(0, -3);
  s = s.replace(/\.+/g, '/').replace(/^\/+|\/+$/g, '');
  return `./${s}.jsx`;
}

export default function PageHost({ clssNm, title }) {
  const [Comp, setComp] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    
    let mounted = true;
    async function load() {
      setLoading(true); setError(null); setComp(null);
      const rel = toRelPathFromScreens(clssNm);
      if (!rel) { setError(new Error('clss_nm이 비어있습니다.')); setLoading(false); return; }

      // // 1) CRA/Webpack: require.context 로 번들 내 파일 탐색
      // try {
      //   // eslint-disable-next-line global-require
      //   const ctx = require.context('../screens', true, /\.(js|jsx|tsx)$/);
      //   if (ctx && ctx.keys().includes(rel)) {
      //     const mod = ctx(rel);
      //     const C = mod?.default || mod;
      //     if (mounted) { setComp(() => C); setLoading(false); return; }
      //   }
      //   // .jsx/.tsx 후보도 시도
      //   for (const cand of [rel.replace(/\.js$/i, '.jsx'), rel.replace(/\.js$/i, '.tsx')]) {
      //     if (ctx && ctx.keys().includes(cand)) {
      //       const mod = ctx(cand);
      //       const C = mod?.default || mod;
      //       if (mounted) { setComp(() => C); setLoading(false); return; }
      //     }
      //   }
      // } catch (e) {
      //   // CRA가 아닐 경우를 대비해 fallback 제공
      // }

      // 2) Fallback: 상대 경로 dynamic import (웹팩이 경로 정적으로 모르면 실패할 수 있음)
      try {
        const base = rel.replace('./', '@/screens/');
        const mod = await import(
          /* webpackChunkName: "screen-[request]" */
          /* webpackMode: "lazy" */ 
          /* @vite-ignore */
          `${base}`);
        const C = mod?.default || mod;
        if (mounted) { setComp(() => C); setLoading(false); return; }
      } catch (e) {
        for (const baseCand of [
          rel.replace('./', '../screens/'),
        ]) {
          try {
            const mod = await import(
              /* webpackChunkName: "screen-[request]" */
              /* webpackMode: "lazy" */
              /* @vite-ignore */
              `${baseCand}`);
            const C = mod?.default || mod;
            if (mounted) { setComp(() => C); setLoading(false); return; }
          } catch {/* next */}
        }
        if (mounted) { setError(new Error(`모듈을 찾을 수 없습니다: src/screens/${rel.slice(2)}`)); setLoading(false); }
      }
    }
    load();
    return () => { mounted = false; };
  }, [clssNm]);

  return (
    <div>
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <h3 style={{ margin: 0 }}>{title}</h3>
        {clssNm && (
          <span style={{ fontSize: 12, padding: '2px 6px', border: '1px solid #d1d5db', borderRadius: 6 }}>
            {clssNm}
          </span>
        )}
      </div>
      {loading && <p style={{ marginTop: 16, opacity: .8 }}>JSX 화면을 불러오는 중입니다…</p>}
      {!loading && error && (
        <div style={{ marginTop: 16, padding: 12, border: '1px solid #fecaca', background: '#fff1f2', borderRadius: 8 }}>
          <div style={{ fontWeight: 700, marginBottom: 6 }}>JSX 모듈 로딩 실패</div>
          <div style={{ whiteSpace:'pre-wrap' }}>{String(error.message || error)}</div>
          <div style={{ marginTop: 8, fontSize: 12, opacity: .8 }}>
            아래 경로에 파일(.js 권장)을 배치해 주세요:<br/>
            <code>src/screens/{String(clssNm||'').replace(/\.jsx$/i,'').replace(/\.+/g,'/')}.jsx</code>
          </div>
        </div>
      )}
      {!loading && !error && Comp && <div style={{ marginTop: 16 }}><Comp /></div>}
    </div>
  );
}