import React, { useEffect, useMemo, useRef, useState } from 'react';
import dayjs from 'dayjs';
import { Box, Stack, Button, TextField, MenuItem, InputAdornment, IconButton } from '@mui/material';
import { SearchOutlined } from '@ant-design/icons';

// ========================= 사내 공통 컴포넌트/유틸 (GPCLOPRCD03S1 패턴 준용) =========================
import GDataGrid from '@/components/GDataGrid.jsx';
import GMessageBox from '@/components/GMessageBox';
import { http } from '@/libs/TaskHttp';
import { changes } from '@/libs/Utils';

// ================================== 컴포넌트 ==================================
export default function GPCLOPRCD04S1() {
  // ---------- 검색 영역 ----------
  const [msgClssCd, setMsgClssCd] = useState('');      // 메세지분류
  const [msgContn, setMsgContn]   = useState('');      // 메세지 내용(한/영 검색)

  // ---------- 공통 코드 ----------
  const [codesMsgClssCd, setCodesMsgClssCd] = useState([]);  // MSG_CLSS_CD(분류)
  const [codesTrMsgTpCd, setCodesTrMsgTpCd] = useState([]);  // MSG_TP_CD(유형)
  const [codesMsgButnCd, setCodesMsgButnCd] = useState([]);  // MSG_BUTN_CD(버튼)

  // ---------- 그리드 상태 ----------
  const [dtMessageCode, setDtMessageCode] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const drvSelected = useMemo(
    () => dtMessageCode.find(r => r.id === selectedId) || null,
    [dtMessageCode, selectedId]
  );
  const [loading, setLoading]             = useState(false);
  const [hasChanges, setHasChanges]       = useState(false);

  const InitializeControl = async () => {
    // TODO: 실제 공통코드 API로 대체
    setCodesMsgClssCd([
      { CD_VAL:'01', CD_VAL_NM:'화면', CD_ADD_INFO_VAL1:'MGE' },
      { CD_VAL:'02', CD_VAL_NM:'업무', CD_ADD_INFO_VAL1:'MGB' },
    ]);
    setCodesTrMsgTpCd([
      { CD_VAL:'000', CD_VAL_NM:'Error',       CD_ADD_INFO_VAL1:'0' },
      { CD_VAL:'100', CD_VAL_NM:'Information', CD_ADD_INFO_VAL1:'1' },
      { CD_VAL:'200', CD_VAL_NM:'Warning',     CD_ADD_INFO_VAL1:'2' },
    ]);
    setCodesMsgButnCd([
      { CD_VAL:'OK',  CD_VAL_NM:'OK' },
      { CD_VAL:'YES', CD_VAL_NM:'YES/NO' },
    ]);

    // 검색 콤보 기본값 세팅
    setMsgClssCd(prev => prev || '01');
  };

  const InitializeEvent = () => { /* C# 이벤트 바인딩 → JSX 핸들러로 대체 */ };

  const OnFormLoaded = () => {
    InitializeControl();
    InitializeEvent();
    GetMessageCode();
  };

  useEffect(() => { OnFormLoaded(); /* eslint-disable-next-line */ }, []);

  // ========== Validation (ASIS ChkValidation 반영) ==========
  const ChkValidation = (rows) => {
    for (const row of rows) {
      if (row.ROW_STATE === 'D') continue;
      if (!row.MSG_CLSS_NM)      { GMessageBox.Show('MGW00019'); return false; }
      if (!row.TR_MSG_TP_NM)     { GMessageBox.Show('MGW00019'); return false; }
      if (!row.MSG_BUTN_NM)      { GMessageBox.Show('MGW00019'); return false; }
      if (!row.MSG_KOR_CONTN)    { GMessageBox.Show('MGW00018'); return false; }
      // MSG_ID 8자리 규칙(영문3 숫자5) – C# MGW01154 근거
      if (row.MSG_ID && !(String(row.MSG_ID).length === 8)) { GMessageBox.Show('MGW01154'); return false; }
    }
    return true;
  };

  // ========== 변경 플래그 ==========
  const DataHasChanges = () => hasChanges;

  // ========== 조회 ==========
  const GetMessageCode = async () => {
    if (DataHasChanges()) {
      const r = await GMessageBox.Show('MGQ00015'); // 변경 무시 후 조회?
      if (String(r).toLowerCase() !== 'yes') return;
    }

    setLoading(true);
    try {
      const param = { MSG_CLSS_CD: msgClssCd, MSG_CONTN: msgContn ?? '' };
      // ▶ 엔드포인트는 제공해 준 파일 기준 그대로 유지
      const { table } = await http.post('/message/getMessageCode', param, { shape: 'datatable' });

      const mapped = (table || []).map((r, i) => ({
        id: r.MSG_ID || `MSG${String(i).padStart(7, '0')}`,
        ROW_STATE: r.ROW_STATE || '',
        ...r,
      }));

      setDtMessageCode(mapped);
      setHasChanges(false);
      setDrvSelected(null);
    } catch (e) {
      console.error('[메세지코드] 조회 실패', e);
    } finally { setLoading(false); }
  };

  // ========== 저장 ==========
  const SaveMessageCode = async () => {
    const data = changes(dtMessageCode);
    if (data.length === 0) { GMessageBox.Show('MGI00014'); return; }
    if (!ChkValidation(data)) return;

    const r = await GMessageBox.Show('MGQ00002'); // 저장하시겠습니까?
    if (String(r).toLowerCase() !== 'yes') return;

    try {
      await http.post('/message/savemessagecode', data, { shape: 'datarow' });
      setHasChanges(false);
      await GetMessageCode();
    } catch (e) { console.error('[메세지코드] 저장 실패', e); }
  };

  // ========== Cache Deploy ==========
  const BtnCacheDeploy_Click = async () => {
    // 필요 시 엔드포인트 연결
    // const r = await GMessageBox.Show('MGQ00066');
    // if (String(r).toLowerCase() !== 'yes') return;
    // await http.post('/admin/cachedeploy/messagecode', {}, { shape: 'json' });
  };

  // ========== 신규 행/편집 ==========
  const createNewRow = () => ({
    id: `NEW${Date.now()}`,
    ROW_STATE: 'I',
    MSG_ID: '',        // 접두(prefix)+번호(아래 setMsgId에서 계산)
    MSG_ID_NUM: '',
    MSG_CLSS_CD: msgClssCd || (codesMsgClssCd[0]?.CD_VAL || ''),
    MSG_CLSS_NM: codesMsgClssCd.find(c=>c.CD_VAL===msgClssCd)?.CD_VAL_NM || '',
    MSG_TP_CD:   '',
    TR_MSG_TP_NM: '',
    MSG_KOR_CONTN: '',
    MSG_ENG_CONTN: '',
    MSG_BUTN_CD: 'OK',
    MSG_BUTN_NM: 'OK',
    REG_ID: '', LST_ADJPRN_ID: '',
    REG_DDTM: dayjs().format('YYYYMMDDHHmmss'),
    LST_ADJ_DDTM: dayjs().format('YYYYMMDDHHmmss'),
  });

  const updateRow = (rowId, patch) => {
    setDtMessageCode(prev => prev.map(r => {
      if (r.id !== rowId) return r;
      const next = { ...r, ...patch };
      if (next.ROW_STATE !== 'I') next.ROW_STATE = 'U';
      return next;
    }));
    setHasChanges(true);
  };

  const onAddRow = () => { const n = createNewRow(); setDtMessageCode(prev => [n, ...prev]); setDrvSelected(n); setHasChanges(true); };
  const onDeleteRow = (row) => {
    setDtMessageCode(prev => prev.map(r => (r.id===row.id) ? (r.ROW_STATE==='I'? null : { ...r, ROW_STATE:'D' }) : r).filter(Boolean));
    setHasChanges(true);
  };

  const getDetailMsg = (param) => {
    console.log("~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~")
    console.log(param)
    setDrvSelected(param);
    console.log("~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~ == ~_~")
  };

  // ========== MSG_ID 생성 (ASIS setMsgId/KeyUp 로직) ==========
  const calcPrefix = (row) => {
    const clss = codesMsgClssCd.find(c => c.CD_VAL === (row.MSG_CLSS_CD || msgClssCd));
    const type = codesTrMsgTpCd.find(c => c.CD_VAL === row.MSG_TP_CD);
    const p1 = clss?.CD_ADD_INFO_VAL1 || '';
    const p2 = type?.CD_ADD_INFO_VAL1 || '';
    return `${p1}${p2}`;
  };
  const setMsgId = (rowId) => {
    setDtMessageCode(prev => prev.map(r => {
      if (r.id !== rowId) return r;
      if (r.ROW_STATE !== 'I') return r; // 신규행에서만 자동 조합
      const prefix = calcPrefix(r);
      const num = (r.MSG_ID_NUM||'').replace(/[^0-9]/g,'');
      const msgId = `${prefix}${num}`;
      return { ...r, MSG_ID: msgId };
    }));
  };

  // ========== 컬럼 ==========
  const columns = useMemo(() => ([
  { headerName: '메세지분류', field: 'MSG_CLSS_NM',  headerAlign: 'center', width: 140, editable: false },
  { headerName: '메세지코드', field: 'MSG_ID',       headerAlign: 'center', width: 140, editable: false },
  { headerName: '메세지유형', field: 'TR_MSG_TP_NM', headerAlign: 'center', width: 140, editable: false },
  { headerName: '한글메세지', field: 'MSG_KOR_CONTN',                 flex: 1,  minWidth: 260, editable: false },
  { headerName: '영문메세지', field: 'MSG_ENG_CONTN',                 flex: 1,  minWidth: 260, editable: false },
  { headerName: '버튼유형',   field: 'MSG_BUTN_NM',  headerAlign: 'center', width: 120, editable: false },
]), []);

  // ========== 렌더 ==========
  return (
    <div style={{ padding: 8 }}>
      <Stack spacing={2}>
        {/* 검색 영역 */}
        <Stack direction="row" spacing={1} alignItems="center">
          <TextField select size="small" label="메세지분류" sx={{ width: 180 }} value={msgClssCd} onChange={(e)=>setMsgClssCd(e.target.value)}>
            {codesMsgClssCd.map(c => <MenuItem key={c.CD_VAL} value={c.CD_VAL}>{c.CD_VAL_NM}</MenuItem>)}
          </TextField>

          <TextField size="small" label="메세지 내용" sx={{ width: 360 }} value={msgContn}
            onChange={(e)=>setMsgContn(e.target.value)}
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton edge="end" size="small" onClick={GetMessageCode}><SearchOutlined /></IconButton>
                </InputAdornment>
              )
            }}
            onKeyUp={(e)=>{ if (e.key === 'Enter') GetMessageCode(); }}
          />

          <Button variant="contained" onClick={GetMessageCode}>Search</Button>
        </Stack>

        {/* 상단: 시스템 메세지 그리드 */}
        <Box sx={{ border: '2px solid #4472C4', padding: '8px', backgroundColor: '#fff', borderRadius: '4px' }}>
          <GDataGrid
            title={`시스템 메세지 Total (${dtMessageCode.length})`}
            rows={dtMessageCode}
            columns={columns}
            height={420}
            rowHeight={25}
            loading={loading}
            checkboxSelection
            hideFooter
            pagination={false}
            disableRowSelectionOnClick
            Buttons={[true, true, true, true]}
            onRowsChange={(rows)=>{ setDtMessageCode(rows); setHasChanges(true); }}
            onAddRow={onAddRow}
            onDeleteRow={onDeleteRow}
            onRevertClick={GetMessageCode}
            selectedItem={drvSelected}          // 이 prop이 필요하다면 유지 (계산된 객체)
            onRowClick={(params)=> setSelectedId(params.row.id)}
            onSelectedItemChange={(row)=> setSelectedId(row?.id)}
          />

          <Stack direction="row" spacing={1} justifyContent="flex-end" sx={{ mt: 1 }}>
            <Button variant="outlined" onClick={BtnCacheDeploy_Click}>Cache Deploy</Button>
            <Button variant="contained" onClick={SaveMessageCode} disabled={!hasChanges}>Save</Button>
          </Stack>
        </Box>

        {/* 하단: 메세지 상세 (ASIS 스타일) */}
        <Box sx={{ border: '2px solid #4472C4', padding: '8px', backgroundColor: '#fff', borderRadius: '4px' }}>
          <Box sx={{ display:'flex', alignItems:'center', padding:'4px 8px', borderBottom:'1px solid #ddd' }}>
            <Box fontSize="13px" fontWeight="600" color="#333">● 메세지 상세</Box>
          </Box>

          <Box sx={{ border:'1px solid #e0e0e0', borderRadius:'4px', padding:'12px', display:'grid', gridTemplateColumns:'160px 1fr 160px 1fr', gap:1 }}>
            {/* 메세지분류 */}
            <DetailLabel>메세지분류</DetailLabel>
            <TextField
              select size="small"
              value={drvSelected?.MSG_CLSS_CD || ''}
              onChange={(e)=> drvSelected && updateRow(drvSelected.id, {
                MSG_CLSS_CD: e.target.value,
                MSG_CLSS_NM: codesMsgClssCd.find(c=>c.CD_VAL===e.target.value)?.CD_VAL_NM || ''
              })}
            >
              {codesMsgClssCd.map(c => <MenuItem key={c.CD_VAL} value={c.CD_VAL}>{c.CD_VAL_NM}</MenuItem>)}
            </TextField>

            {/* 메세지유형 */}
            <DetailLabel>메세지유형</DetailLabel>
            <TextField
              select size="small"
              value={drvSelected?.MSG_TP_CD || ''}
              onChange={(e)=> drvSelected && updateRow(drvSelected.id, {
                MSG_TP_CD: e.target.value,
                TR_MSG_TP_NM: codesTrMsgTpCd.find(c=>c.CD_VAL===e.target.value)?.CD_VAL_NM || ''
              })}
            >
              {codesTrMsgTpCd.map(c => <MenuItem key={c.CD_VAL} value={c.CD_VAL}>{c.CD_VAL_NM}</MenuItem>)}
            </TextField>

            {/* 메세지코드 */}
            <DetailLabel>메세지코드</DetailLabel>
            <TextField size="small" value={drvSelected?.MSG_ID || ''}
              onChange={(e)=> drvSelected && updateRow(drvSelected.id, { MSG_ID: e.target.value })}
              InputProps={{ readOnly: !(drvSelected?.ROW_STATE==='I') }} />

            {/* 메세지코드(직접입력) */}
            <DetailLabel>메세지코드(직접입력)</DetailLabel>
            <TextField size="small" value={drvSelected?.MSG_ID_NUM || ''}
              onChange={(e)=>{ if (!drvSelected) return; updateRow(drvSelected.id, { MSG_ID_NUM: e.target.value }); setTimeout(()=> setMsgId(drvSelected.id), 0); }}
              InputProps={{ readOnly: !(drvSelected?.ROW_STATE==='I') }} />

            {/* 한글내용 */}
            <DetailLabel>한글내용</DetailLabel>
            <TextField size="small" value={drvSelected?.MSG_KOR_CONTN ?? ''}
              onChange={(e)=> drvSelected && updateRow(drvSelected.id, { MSG_KOR_CONTN: e.target.value })}
              multiline minRows={1}
            />

            {/* 영문내용 */}
            <DetailLabel>영문내용</DetailLabel>
            <TextField size="small" value={drvSelected?.MSG_ENG_CONTN || ''}
              onChange={(e)=> drvSelected && updateRow(drvSelected.id, { MSG_ENG_CONTN: e.target.value })}
              multiline minRows={1}
            />

            {/* 버튼코드 */}
            <DetailLabel>버튼코드</DetailLabel>
            <TextField
              select size="small"
              value={drvSelected?.MSG_BUTN_CD || ''}
              onChange={(e)=> drvSelected && updateRow(drvSelected.id, {
                MSG_BUTN_CD: e.target.value,
                MSG_BUTN_NM: codesMsgButnCd.find(c=>c.CD_VAL===e.target.value)?.CD_VAL_NM || ''
              })}
            >
              {codesMsgButnCd.map(c => <MenuItem key={c.CD_VAL} value={c.CD_VAL}>{c.CD_VAL_NM}</MenuItem>)}
            </TextField>
          </Box>
        </Box>
      </Stack>
    </div>
  );
}

// 상세 레이블 공통 컴포넌트
function DetailLabel({ children }) {
  return <Box sx={{ alignSelf:'center', fontSize:12, color:'#666' }}>{children}</Box>;
}
