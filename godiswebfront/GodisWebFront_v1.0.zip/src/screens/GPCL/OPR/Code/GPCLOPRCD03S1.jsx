import React, { useEffect, useMemo, useState, useRef } from 'react';
import { Box, Stack, Button, TextField, InputAdornment, IconButton } from '@mui/material';
import dayjs from 'dayjs';

// 사내 공통 컴포넌트 (GPCLOPRCD01S1 / GPCLOPRUS01S1와 동일 계열 가정)
import GDataGrid from '@/components/GDataGrid.jsx';
import { SearchOutlined } from '@ant-design/icons';
import GDateEditCell from '@/components/GDateEditCell.jsx';
import GSimpleTreeGrid from '@/components/GSimpleTreeGrid';
import GMessageBox from '@/components/GMessageBox';
import { http } from '@/libs/TaskHttp';
import { changes } from '@/libs/Utils';

export default function GPCLOPRCD03S1() {
  // ================== 상태 정의 ==================
  // 상단 검색어(그룹코드명)
  const [grpNm, setGrpNm] = useState('');
  const codesReqRef = useRef(0); // 최신 요청 식별자

  // 그룹 그리드
  const [clssGroups, setClssGroups] = useState([]); // DtClssCodeGroup
  const [drvSelectedClssCodeGroup, setDrvSelectedClssCodeGroup] = useState(null); // DrvSelectedClssCodeGroup
  const [hasGroupChanges, setHasGroupChanges] = useState(false);

  // 트리 + 상세
  const [clssCodes, setClssCodes] = useState([]); // DtClssCode (tree rows)
  const [drvSelectedClssCode, setDrvSelectedClssCode] = useState(null); // DrvSelectedClssCode
  const [loadingCodes, setLoadingCodes] = useState(false);
  const [hasCodeChanges, setHasCodeChanges] = useState(false);

  // 재조회 경고 플래그(C# _bSearchFlag)
  const [bSearchFlag, setBSearchFlag] = useState(true);

  // ================== ASIS 함수명 ==================
  const InitializeControl = () => {};
  const InitializeEvent = () => {};
  const initializeData = () => { GetClssCodGroupData(); };

  useEffect(() => {
    InitializeControl();
    InitializeEvent();
    initializeData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!drvSelectedClssCodeGroup?.CLSS_GRP_CD_ID) {
        setClssCodes([]);
        setDrvSelectedClssCode(null);
        return;
    }
    // 최신 그룹 기준으로 트리 조회
    GetClssCodeData(drvSelectedClssCodeGroup);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [drvSelectedClssCodeGroup]);

  // ================== 공통 유틸(ASIS chkValidation 대응) ==================
  const ymdOk = (v) => /^(\d{8})$/.test(String(v||''));
  const toNum = (v) => Number(String(v||'').replace(/[^0-9]/g,''));

  /**
   * @param {('G'|'C')} type  - G: 계층그룹코드, C: 계층코드
   * @param {Array<object>} rows - 변경 데이터 테이블(changes 결과)
   * @returns {Promise<boolean>} 통과 여부
   */
  const chkValidation = async (type, rows) => {
    if (!Array.isArray(rows) || rows.length === 0) return true;

    if (type === 'G') {
      for (const row of rows) {
        if (row.ROW_STATE === 'D') continue;

        // 1) 필수값: CLSS_GRP_CD_ID
        if (!row.CLSS_GRP_CD_ID || String(row.CLSS_GRP_CD_ID).trim() === '') {
          await GMessageBox.Show('MGW00018'); // {0}을(를) 입력하세요. (그룹코드ID)
          // 실패행으로 포커스 이동
          const target = (clssGroups||[]).find(r => r.CLSS_GRP_CD_ID === row.CLSS_GRP_CD_ID) || row;
          setDrvSelectedClssCodeGroup(target);
          return false;
        }

        // 2) 필수값: VALID_STRT_DD / VALID_END_DD
        if (!row.VALID_STRT_DD || !ymdOk(row.VALID_STRT_DD)) {
          await GMessageBox.Show('MGW00018'); // 적용일
          setDrvSelectedClssCodeGroup((clssGroups||[]).find(r => r.CLSS_GRP_CD_ID === row.CLSS_GRP_CD_ID) || row);
          return false;
        }
        if (!row.VALID_END_DD || !ymdOk(row.VALID_END_DD)) {
          await GMessageBox.Show('MGW00018'); // 만료일
          setDrvSelectedClssCodeGroup((clssGroups||[]).find(r => r.CLSS_GRP_CD_ID === row.CLSS_GRP_CD_ID) || row);
          return false;
        }

        // 3) 중복체크: CLSS_GRP_CD_ID
        const dupeCnt = (clssGroups||[])
          .concat(rows.filter(r=>r!==row))
          .filter(r => r.CLSS_GRP_CD_ID === row.CLSS_GRP_CD_ID && r.ROW_STATE !== 'D').length;
        if (dupeCnt > 1) {
          await GMessageBox.Show('MGW00024'); // 중복된 값 존재
          setDrvSelectedClssCodeGroup((clssGroups||[]).find(r => r.CLSS_GRP_CD_ID === row.CLSS_GRP_CD_ID) || row);
          return false;
        }

        // 4) 날짜 범위 검사: start <= end
        if (toNum(row.VALID_STRT_DD) > toNum(row.VALID_END_DD)) {
          // Util.CheckTurnAroundFromToDate == false 대응
          await GMessageBox.Show('MGW00018'); // 날짜 범위 오류 메시지 테이블에 맞춰 교체 필요
          setDrvSelectedClssCodeGroup((clssGroups||[]).find(r => r.CLSS_GRP_CD_ID === row.CLSS_GRP_CD_ID) || row);
          return false;
        }
      }
    } else if (type === 'C') {
      // 선택 그룹이 신규이면 우선 저장 요구
      if (drvSelectedClssCodeGroup?.ROW_STATE === 'I') {
        await GMessageBox.Show('MGN00020'); // 먼저 저장해 주세요.
        return false;
      }

      for (const row of rows) {
        if (row.ROW_STATE === 'D') continue;
        // 1) 필수값: GRP_CD_ID
        if (!row.GRP_CD_ID || String(row.GRP_CD_ID).trim() === '') {
          await GMessageBox.Show('MGW00019'); // 선택하세요
          const target = (clssCodes||[]).find(r => r.CLSS_GRP_CD_ID===row.CLSS_GRP_CD_ID && r.CLSS_CD_VAL===row.CLSS_CD_VAL) || row;
          setDrvSelectedClssCode(target);
          return false;
        }
        // 2) 필수값: CD_VAL (또는 연결 공통코드 값)
        if (!row.CD_VAL || String(row.CD_VAL).trim() === '') {
          await GMessageBox.Show('MGW00019');
          const target = (clssCodes||[]).find(r => r.CLSS_GRP_CD_ID===row.CLSS_GRP_CD_ID && r.CLSS_CD_VAL===row.CLSS_CD_VAL) || row;
          setDrvSelectedClssCode(target);
          return false;
        }
      }
    }

    return true;
  };

  // ================== 조회 ==================
  const DataHasChanges = () => (hasGroupChanges || hasCodeChanges);

  const GetClssCodGroupData = async () => {
    // C#: MGQ00015 (변경데이터 존재 시 재조회 여부)
    if (bSearchFlag && DataHasChanges()) {
      const r = await GMessageBox.Show('MGQ00015', 'YesNo', 'warning', 'Warning');
      if (r === 'no') return;
    }

    try {
      const param = { CLSS_GRP_CD_DSC: grpNm ?? '' };
      // 실제 라우트로 교체 필요
      const { table } = await http.post('/admin/getclsscodegroup', param, { shape: 'datatable' });
      setClssGroups(table ?? []);
      setHasGroupChanges(false);

      if ((table ?? []).length > 0) {
        setDrvSelectedClssCodeGroup(table[0]);
        await GetClssCodeData(table[0]);
      } else {
        setDrvSelectedClssCodeGroup(null);
        setClssCodes([]);
        setDrvSelectedClssCode(null);
      }
    } catch (e) {
      console.error('[계층코드그룹] 조회 실패', e);
    } finally {
    }
  };

  const GetClssCodeData = async (grpRow = drvSelectedClssCodeGroup) => {
    if (!grpRow || !grpRow.CLSS_GRP_CD_ID) {
        setClssCodes([]);
        setDrvSelectedClssCode(null);
        return;
    }

    try {
        setLoadingCodes(true);
        const myReqId = ++codesReqRef.current; // 내 요청 번호
        const param = { CLSS_GRP_CD_ID: grpRow.CLSS_GRP_CD_ID };
        const { table } = await http.post('/admin/getclsscode', param, { shape: 'datatable' });

        // 뒤늦게 온 이전 요청이면 무시 (비동기 경쟁 방지)
        if (myReqId !== codesReqRef.current) return;

        // 트리 요구 키 보정
        const mapped = (table || []).map((r, i) => {
            // 루트 노드는 parentIdField를 null/undefined로 맞춰주자
            const parent = (r.UP_CLSS_CD_VAL && r.UP_CLSS_CD_VAL.trim() !== '') ? r.UP_CLSS_CD_VAL : null;

            return {
                id: r.CLSS_CD_VAL || `CLSS${String(i).padStart(7, '0')}`,
                ...r,
                // 👇 GRP_NM이 비어 있으면 CD_VAL_NM을 라벨로 사용 (없으면 코드값)
                GRP_NM: r.GRP_NM && String(r.GRP_NM).trim() !== '' 
                        ? r.GRP_NM 
                        : (r.CD_VAL_NM && String(r.CD_VAL_NM).trim() !== '' 
                            ? r.CD_VAL_NM 
                            : (r.CLSS_CD_VAL || '')),
                UP_CLSS_CD_VAL: parent,
            };
        });
        

        setClssCodes(mapped);
        setHasCodeChanges(false);

        // ✅ 선택 유지 로직
        if (drvSelectedClssCode) {
          const keep = mapped.find((x) => x.CLSS_CD_VAL === drvSelectedClssCode.CLSS_CD_VAL);
          setDrvSelectedClssCode(keep || mapped[0] || null);
        } else {
          setDrvSelectedClssCode(mapped[0] || null);
        }
    } catch (e) {
        console.error('[계층코드] 조회 실패', e);
    } finally {
        setLoadingCodes(false);
    }
  };

  // ================== 저장 ==================
  const SaveClssCodeGroup = async () => {
    const data = changes(clssGroups);
    if (data.length === 0) {
      await GMessageBox.Show('MGE00890', 'Ok', 'warning', 'Information');
      return;
    }

    
    if (!(await chkValidation('G', data))) return;

    const r = await GMessageBox.Show('MGE00890', 'YesNo', 'warning', 'Warning');
    if (r === 'no') return;

    try {
      await http.post('/admin/saveclsscodegroup', data, { shape: 'datarow' });
      setHasGroupChanges(false);
      await GetClssCodGroupData();
    } catch (e) {
      console.error('[계층코드그룹] 저장 실패', e);
    }
  };

  const SaveClssCode = async () => {
    const data = changes(clssCodes);
    if (data.length === 0) {
      await GMessageBox.Show('MGE00890', 'Ok', 'warning', 'Information');
      return;
    }
    
    /********************************************************* PSW 임시 코드 *********************************************************/
    for (const row of data) {
      row.CD_VAL = row.CD_VAL_NM;
      row.GRP_CD_ID = "코드피커필요";
      row.GRP_NM = "코드피커필요";
    }
    /********************************************************* PSW 임시 코드 *********************************************************/

    console.log(data)
    if (!(await chkValidation('C', data))) return;

    const r = await GMessageBox.Show('MGE00890', 'YesNo', 'warning', 'Warning');
    if (r === 'no') return;

    try {
      console.log(data)
      await http.post('/admin/saveclsscode', data, { shape: 'datarow' });
      setHasCodeChanges(false);
      await GetClssCodeData();
    } catch (e) {
      console.error('[계층코드] 저장 실패', e);
    }
  };

  // ================== Cache Deploy ==================
  const BtnCacheDeploy_Click = async () => {
    const r = await GMessageBox.Show('MGQ00066', 'YesNo', 'warning', 'Warning');
    if (r === 'no') return;
    try {
      await http.post('/admin/cachedeploy/classcode', {}, { shape: 'json' });
    } catch (e) {
      console.error('[CacheDeploy] 실패', e);
    }
  };

  // ================== 신규 행 템플릿 ==================
  const createNewGroupRow = () => ({
    ROW_STATE: 'I',
    CLSS_GRP_CD_ID: '',
    CLSS_GRP_CD_DSC: '',
    MEM_CREAT_OBJ_YN: 'Y',
    VALID_STRT_DD: dayjs().format('YYYYMMDD'),
    VALID_END_DD: '99991231',
  });

  const nextClssCodeVal = () => {
    const max = clssCodes.reduce((m, r) => {
      const n = Number((r.CLSS_CD_VAL || '').replace(/^CLSS/, '')) || 0;
      return Math.max(m, n);
    }, 0);
    return `CLSS${String(max + 1).padStart(7, '0')}`;
  };

  const createNewClssRow = (parent) => {
    var newClssCd = nextClssCodeVal();
    
    return {
    id: newClssCd, 
    ROW_STATE: 'I',
    CLSS_GRP_CD_ID: drvSelectedClssCodeGroup?.CLSS_GRP_CD_ID || '',
    CLSS_CD_VAL: newClssCd,
    UP_CLSS_CD_VAL: parent?.CLSS_CD_VAL || null,
    GRP_CD_ID: '',
    GRP_NM: '',
    CD_VAL: '',
    CD_VAL_NM: 'New' + newClssCd,
  };
}

const generateNewClssId = () => {
    var newClssCd = nextClssCodeVal();
    return newClssCd;
}

  // ================== 삭제 재귀 (ASIS DeleteClssCdList) ==================
  const DeleteClssCdList = (node) => {
    if (!node) return;
    const children = clssCodes.filter(r => r.UP_CLSS_CD_VAL === node.CLSS_CD_VAL);
    children.forEach(DeleteClssCdList);

    setClssCodes(prev => prev
      .map(r => {
        if (r.CLSS_CD_VAL !== node.CLSS_CD_VAL) return r;
        if (r.ROW_STATE === 'I') return null; // 신규는 물리 삭제
        return { ...r, ROW_STATE: 'D' };      // 기존은 D 처리
      })
      .filter(Boolean)
    );
    setHasCodeChanges(true);
  };

  // ================== 컬럼 ==================
  const groupColumns = useMemo(() => ([
    { headerName: '그룹코드ID', headerAlign: 'center', field: 'CLSS_GRP_CD_ID', width: 160, editable: true },
    { headerName: '설명',       headerAlign: 'center', field: 'CLSS_GRP_CD_DSC', flex: 1, editable: true },
    { headerName: '메모리생성대상', headerAlign: 'center', field: 'MEM_CREAT_OBJ_YN', width: 120, editable: true, type: 'singleSelect', valueOptions:[{value:'Y',label:'Yes'},{value:'N',label:'No'}]},
    { headerName: '적용일',     headerAlign: 'center', field: 'VALID_STRT_DD', width: 120, editable: true, displayAsYmd:true, renderEditCell:(p)=><GDateEditCell {...p} /> },
    { headerName: '만료일',     headerAlign: 'center', field: 'VALID_END_DD',  width: 120, editable: true, displayAsYmd:true, renderEditCell:(p)=><GDateEditCell {...p} /> },
  ]), []);

  // ================== 이벤트 ==================
  const handleSelectGroup = async (row) => {
    if (drvSelectedClssCodeGroup?.CLSS_GRP_CD_ID === row?.CLSS_GRP_CD_ID) return;

    if (DataHasChanges()) {
      const ok = window.confirm('변경된 데이터가 존재합니다! 무시하고 조회 하겠습니까?');
      if (!ok) return;
    }

    setDrvSelectedClssCodeGroup(row);
    await GetClssCodeData(row);
  };

  const updateSelectedClssCode = (patch) => {
    if (!drvSelectedClssCode) return;
    const next = {
      ...drvSelectedClssCode,
      ...patch,
      ROW_STATE: drvSelectedClssCode.ROW_STATE === 'I' ? 'I' : 'U',
    };
    setDrvSelectedClssCode(next);
    setClssCodes(prev => prev.map(r => (r.id === drvSelectedClssCode.id ? next : r)));
    setHasCodeChanges(true);
  };

  // ================== 렌더 ==================
  return (
    <div style={{ padding: 8 }}>
      <Stack spacing={2}>
        {/* 검색 영역 */}
        <Stack direction="row" spacing={1} alignItems="center">
          <TextField
            size="small"
            value={grpNm}
            onChange={(e)=>setGrpNm(e.target.value)}
            onKeyUp={(e)=>{ if (e.key === 'Enter') GetClssCodGroupData(); }}
            placeholder="그룹코드명"
            sx={{ width: 260 }}
          />
          <Button variant="contained" onClick={GetClssCodGroupData}>Search</Button>
        </Stack>

        {/* 상단: 계층코드그룹 그리드 */}
        <GDataGrid
          title="계층코드그룹"
          rows={clssGroups}
          columns={groupColumns}
          height={260}
          columnHeaderHeight={30}
          checkboxSelection
          rowHeight={25}
          hideFooter
          pagination={false}
          disableRowSelectionOnClick
          Buttons={[true, true, true, true]}
          createNewRow={createNewGroupRow}
          onRowsChange={(rows)=>{ setClssGroups(rows); setHasGroupChanges(true); }}
          onRowClick={(params)=>handleSelectGroup(params.row)}
          onRevertClick={GetClssCodGroupData}
        />
        <div style={{ display:'flex', justifyContent:'flex-end' }}>
          <Button variant="contained" onClick={SaveClssCodeGroup} disabled={!hasGroupChanges}>Save</Button>
        </div>

        {/* 하단: 트리 + 상세 */}
        <Box sx={{ border: '2px solid #4472C4', padding: '8px', backgroundColor: '#fff', borderRadius: '4px' }}>
          <Stack direction="row" spacing={2}>
            {/* 좌측: 계층코드 트리 (컬럼 헤더 없음) */}
            <GSimpleTreeGrid
              title="계층코드"
              rows={clssCodes}
              onRowsChange={(rows)=>{ setClssCodes(rows); setHasCodeChanges(true); }}
              idField="CLSS_CD_VAL"
              parentIdField="UP_CLSS_CD_VAL"
              labelField="CD_VAL_NM"
              selectedItem={drvSelectedClssCode}
              onSelectedItemChange={setDrvSelectedClssCode}
              createNewRow={createNewClssRow}
              generateNewId={generateNewClssId}
              onDeleteRow={DeleteClssCdList}
              Buttons={{ add:true, delete:true, revert:true, excel:false }}
              onRevertClick={()=> drvSelectedClssCodeGroup && GetClssCodeData(drvSelectedClssCodeGroup)}
              sx={{ flex: 5 }}
              loading={loadingCodes}
            />

            {/* 우측: 계층코드 상세 */}
            <Stack flex={5} style={{ backgroundColor: '#fff' }}>
              <Box sx={{ display:'flex', alignItems:'center', padding:'4px 8px', borderBottom:'1px solid #ddd' }}>
                <Box fontSize="13px" fontWeight="600" color="#333">● 계층코드 상세</Box>
              </Box>

              <Box sx={{ border:'1px solid #e0e0e0', borderRadius:'4px', padding:'16px', display:'flex', flexDirection:'column', gap:1, flex:1 }}>
                {/* 그룹코드 */}
                <Row label="그룹코드">
                  <TextField size="small" fullWidth value={drvSelectedClssCode?.CLSS_GRP_CD_ID || drvSelectedClssCodeGroup?.CLSS_GRP_CD_ID || ''} InputProps={{ readOnly:true }} />
                </Row>

                {/* 부모코드 */}
                <Row label="부모코드">
                  <TextField size="small" fullWidth value={drvSelectedClssCode?.UP_CLSS_CD_VAL || ''} onChange={(e)=>updateSelectedClssCode({ UP_CLSS_CD_VAL: e.target.value })} />
                </Row>

                {/* 계층코드 */}
                <Row label="계층코드">
                  <TextField size="small" fullWidth value={drvSelectedClssCode?.CLSS_CD_VAL || ''} InputProps={{ readOnly:true }} />
                </Row>

                {/* 사용공통코드 (그룹/명) */}
                <Row label="사용공통코드">
                    <TextField InputProps={{
                            readOnly: true,
                            sx: { backgroundColor: '#f5f5f5' },
                            endAdornment: (
                            <InputAdornment position="end">
                                <IconButton
                                size="small" 
                                edge="end"
                                > 
                                <SearchOutlined />
                                </IconButton>
                            </InputAdornment>
                            )
                        }}
                        size="small" placeholder="GRP_CD_ID" sx={{ width:'40%' }} value={drvSelectedClssCode?.GRP_CD_ID || ''} onChange={(e)=>updateSelectedClssCode({ GRP_CD_ID: e.target.value })} />
                </Row>

                {/* 연결코드 (값/명) */}
                <Row label="연결코드">
                  <TextField size="small" placeholder="CD_VAL_NM" sx={{ flex:1 }} value={drvSelectedClssCode?.CD_VAL_NM || ''} onChange={(e)=>updateSelectedClssCode({ CD_VAL_NM: e.target.value })} />
                </Row>
              </Box>

              <div style={{ display:'flex', justifyContent:'flex-end', gap:8, marginTop:'8px' }}>
                <Button variant="outlined" onClick={BtnCacheDeploy_Click}>Cache Deploy</Button>
                <Button variant="contained" onClick={SaveClssCode} disabled={!hasCodeChanges}>Save</Button>
              </div>
            </Stack>
          </Stack>
        </Box>
      </Stack>
    </div>
  );
}

function Row({ label, children }) {
  return (
    <Box sx={{ display:'flex', alignItems:'center' }}>
      <Box sx={{ minWidth:'100px', fontSize:'12px', color:'#666', bgcolor:'#f5f5f5', padding:'6px 12px', border:'1px solid #e0e0e0', borderRight:'none' }}>{label}</Box>
      <Box sx={{ flex:1, marginLeft:'8px' }}>{children}</Box>
    </Box>
  );
}
