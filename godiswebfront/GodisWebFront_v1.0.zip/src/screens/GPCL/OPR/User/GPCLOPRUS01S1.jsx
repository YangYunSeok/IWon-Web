import React, { useEffect, useState } from 'react';
import { Stack, Box, Button } from '@mui/material';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import GSelectBox from '@/components/GSelectBox';
import GcustomButton, { btnSave } from '@/components/GcustomButton';
import GDataGrid from '@/components/GDataGrid.jsx';
import GSimpleTreeGrid from '@/components/GSimpleTreeGrid';
import CustomGrid from '@/components/GCustomGrid.jsx';
import { http } from '@/libs/TaskHttp';
import { changes } from '@/libs/Utils';
import { useAuth } from '@/context/AuthContext.jsx';

/**
 * 사용자 관리 화면
 * - 좌측: 소속그룹 트리 (GSimpleTreeGrid)
 * - 중앙: 사용자 그리드 (GDataGrid)
 * - 우측: 사용자 상세 정보
 */
export default function GPCLOPRUS01S1() {
	// ==============================================================
	//                        변수 정의
	// ==============================================================
	const { user } = useAuth();
	
	const [groups, setGroups] = useState([]);
	const [selectedGroup, setSelectedGroup] = useState(null);
	const [loadingGroups, setLoadingGroups] = useState(false);

	const [users, setUsers] = useState([]);
	const [selectedUser, setSelectedUser] = useState(null);
	const [loadingUsers, setLoadingUsers] = useState(false);

	const [savingGroup, setSavingGroup] = useState(false);
	const [savingUser, setSavingUser] = useState(false);
	const [hasGroupChanges, setHasGroupChanges] = useState(false);
	const [hasUserChanges, setHasUserChanges] = useState(false);
	const [nextGroupId, setNextGroupId] = useState(1);

	// ==============================================================
	//                        데이터 조회 처리
	// ==============================================================

	const getGroups = async () => {
		try {
			setLoadingGroups(true);
			const param = {};
			const { table } = await http.post('/admin/getusergroups', param, { shape: 'datatable' });

			const mapped = table.map((g, idx) => ({
				id: g.USR_GRP_ID || String(idx),
				...g,
				UP_USR_GRP_ID: g.UP_USR_GRP_ID || null
			}));

			setGroups(mapped);

			// ✅ 기존 그룹 ID 중 최대값 찾기
			const maxId = mapped.reduce((max, group) => {
				const match = group.USR_GRP_ID?.match(/^USRG(\d+)$/);
				if (match) {
					const numericId = parseInt(match[1], 10);
					return Math.max(max, numericId);
				}
				return max;
			}, 0);

			setNextGroupId(maxId + 1);

			// ✅ 기존에 선택된 그룹이 있으면 해당 그룹을 다시 선택
			if (selectedGroup) {
				const restoredGroup = mapped.find(g => g.USR_GRP_ID === selectedGroup.USR_GRP_ID);
				if (restoredGroup) {
					setSelectedGroup(restoredGroup);
					getUsers(restoredGroup.USR_GRP_ID);
				} else if (mapped.length > 0) {
					setSelectedGroup(mapped[0]);
					getUsers(mapped[0].USR_GRP_ID);
				}
			} else if (mapped.length > 0) {
				setSelectedGroup(mapped[0]);
				getUsers(mapped[0].USR_GRP_ID);
			}
		} catch (e) {
			console.error('[소속그룹] 조회 실패', e);
		} finally {
			setLoadingGroups(false);
		}
	};

	const getUsers = async (usrGrpId) => {
		if (!usrGrpId) {
			setUsers([]);
			return;
		}

		try {
			setLoadingUsers(true);
			const param = { USR_GRP_ID: usrGrpId };
			const { table } = await http.post('/admin/getuser', param, { shape: 'datatable' });

			const mapped = table.map((u, idx) => ({ 
				id: u.USR_ID || String(idx), 
				...u 
			}));
			setUsers(mapped);

			if (mapped.length > 0) {
				setSelectedUser(mapped[0]);
			} else {
				setSelectedUser(null);
			}
		} catch (e) {
			console.error('[사용자] 조회 실패', e);
		} finally {
			setLoadingUsers(false);
		}
	};

	useEffect(() => {
		getGroups();
	}, []);

	// ==============================================================
	//                        데이터 저장 처리
	// ==============================================================
	const saveGroup = async () => {
		if (!hasGroupChanges) {
			alert('변경된 데이터가 없습니다.');
			return;
		}

		const changedGroups = groups.filter(g => g.ROW_STATE);

		if (changedGroups.length === 0) {
			alert('변경된 데이터가 없습니다.');
			return;
		}

		if (!window.confirm(`${changedGroups.length}건의 그룹 데이터를 저장하시겠습니까?`)) {
			return;
		}

		try {
			setSavingGroup(true);

			const response = await http.post('/admin/saveusergroups', changedGroups, {
				shape: 'json'
			});

			alert('저장되었습니다.');

			await getGroups();
			
			setHasGroupChanges(false);
		} catch (e) {
			console.error('[그룹 저장 실패]', e);
			alert('저장 중 오류가 발생했습니다: ' + (e.message || ''));
		} finally {
			setSavingGroup(false);
		}
	};

	const saveUser = async () => {
		const changedData = changes(users);
		
		if (changedData.length === 0) {
			alert('변경된 데이터가 없습니다.');
			return;
		}
		
		// ✅ 새로 추가된 사용자(ROW_STATE === 'I') 중 USR_ID 중복 체크 (서버에서)
		const newUsers = changedData.filter(u => u.ROW_STATE === 'I');
		
		for (const newUser of newUsers) {
			if (!newUser.USR_ID || newUser.USR_ID.trim() === '') {
				alert('사용자 ID를 입력해주세요.');
				return;
			}
			
			// ✅ 서버에서 중복 체크
			try {
				const response = await http.post('/admin/checkDuplicateUserId', {
					USR_ID: newUser.USR_ID
				});
				
				if (!response.success) {
					alert('중복 체크 중 오류가 발생했습니다.');
					return;
				}
				
				if (response.isDuplicate) {
					alert(`이미 존재하는 사용자 ID입니다: ${newUser.USR_ID}`);
					return;
				}
			} catch (e) {
				console.error('[중복 체크 실패]', e);
				alert('중복 체크 중 오류가 발생했습니다.');
				return;
			}
		}
		
		if (!window.confirm(`${changedData.length}건의 데이터를 저장하시겠습니까?`)) {
			return;
		}
		
		try {
			setSavingUser(true);
			
			const response = await http.post('/admin/saveuser', changedData, { 
				shape: 'json'
			});
			
			alert('저장되었습니다.');
			
			if (selectedGroup) {
				getUsers(selectedGroup.USR_GRP_ID);
			}
			
			setHasUserChanges(false);
		} catch (e) {
			console.error('[사용자 저장 실패]', e);
			alert('저장 중 오류가 발생했습니다: ' + (e.message || ''));
		} finally {
			setSavingUser(false);
		}
	};

	const resetPassword = async () => {
		if (!selectedUser) return;
		
		if (window.confirm(`${selectedUser.USR_NM || selectedUser.USR_ID}의 비밀번호를 초기화하시겠습니까?`)) {
			try {
				const param = [{
					USR_ID: selectedUser.USR_ID,
					LST_ADJPRN_ID: 'ADMIN'
				}];
				
				const response = await http.post('/admin/saveuserpw', param, {
					shape: 'json'
				});
				
				alert('비밀번호가 초기화되었습니다.');
				
				if (selectedGroup) {
					getUsers(selectedGroup.USR_GRP_ID);
				}
			} catch (e) {
				console.error('[비밀번호 초기화 실패]', e);
				alert('비밀번호 초기화 중 오류가 발생했습니다: ' + (e.message || ''));
			}
		}
	};

	// ==============================================================
	//                  관리자 로그인 처리
	// ==============================================================
	const handleManagerLogin = async () => {
		if (!selectedUser) {
			alert('선택된 사용자가 없습니다.');
			return;
		}

		if (!window.confirm(`${selectedUser.USR_NM || selectedUser.USR_ID}(으)로 로그인하시겠습니까?`)) {
			return;
		}

		try {
			// 1. 임시 토큰 생성
			const response = await http.post('/admin/createManagerLoginToken', {
				USR_ID: selectedUser.USR_ID,
				USR_NM: selectedUser.USR_NM
			});

			if (!response.success) {
				alert('토큰 생성 실패: ' + response.message);
				return;
			}

			const token = response.token;

			// 2. 새 탭 열기
			const newTabUrl = `${window.location.origin}/auto-login?token=${token}`;
			window.open(newTabUrl, '_blank');

			alert('관리자 로그인 성공');

		} catch (e) {
			console.error('[관리자 로그인 실패]', e);
			alert('관리자 로그인 실패: ' + (e.message || ''));
		}
	};

	// ==============================================================
	//                        이벤트 정의
	// ==============================================================
	const handleGroupSelect = (group) => {
		if (selectedGroup?.USR_GRP_ID === group.USR_GRP_ID) {
			return;
		}
		
		setSelectedGroup(group);
		getUsers(group.USR_GRP_ID);
	};

	const handleUserSelect = (user) => {
		setSelectedUser(user);
	};

	const createNewUserRow = () => {
		const today = dayjs().format('YYYYMMDD');
		const tempId = `temp_${Date.now()}`; // ✅ 임시 ID 생성
		return {
			id: tempId, // ✅ id 추가
			USR_ID: '',
			USR_NM: '',
			USR_GRP_ID: selectedGroup?.USR_GRP_ID || '',
			USR_GRP_NM: selectedGroup?.USR_GRP_NM || '',
			JOBTITL_NM: '',
			USR_STAT_CD: 'N',
			VALID_STRT_DD: today,
			VALID_END_DD: '99991231',
			PW_ERR_CNT: 0
		};
	};

	const createNewGroupRow = (parentGroup) => {
		const newGroupId = `USRG${String(nextGroupId).padStart(6, '0')}`;
		setNextGroupId(prev => prev + 1);
		
		return {
			USR_GRP_ID: newGroupId,
			USR_GRP_NM: '새 그룹',
			UP_USR_GRP_ID: parentGroup?.USR_GRP_ID || null
		};
	};

	const generateNewGroupId = () => {
		const newGroupId = `USRG${String(nextGroupId).padStart(6, '0')}`;
		setNextGroupId(prev => prev + 1);
		return newGroupId;
	};

	const handleGroupRowsChange = (newRows) => {
		setGroups(newRows);
		
		// 새로 추가된 행 자동 선택
		if (newRows.length > groups.length) {
			const newGroup = newRows[newRows.length - 1];
			setSelectedGroup(newGroup);
			setUsers([]);
		}
	};

	const handleUserStatusChange = (newStatus) => {
		if (!selectedUser) return;
		const today = dayjs().format('YYYYMMDD');
		let updatedUser = { ...selectedUser, USR_STAT_CD: newStatus };
		if (newStatus === 'E') {
			updatedUser.VALID_END_DD = today;
		} else if (selectedUser.USR_STAT_CD === 'E' && newStatus === 'A') {
			updatedUser.VALID_END_DD = '99991231';
		}
		
		if (updatedUser.ROW_STATE !== 'I') {
			updatedUser.ROW_STATE = 'U';
		}
		
		setSelectedUser(updatedUser);
		
		setUsers(users.map(u => 
			u.id === selectedUser.id ? updatedUser : u
		));
		setHasUserChanges(true);
	};

	const handleUserGroupChange = (newGroupId) => {
		if (!selectedUser) return;
		
		const newGroup = groups.find(g => g.USR_GRP_ID === newGroupId);
		
		const updatedUser = { 
			...selectedUser, 
			USR_GRP_ID: newGroupId,
			USR_GRP_NM: newGroup?.USR_GRP_NM || '',
			ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
		};
		
		setSelectedUser(updatedUser);
		
		setUsers(users.map(u => 
			u.id === selectedUser.id ? updatedUser : u
		));
		setHasUserChanges(true);
	};

	// ==============================================================
	//                        그리드 컬럼 정의
	// ==============================================================
	const userColumns = [
		{
			headerName: 'ID',
			headerAlign: 'center',
			field: 'USR_ID',
			width: 150,
			editable: false
		},
		{
			headerName: '이름',
			headerAlign: 'center',
			field: 'USR_NM',
			width: 150,
			editable: false
		},
		{
			headerName: '직위',
			headerAlign: 'center',
			field: 'JOBTITL_NM',
			flex: 1,
			editable: false,
			align: 'center'
		}
	];

	// ==============================================================
	//                   사용자 입력 필드 정의
	// ==============================================================
	const userFields = [
		{
			label: 'ID',
			type: 'text',
			name: 'USR_ID',
			value: selectedUser?.USR_ID || '',
			readOnly: selectedUser?.ROW_STATE !== 'I',
			onChange: (e) => {
				const updatedUser = { 
					...selectedUser, 
					USR_ID: e.target.value,
					ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
				};
				setSelectedUser(updatedUser);
				setUsers(users.map(u =>
					u.id === selectedUser.id ? updatedUser : u
				));
				setHasUserChanges(true);
			}
		},
		{
			label: '사용자명',
			type: 'text',
			name: 'USR_NM',
			value: selectedUser?.USR_NM || '',
			readOnly: !selectedUser,
			onChange: (e) => {
				const updatedUser = { 
					...selectedUser, 
					USR_NM: e.target.value,
					ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
				};
				setSelectedUser(updatedUser);
				setUsers(users.map(u =>
					u.id === selectedUser.id ? updatedUser : u
				));
				setHasUserChanges(true);
			}
		},
		{
			label: '소속그룹',
			type: 'dataselect',
			name: 'USR_GRP_ID',
			value: selectedUser?.USR_GRP_ID || '',
			readOnly: !selectedUser,
			onChange: (value) => handleUserGroupChange(value),
			options: groups.map(g => ({
				label: g.USR_GRP_NM,
				value: g.USR_GRP_ID
			}))
		},
		{
			label: '직위',
			type: 'text',
			name: 'JOBTITL_NM',
			value: selectedUser?.JOBTITL_NM || '',
			readOnly: !selectedUser,
			onChange: (e) => {
				const updatedUser = { 
					...selectedUser, 
					JOBTITL_NM: e.target.value,
					ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
				};
				setSelectedUser(updatedUser);
				setUsers(users.map(u =>
					u.id === selectedUser.id ? updatedUser : u
				));
				setHasUserChanges(true);
			}
		},
		{
			label: '사용자상태',
			type: 'codeselect',
			name: 'USR_STAT_CD',
			grpCdId: 'USR_STAT_CD',
			value: selectedUser?.USR_STAT_CD || '',
			readOnly: !selectedUser,
			onChange: (value) => handleUserStatusChange(value)
		},
		{
			label: '로그인실패횟수',
			type: 'text',
			name: 'PW_ERR_CNT',
			value: selectedUser?.PW_ERR_CNT ?? 0,
			readOnly: true,
			actionButton: {
				label: 'Reset Password',
				onClick: resetPassword,
				readOnly: !selectedUser  // ✅ disabled 대신 readOnly
			}
		},
		{
			label: '적용일',
			type: 'date',
			name: 'VALID_STRT_DD',
			value: selectedUser?.VALID_STRT_DD || '',
			readOnly: !selectedUser,
			onChange: (dateStr) => {
				if (!selectedUser) return;
				
				// 빈 값이면 검증 없이 바로 적용
				if (!dateStr) {
					const updatedUser = { 
						...selectedUser, 
						VALID_STRT_DD: '',
						ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
					};
					setSelectedUser(updatedUser);
					setUsers(users.map(u => 
						u.id === selectedUser.id ? updatedUser : u
					));
					setHasUserChanges(true);
					return;
				}
				
				// 값이 있을 때만 검증
				if (selectedUser.VALID_END_DD && dateStr > selectedUser.VALID_END_DD) {
					alert('적용일은 만료일보다 이후일 수 없습니다.');
					return;
				}
				
				const updatedUser = { 
					...selectedUser, 
					VALID_STRT_DD: dateStr,
					ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
				};
				
				setSelectedUser(updatedUser);
				setUsers(users.map(u => 
					u.id === selectedUser.id ? updatedUser : u
				));
				setHasUserChanges(true);
			}
		},
		{
			label: '만료일',
			type: 'date',
			name: 'VALID_END_DD',
			value: selectedUser?.VALID_END_DD || '',
			readOnly: !selectedUser,
			onChange: (dateStr) => {
				if (!selectedUser) return;
				
				// 빈 값이면 검증 없이 바로 적용
				if (!dateStr) {
					const updatedUser = { 
						...selectedUser, 
						VALID_END_DD: '',
						ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
					};
					setSelectedUser(updatedUser);
					setUsers(users.map(u => 
						u.id === selectedUser.id ? updatedUser : u
					));
					setHasUserChanges(true);
					return;
				}
				
				// 값이 있을 때만 검증
				if (selectedUser.VALID_STRT_DD && dateStr < selectedUser.VALID_STRT_DD) {
					alert('만료일은 적용일보다 이전일 수 없습니다.');
					return;
				}
				
				const updatedUser = { 
					...selectedUser, 
					VALID_END_DD: dateStr,
					ROW_STATE: selectedUser.ROW_STATE === 'I' ? 'I' : 'U'
				};
				
				setSelectedUser(updatedUser);
				setUsers(users.map(u => 
					u.id === selectedUser.id ? updatedUser : u
				));
				setHasUserChanges(true);
			}
		}
	];

	// ==============================================================
	//                   그룹 입력 필드 정의
	// ==============================================================
	const groupFields = [
		{
			label: '그룹ID',
			type: 'text',
			name: 'USR_GRP_ID',
			value: selectedGroup?.USR_GRP_ID || '',
			readOnly: true  // ✅ 그룹ID는 항상 readOnly
		},
		{
			label: '그룹명',
			type: 'text',
			name: 'USR_GRP_NM',
			value: selectedGroup?.USR_GRP_NM || '',
			readOnly: !selectedGroup,  // ✅ disabled 대신 readOnly
			onChange: (e) => {
				const updatedGroup = { 
					...selectedGroup, 
					USR_GRP_NM: e.target.value,
					ROW_STATE: selectedGroup.ROW_STATE === 'I' ? 'I' : 'U'
				};
				setSelectedGroup(updatedGroup);
				setGroups(groups.map(g =>
					g.USR_GRP_ID === selectedGroup.USR_GRP_ID
						? updatedGroup
						: g
				));
				setHasGroupChanges(true);
			}
		}
	];

	// ==============================================================
	//                          화면구성 영역
	// ==============================================================
	return (
		<LocalizationProvider dateAdapter={AdapterDayjs}>
			<div style={{ padding: '8px' }}>
				<Stack spacing={2}>
					{/* 상단: 소속그룹 영역 */}
					<Box sx={{ border: '2px solid #4472C4', padding: '8px', backgroundColor: '#fff', borderRadius: '4px' }}>
						<Stack direction="row" spacing={2} height={380}>
							{/* 좌측: 소속그룹 트리 */}
							<GSimpleTreeGrid
								rows={groups}
								onRowsChange={handleGroupRowsChange}
								idField="USR_GRP_ID"
								parentIdField="UP_USR_GRP_ID"
								labelField="USR_GRP_NM"
								columnLabel="사용자그룹명"
								createNewRow={createNewGroupRow}
								generateNewId={generateNewGroupId}
								title="소속그룹"
								selectedItem={selectedGroup}
								onSelectedItemChange={handleGroupSelect}
								onHasChanges={setHasGroupChanges}
								Buttons={{ add: true, delete: true, revert: true, excel: false }}
								onRevertClick={getGroups}
								sx={{ flex: 4 }}
							/>

							{/* 우측: 사용자 그룹 정보 */}
							<Stack flex={6} style={{ backgroundColor: '#fff' }}>
								<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: '4px 8px', marginBottom: '8px', borderBottom: '1px solid #ddd' }}>
									<Box fontSize="13px" fontWeight="600" color="#333">● 사용자 그룹 정보</Box>
								</Box>
								<Box sx={{ border: '1px solid #e0e0e0', borderRadius: '4px', padding: '16px', flex: 1, display: 'flex', flexDirection: 'column' }}>
									<CustomGrid columns={1} fields={groupFields} />
								</Box>
								<div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'auto' }}>
									<GcustomButton
										showAdd={false}
										showDelete={false}
										showRevert={false}
										showExcel={false}
										showSave={true}
										onSave={saveGroup}
										saveLoading={savingGroup || !hasGroupChanges}
									/>
								</div>
							</Stack>
						</Stack>
					</Box>

					{/* 하단: 사용자 영역 */}
					<Box sx={{ border: '2px solid #4472C4', padding: '8px', backgroundColor: '#fff', borderRadius: '4px' }}>
						<Stack direction="row" spacing={2} height={380}>
							{/* 좌측: 사용자 목록 (GDataGrid) */}
							<Stack flex={4}>
								<GDataGrid
									title={`사용자 Total (${users.length})`}
									showTitle={true}
									rows={users}
									columns={userColumns}
									onRowsChange={(newRows) => {
										setUsers(newRows);
										
										// ✅ 새로 추가된 행들 찾기
										if (newRows.length > users.length) {
											const newUsers = newRows.filter(u => 
												u.ROW_STATE === 'I' && !users.find(existing => existing.id === u.id)
											);
											
											if (newUsers.length > 0) {
												// 여러 개 추가되면 마지막 것 선택
												setSelectedUser(newUsers[newUsers.length - 1]);
											}
										}
										
										setHasUserChanges(true);
									}}
									Buttons={{ add: true, delete: true, revert: true, excel: false }}
									createNewRow={createNewUserRow}
									onRevertClick={() => {
										if (selectedGroup) {
											getUsers(selectedGroup.USR_GRP_ID);
										}
									}}
									height={380}
									columnHeaderHeight={30}
									rowHeight={25}
									checkboxSelection
									disableRowSelectionOnClick
									pagination={false}
									hideFooter
									onRowClick={(params) => handleUserSelect(params.row)}
									loading={loadingUsers}
									enableRowState={true}
								/>
							</Stack>

							{/* 우측: 사용자 상세 정보 */}
							<Stack flex={6} style={{ backgroundColor: '#fff' }}>
								<Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: '4px 8px', marginBottom: '8px', borderBottom: '1px solid #ddd' }}>
									<Box fontSize="13px" fontWeight="600" color="#333">● 사용자 정보</Box>
								</Box>
								<Box sx={{ border: '1px solid #e0e0e0', borderRadius: '4px', padding: '16px', flex: 1, display: 'flex', flexDirection: 'column' }}>
									<CustomGrid columns={2} fields={userFields} />
								</Box>
								<div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 'auto', gap: 8 }}>
									<Button
										variant="contained"
										onClick={handleManagerLogin}
										disabled={!selectedUser}
										sx={{
											...btnSave,
											minWidth: 100,
											backgroundColor: '#1976d2',
											'&:hover': { bgcolor: '#1565c0' }
										}}
									>
										관리자로그인
									</Button>
									<GcustomButton
										showAdd={false}
										showDelete={false}
										showRevert={false}
										showExcel={false}
										showSave={true}
										onSave={saveUser}
										saveLoading={savingUser || !hasUserChanges}
									/>
								</div>
							</Stack>
						</Stack>
					</Box>
				</Stack>
			</div>
		</LocalizationProvider>
	);
}