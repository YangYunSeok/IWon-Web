import React, { useEffect, useMemo, useState, useRef } from 'react';
import { Card, Input, Button, Space, message, Table } from 'antd';
import { Box, TextField, MenuItem, RadioGroup, FormControlLabel, Radio, Select, Grid } from '@mui/material';

import EditableTable from '@/components/EditableTable.jsx';
import GSelectBox  from '@/components/GSelectBox.jsx';
import CommonRadio   from '@/components/CommonRadio.jsx';


// SearchHeader 컴포넌트
import SearchHeader from '@/components/GSearchHeader.jsx';

// CustomGrid 컴포넌트
import CustomGrid from '@/components/GCustomGrid.jsx';

export default function GPCLOPRTESTS1() {
  // 검색바 상태
  const [grpNm, setGrpNm] = useState('');
  const [grpType, setGrpType] = useState('ALL'); // UI 필터 (백엔드 파라미터 아님)
  const [status, setStatus] = useState('Y'); // 초기값 'Y'
  
  // 누락된 상태 변수들 추가
  const [groups, setGroups] = useState([]);
  const [loadingGroups, setLoadingGroups] = useState(false);
  const [selectedGrpId, setSelectedGrpId] = useState(null);

  // SearchHeader용 폼 상태
  const [filters, setFilters] = useState({
    email: '',
    role: '',
    status: 'active',
    gender: '',
  });

  const handleChange = (e) => {
    setFilters({ ...filters, [e.target.name]: e.target.value });
  };

  const handleInitialize = () => {
    setFilters({ email: '', role: '', status: 'active', gender: '' });
  };

  const handleSearch = () => {
    console.log('조회 조건:', filters);
  };

  const ROLE_OPTIONS = [
    { label: '전체', value: '' },
    { label: '관리자', value: 'admin' },
    { label: '사용자', value: 'user' },
  ];

  const STATUS_OPTIONS = [
    { label: '활성', value: 'active' },
    { label: '비활성', value: 'inactive' },
  ];

  const GENDER_OPTIONS = [
    { label: '전체', value: '' },
    { label: '남성', value: 'M' },
    { label: '여성', value: 'F' },
  ];

  // CustomGrid용 데이터
  const items = [
    { header: '이메일', content: <TextField size="small" fullWidth /> },
    { header: '권한', content: (
        <Select size="small" fullWidth defaultValue="">
          <MenuItem value="">전체</MenuItem>
          <MenuItem value="admin">관리자</MenuItem>
          <MenuItem value="user">사용자</MenuItem>
        </Select>
      )
    },
    { header: '상태1', content: (
        <RadioGroup row defaultValue="active">
          <FormControlLabel value="active" control={<Radio size="small" />} label="활성" />
          <FormControlLabel value="inactive" control={<Radio size="small" />} label="비활성" />
        </RadioGroup>
      )
    },
    { header: '상태2', content: (
        <RadioGroup row fullWidth defaultValue="active">
          <FormControlLabel value="active" control={<Radio size="small" />} label="활성" />
          <FormControlLabel value="inactive" control={<Radio size="small" />} label="비활성" />
        </RadioGroup>
      )
    },
  ];

  const fields = [
      { label: '이메일', type: 'text', name: 'email', value: filters.email, onChange: handleChange },
      { label: '권한', type: 'select', name: 'role', value: filters.role, onChange: handleChange, options: ROLE_OPTIONS },
      { label: '상태', type: 'radio', name: 'status', value: filters.status, onChange: handleChange, options: STATUS_OPTIONS },
      { label: '성별', type: 'select', name: 'gender', value: filters.gender, onChange: handleChange, options: GENDER_OPTIONS },
      {},
      {}
  ];


  const getGroups = async () => {
    try {
      setLoadingGroups(true);
      const q = grpNm ? `?grpNm=${encodeURIComponent(grpNm)}` : '';
      const res = await fetch(`/api/admin/getgroups${q}`);

      console.log(res);

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const list = await res.json();

      console.log(list);

      // 프론트 단 그룹유형 필터
      const filtered = (grpType && grpType !== 'ALL')
        ? list.filter(g => (g.grpTypeCd || '').toUpperCase() === grpType)
        : list;

      const mapped = filtered.map((g, idx) => ({
        key: g.grpCdId || String(idx),
        ...g,
      }));
      setGroups(mapped);

      // 최초 로드 시 선택 없으면 첫 행 기준으로 하단 조회
      if (!selectedGrpId && mapped.length > 0) {
        setSelectedGrpId(mapped[0].grpCdId ?? mapped[0].key);
      }
    } catch (e) {
      console.error('[공통코드] 그룹 조회 실패', e);
      message.error('그룹 목록을 불러오지 못했습니다.');
    } finally {
      setLoadingGroups(false);
    }
  };

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const [emailError, setEmailError] = useState(false);

  const emailHandleChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({ ...prev, [name]: value }));

    if (name === 'email') {
      setEmailError(value && !emailRegex.test(value)); // 형식 오류 검사
    }
  };

  return (
    <div>
      <SearchHeader
        fields={[
          {
            header: '이메일',
            content: (
              <TextField
              fullWidth
                name="email"
                value={filters.email}
                onChange={emailHandleChange}
                placeholder="이메일 입력"
                error={emailError}
                helperText={emailError ? '올바른 이메일 주소를 입력하세요.' : ''}
              />
            ),
          },
          {
            header: '권한',
            content: (
              <Select
                fullWidth
                name="role"
                value={filters.role}
                onChange={handleChange}
              >
                {ROLE_OPTIONS.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </MenuItem>
                ))}
              </Select>
            ),
          },
          {
            header: '상태',
            content: (
              <RadioGroup
                row
                name="status"
                value={filters.status}
                onChange={handleChange}
              >
                {STATUS_OPTIONS.map((opt) => (
                  <FormControlLabel
                    key={opt.value}
                    value={opt.value}
                    control={<Radio />}
                    label={opt.label}
                  />
                ))}
              </RadioGroup>
            ),
          },
          {
            header: '성별',
            content: (
              <Select
                fullWidth
                name="gender"
                value={filters.gender}
                onChange={handleChange}
              >
                {GENDER_OPTIONS.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </MenuItem>
                ))}
              </Select>
            ),
          },
        ]}
        onInitialize={handleInitialize}
        onSearch={handleSearch}
      />

      <SearchHeader
        fields={[
          {
            header: '이메일',
            content: (
              <TextField
                fullWidth
                name="email"
                value={filters.email}
                onChange={emailHandleChange}
                placeholder="이메일 입력"
                error={emailError}
                helperText={emailError ? '올바른 이메일 주소를 입력하세요.' : ''}
              />
            ),
          },
          {
            header: '권한',
            content: (
              <Select
                fullWidth
                name="role"
                value={filters.role}
                onChange={handleChange}
              >
                {ROLE_OPTIONS.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </MenuItem>
                ))}
              </Select>
            ),
          },
          {
            header: '상태',
            content: (
              <RadioGroup
                row
                name="status"
                value={filters.status}
                onChange={handleChange}
              >
                {STATUS_OPTIONS.map((opt) => (
                  <FormControlLabel
                    key={opt.value}
                    value={opt.value}
                    control={<Radio />}
                    label={opt.label}
                  />
                ))}
              </RadioGroup>
            ),
          },
          {
            header: '성별',
            content: (
              <Select
                fullWidth
                name="gender"
                value={filters.gender}
                onChange={handleChange}
              >
                {GENDER_OPTIONS.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </MenuItem>
                ))}
              </Select>
            ),
          },
          {
            header: '성별2',
            content: (
              <Select
                fullWidth
                name="gender"
                value={filters.gender}
                onChange={handleChange}
              >
                {GENDER_OPTIONS.map((opt) => (
                  <MenuItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </MenuItem>
                ))}
              </Select>
            ),
          },
          {},
          {},
          {}
        ]}
        onInitialize={handleInitialize}
        onSearch={handleSearch}
      />
      
      {/* <SearchHeader
        fields={[
          { label: '이메일', type: 'text', name: 'email', value: filters.email, onChange: handleChange },
          { label: '권한', type: 'select', name: 'role', value: filters.role, onChange: handleChange, options: ROLE_OPTIONS },
          { label: '상태', type: 'radio', name: 'status', value: filters.status, onChange: handleChange, options: STATUS_OPTIONS },
          { label: '성별', type: 'select', name: 'gender', value: filters.gender, onChange: handleChange, options: GENDER_OPTIONS },
        ]}
        onInitialize={handleInitialize}
        onSearch={handleSearch}
      /> */}

      {/* <SearchHeader
        fields={[
          { label: '이메일', type: 'text', name: 'email', value: filters.email, onChange: handleChange },
          { label: '권한', type: 'select', name: 'role', value: filters.role, onChange: handleChange, options: ROLE_OPTIONS },
          { label: '상태', type: 'radio', name: 'status', value: filters.status, onChange: handleChange, options: STATUS_OPTIONS },
          { label: '성별', type: 'select', name: 'gender', value: filters.gender, onChange: handleChange, options: GENDER_OPTIONS },
          { label: '이메일2', type: 'text', name: 'email', value: filters.email, onChange: handleChange },
          { label: '권한2', type: 'select', name: 'role', value: filters.role, onChange: handleChange, options: ROLE_OPTIONS },
          {}, // 빈칸 입력시 공백
          {}
        ]}
        onInitialize={handleInitialize}
        onSearch={handleSearch}
      /> */}

      <CustomGrid columns={4} fields={fields} />

      <CustomGrid columns={3} fields={fields} />

      {/* 검색 바 */}
      <Card size="small" title="Select Box" style={{ marginBottom: 8 }}>
        <Space align="center" wrap>
          <Space.Compact>
            <Input
              value={grpNm}
              onChange={(e) => setGrpNm(e.target.value)}
              onPressEnter={getGroups}
              placeholder="그룹코드명"
              style={{ width: 200 }}
              performanceMode="large"
            />
            <GSelectBox
              grpCdId="GRP_TP_CD" // 상태코드 그룹
              value={grpType}
              onChange={setGrpType}
              includeAll={true}
              allLabel="-- All --"
              performanceMode="large"
              width={160}
            />
          </Space.Compact>
          <Button auth="Search" type="primary" onClick={getGroups}>Search</Button>
        </Space>

        <div style={{ marginTop: 16 }}>
          <p>그룹명: <strong>{grpNm || '(비어있음)'}</strong></p>
          <p>그룹타입: <strong>{grpType}</strong></p>
          <p>조회된 그룹 수: <strong>{groups.length}개</strong></p>
        </div>
      </Card>

      {groups.length > 0 && (
        <Card size="small" title={`조회 결과 (${groups.length}개)`}>
          <Table
            dataSource={groups}  // 모든 데이터
            size="small"
            pagination={false}   // 페이징 없이
            scroll={{ y: 200 }}  // 200px 높이에서 스크롤
            columns={[
              {
                title: '그룹ID',
                dataIndex: 'grpCdId',
                key: 'grpCdId',
                width: 120,
              },
              {
                title: '그룹명',
                dataIndex: 'grpNm',
                key: 'grpNm',
                width: 200,
              },
              {
                title: '타입',
                dataIndex: 'grpTypeCd',
                key: 'grpTypeCd',
                width: 100,
              },
              {
                title: '사용여부',
                dataIndex: 'useYn',
                key: 'useYn',
                width: 80,
              },
            ]}
          />
        </Card>
      )}

      {/* Radio Button 테스트 */}
      <Card size="small" title="Radio Button" style={{ marginBottom: 16 }}>
        <Space direction="vertical" style={{ width: '100%' }}>
          <div style={{ marginBottom: 2 }}>
            <label>상태 (문자열 가로 방향): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={['활성', '비활성', '대기']}
            />
          </div>
          
          <div style={{ marginBottom: 2 }}>
            <label>상태 (문자열 세로 방향): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={['활성', '비활성', '대기']}
              direction="vertical"
            />
          </div>

          <div style={{ marginBottom: 2 }}>
            <label>상태 (객체 배열): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={[
                { label: '활성', value: 'Y' },
                { label: '비활성', value: 'N' },
                { label: '대기', value: 'W' }
              ]}
            />
          </div>

          <div style={{ marginBottom: 2 }}>
            <label>상태 (버튼 스타일): </label>
            <CommonRadio
              value={status}
              onChange={setStatus}
              options={[
                { label: '활성', value: 'Y' },
                { label: '비활성', value: 'N' },
                { label: '대기', value: 'W' }
              ]}
              buttonStyle={true}
            />
          </div>

          
        </Space>
        
        {/* 현재 값 표시 */}
        <div style={{ marginTop: 16 }}>
          <p>선택된 상태: <strong>{status}</strong></p>
        </div>
      </Card>
    </div>
  );
}
