// GPCLOPRMT01S1.jsx
import React, { useEffect, useState } from 'react';
import {
  Box,
  Grid,
  TextField,
  Button,
  MenuItem,
  InputLabel,
  FormControl,
  Typography,
  Paper,
  Stack,
  Select,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  IconButton,
  InputAdornment,
} from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { DataGrid } from "@mui/x-data-grid";
import { message } from "antd";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import dayjs from "dayjs";

import GDataTreeGrid from "@/components/GDataTreeGrid.jsx";
import { http } from "@/libs/TaskHttp";

export default function GPCLOPRMT01S1() {
  // ==============================================================  
  // 상태 변수 정의  
  // ==============================================================  
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [startDate, setStartDate] = useState(dayjs());
  const [status, setStatus] = useState("");
  const [executor, setExecutor] = useState("");
  const [groupName, setGroupName] = useState("");
  const [execType, setExecType] = useState("");
  const [resultMessage, setResultMessage] = useState("조회 결과가 없습니다.");
  const [loadingGroups, setLoadingGroups] = useState(false);
  const [groups, setGroups] = useState([]);
  const [selectedGrpId, setSelectedGrpId] = useState(null);

  // ✅ 사용자 검색 관련 상태
  const [openUserModal, setOpenUserModal] = useState(false);
  const [userList, setUserList] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [userSearch, setUserSearch] = useState("");

  // ✅ 상세 모달 관련 상태
  const [openDetailModal, setOpenDetailModal] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [resultInfo, setResultInfo] = useState(null);
  const [detailLogs, setDetailLogs] = useState([]);
  const [exceptionText, setExceptionText] = useState("");

  // ==============================================================  
  // 컬럼 정의  
  // ==============================================================  
  const columns = [
    { field: "TASK_GRP_NM", headerName: "작업명", width: 300 },
    { field: "TASK_ID", headerName: "작업ID", width: 150 },
    { field: "TASK_SEQ", headerName: "순서", width: 100 },
    { field: "REG_NM", headerName: "실행요청자", width: 150 },
    { field: "EXECUTE_PARM_VAL", headerName: "Argument", width: 250 },
    { field: "EXECUTE_STAT_NM", headerName: "상태", width: 120 },
    { field: "FOLLW_TASK_CNT", headerName: "하위성공", width: 120 },
    { field: "TASK_CNT", headerName: "작업성공", width: 120 },
    { field: "TOTAL_CNT", headerName: "데이터성공", width: 120 },
    { field: "STRT_DDTM", headerName: "작업시작일시", width: 180 },
    { field: "END_DDTM", headerName: "작업종료일시", width: 180 },
    { field: "EXEC_MI", headerName: "소요시간", width: 100 },
    {
      field: "ETC",
      headerName: "",
      width: 130,
      renderCell: (params) => {
        const { EXECUTE_TP_CD, EXECUTE_STAT_CD } = params.row;

        if (EXECUTE_TP_CD === "00" && EXECUTE_STAT_CD === "08") {
          return (
            <Button
              variant="contained"
              color="primary"
              size="small"
              onClick={() => handleDetailClick(params.row)}
            >
              Detail
            </Button>
          );
        }

        if (EXECUTE_TP_CD === "00" && EXECUTE_STAT_CD === "01") {
          return null;
        }

        if (
          ["01", "02", "03", "04"].includes(EXECUTE_TP_CD) &&
          ["08", "09", "07"].includes(EXECUTE_STAT_CD)
        ) {
          return (
            <Button variant="outlined" size="small" disabled>
              ForceEnd
            </Button>
          );
        }

        if (EXECUTE_TP_CD === "10") {
          return null;
        }

        return null;
      },
    },
    { field: "SEQ_KEY", headerName: "", width: 100, hide: true },
    { field: "GRP_SEQ", headerName: "", width: 100, hide: true },
    { field: "EXECUTE_GRP_SEQ", headerName: "", width: 100, hide: true },
    { field: "EXECUTE_TASK_SEQ", headerName: "", width: 100, hide: true },
    { field: "EXECUTE_TP_CD", headerName: "", width: 100, hide: true },
    { field: "EXECUTE_STAT_CD", headerName: "", width: 100, hide: true },
    { field: "DATA_FAIL_CNT", headerName: "", width: 100, hide: true },
    { field: "DATA_FAIL_YN", headerName: "", width: 100, hide: true },
    { field: "FOLLW_TASK_IDS", headerName: "", width: 100, hide: true },
    { field: "PARENT_TASK_IDS", headerName: "", width: 100, hide: true },
    { field: "TOT_CNT", headerName: "", width: 100, hide: true },
  ];

  const columnGroupingModel = [
    {
      groupId: "작업정보",
      children: [
        { field: "TASK_ID" },
        { field: "TASK_SEQ" },
        { field: "REG_NM" },
        { field: "EXECUTE_PARM_VAL" },
      ],
    },
    {
      groupId: "작업결과",
      children: [
        { field: "EXECUTE_STAT_NM" },
        { field: "FOLLW_TASK_CNT" },
        { field: "TASK_CNT" },
        { field: "TOTAL_CNT" },
      ],
    },
    {
      groupId: "작업",
      children: [
        { field: "STRT_DDTM" },
        { field: "END_DDTM" },
        { field: "EXEC_MI" },
      ],
    },
  ];

  // ==============================================================  
  // 데이터 조회 함수  
  // ==============================================================  
  const getBatchGroups = async () => {
    try {
      setLoadingGroups(true);

      const param = {
        SEARCH_DD: "20240321",
        EXECUTE_STAT_CD: "08",
        SEARCH_GRP_NM: groupName,
        SEARCH_ID: executor,
        AUTO_FLAG: "N",
        EXECUTE_TP_CD: execType,
        SEARCH_EXEC_SEQ: 0,
        SEARCH_TOTAL: "N",
        OFFSET: 0,
      };

      const { name, table } = await http.post("/admin/getbatchgroups", param, { shape: "datatable" });
      const treeData = buildTree(table);
      setGroups(treeData);

      if (table && table.length > 0) {
        setResultMessage(`${table.length}건이 조회되었습니다.`);
        message.info(`${table.length}건이 조회되었습니다.`);
        setSelectedGrpId(table[0]);
      } else {
        setResultMessage("조회 결과가 없습니다.");
        message.warning("조회 결과가 없습니다.");
      }
    } catch (e) {
      console.error("[배치모니터링] 그룹 조회 실패", e);
      message.error("그룹 목록을 불러오지 못했습니다.");
    } finally {
      setLoadingGroups(false);
    }
  };

  useEffect(() => {
    getBatchGroups();
  }, []);

  // ==============================================================  
  // 초기화 함수  
  // ==============================================================  
  const handleReset = () => {
    setStartDate(null);
    setStatus("");
    setExecutor("");
    setGroupName("");
    setExecType("");
    setRows([]);
    setResultMessage("조회 결과가 없습니다.");
  };

  // ==============================================================  
  // DEPTH 기반 트리 구조 변환 함수  
  // ==============================================================  
  const buildTree = (flatRows) => {
    const tree = [];
    const stack = [];

    flatRows.forEach((node) => {
      const currentDepth = node.DEPTH || 0;

      while (stack.length > 0 && stack[stack.length - 1].DEPTH >= currentDepth) {
        stack.pop();
      }

      if (stack.length === 0) {
        tree.push(node);
      } else {
        const parent = stack[stack.length - 1];
        if (!parent.children) parent.children = [];
        parent.children.push(node);
      }

      stack.push(node);
    });

    return tree;
  };

  // ==============================================================  
  // 사용자 검색 관련 함수  
  // ==============================================================  
  const handleSearchClick = (searchValue) => {
    const q = typeof searchValue === "string" ? searchValue : executor || "";
    setUserList([]);
    setUserSearch(q);
    setOpenUserModal(true);
  };

  const handleUserSelect = () => {
    if (selectedUser) {
      setExecutor(selectedUser.USR_NM);
    }
    setOpenUserModal(false);
  };

  // ==============================================================  
  // 팝업 관련 함수  
  // ==============================================================  
  const handleDetailClick = async (row) => {
    setSelectedRow(row);
    setOpenDetailModal(true);

    try {
      setLoading(true);
      const param = { EXECUTE_TASK_SEQ: row.EXECUTE_TASK_SEQ };
      const result = await http.post("/admin/getexcpdtllog", param);

      console.log("Detail Param =>", row.EXECUTE_TASK_SEQ);

      setResultInfo(result.dtExcptDtlLog || {});
      setDetailLogs(result.dtExcptDtlLogList || []);
      setExceptionText(result.dtExcptDtlLog?.EXECUTE_RSLT_CONTN || "");
    } catch (e) {
      console.error("상세 조회 실패", e);
      message.error("상세 정보를 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  };

  const handleCloseDetailModal = () => {
    setOpenDetailModal(false);
    setSelectedRow(null);
    setResultInfo(null);
    setDetailLogs([]);
    setExceptionText("");
  };

  // ==============================================================  
  // 화면 구성  
  // ==============================================================  
  return (
    <Box p={2}>
      <Typography variant="h6" sx={{ mb: 2 }}>
        배치작업모니터링
      </Typography>

      <Paper sx={{ p: 2.5, mb: 2 }}>
        <Grid container spacing={2} alignItems="center">
          {/* 실행일자 */}
          <Grid item xs={12} sm={6} md={3}>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                label="실행일자"
                value={startDate}
                onChange={(newValue) => setStartDate(newValue)}
                format="YYYY-MM-DD"
                slotProps={{ textField: { fullWidth: true, size: "small" } }}
              />
            </LocalizationProvider>
          </Grid>

          {/* 처리상태 */}
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth size="small" sx={{ minWidth: 130 }}>
              <InputLabel>처리상태</InputLabel>
              <Select value={status} label="처리상태" onChange={(e) => setStatus(e.target.value)}>
                <MenuItem value="">-- ALL --</MenuItem>
                <MenuItem value="">Waiting</MenuItem>
                <MenuItem value="">Running</MenuItem>
                <MenuItem value="">None</MenuItem>
                <MenuItem value="">Cancle</MenuItem>
                <MenuItem value="">Failed</MenuItem>
                <MenuItem value="">Success</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* 실행요청자 */}
          <Grid item xs={12} sm={6} md={3}>
            <TextField
              label="실행요청자"
              fullWidth
              size="small"
              value={executor}
              onChange={(e) => setExecutor(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  handleSearchClick(e.target.value);
                }
              }}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton onClick={() => handleSearchClick(executor)}>
                      <SearchIcon />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </Grid>

          {/* 작업그룹명 */}
          <Grid item xs={12} sm={6} md={3}>
            <TextField
              label="작업그룹명"
              fullWidth
              size="small"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
            />
          </Grid>

          {/* 실행유형 */}
          <Grid item xs={12} sm={6} md={3}>
            <FormControl fullWidth size="small" sx={{ minWidth: 130 }}>
              <InputLabel>실행유형</InputLabel>
              <Select value={execType} label="실행유형" onChange={(e) => setExecType(e.target.value)}>
                <MenuItem value="">-- ALL --</MenuItem>
                <MenuItem value="">Schedule</MenuItem>
                <MenuItem value="">Ondemand</MenuItem>
                <MenuItem value="">SelectedTask</MenuItem>
                <MenuItem value="">지주시나리오</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* 버튼 */}
          <Grid
            item
            xs={12}
            sm={12}
            md={6}
            sx={{ display: "flex", justifyContent: "flex-end", gap: 1.5 }}
          >
            <Button
              variant="contained"
              color="primary"
              onClick={getBatchGroups}
              sx={{ minWidth: 100, height: 40 }}
            >
              조회
            </Button>
            <Button
              variant="outlined"
              color="secondary"
              onClick={handleReset}
              sx={{ minWidth: 100, height: 40 }}
            >
              초기화
            </Button>
          </Grid>
        </Grid>
      </Paper>

      <Stack height={500}>
        <Box sx={{ width: "100%", overflow: "auto" }}>
          <Box
            sx={{
              minWidth: `${columns.filter((c) => !c.hide).reduce((sum, c) => sum + (c.width || 120), 0)}px`,
              "& .MuiPaper-root": { overflow: "visible !important" },
              "& .MuiTreeView-root": { overflowX: "visible !important" },
            }}
          >
            <GDataTreeGrid
              title="배치실행결과"
              rows={groups}
              columns={columns}
              columnGroupingModel={columnGroupingModel}
              getRowId={(row) => row.SEQ_KEY}
              Buttons={[true, true, true, true]}
              columnHeaderHeight={30}
              rowHeight={25}
              height={480}
              pagination={false}
              hideFooter
              disableRowSelectionOnClick
              loading={loading}
            />
          </Box>
        </Box>
      </Stack>

      <Box mt={2} textAlign="right">
        <Typography variant="body2" color="text.secondary">
          {resultMessage}
        </Typography>
      </Box>

      {/* ✅ 상세 모달 */}
      <Dialog open={openDetailModal} onClose={handleCloseDetailModal} maxWidth="lg" fullWidth>
        <DialogTitle>배치에러상세</DialogTitle>
        <DialogContent>
          <Box sx={{ mb: 2, display: "flex", justifyContent: "flex-end" }}>
            <Button
              variant="contained"
              size="small"
              onClick={() => handleDetailClick(selectedRow)}
            >
              Search
            </Button>
          </Box>

          <Paper sx={{ p: 1, mb: 2, backgroundColor: "#e7f2ff" }}>
            <Typography variant="subtitle1" sx={{ fontWeight: "bold" }}>
              작업결과
            </Typography>
            <Box sx={{ minHeight: 80, backgroundColor: "#f5f7fa", p: 2 }}>
              <pre style={{ margin: 0 }}>
                {resultInfo ? JSON.stringify(resultInfo, null, 2) : "결과 없음"}
              </pre>
            </Box>
          </Paper>

          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 1 }}>
            작업상세로그
          </Typography>

          <div style={{ height: 200, marginBottom: 16 }}>
            <DataGrid
              rows={detailLogs}
              columns={[
                { field: "EXE_TASK_DD", headerName: "실행일자", width: 120 },
                { field: "EXE_TASK_TM", headerName: "실행시간", width: 120 },
                { field: "BAS_DD", headerName: "기준일자", width: 120 },
                { field: "PRG_ID", headerName: "프로그램ID", width: 120 },
                { field: "PK_VAL1", headerName: "PK1", width: 120 },
                { field: "PK_VAL2", headerName: "PK2", width: 120 },
                { field: "PK_VAL3", headerName: "PK3", width: 120 },
                { field: "PK_VAL4", headerName: "PK4", width: 120 },
                { field: "PK_VAL5", headerName: "PK5", width: 120 },
                { field: "ERR_NUMBER", headerName: "ERROR번호", width: 120 },
                { field: "ERR_PROCEDURE", headerName: "ERROR프로시져", width: 120 },
                { field: "ERR_LINE", headerName: "ERROR라인", width: 120 },
                { field: "ERR_MESSAGE", headerName: "ERROR메세지", width: 120 },
                { field: "LOG_SEQ", headerName: "", width: 120, hide: true },
                { field: "EXE_TASK_SEQ", headerName: "", width: 120, hide: true },
                { field: "REG_ID", headerName: "", width: 120, hide: true },
                { field: "ERR_SEVERITY", headerName: "", width: 120, hide: true },
                { field: "ERR_STATE", headerName: "", width: 120, hide: true },
              ]}
              hideFooter
            />
          </div>

          <Typography variant="subtitle1" sx={{ fontWeight: "bold", mb: 1 }}>
            상세 Exception
          </Typography>

          <Box
            sx={{
              backgroundColor: "#f7f9fb",
              border: "1px solid #ddd",
              borderRadius: 1,
              p: 2,
              minHeight: 100,
            }}
          >
            <pre style={{ margin: 0, whiteSpace: "pre-wrap" }}>
              {exceptionText || "예외 내용이 없습니다."}
            </pre>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDetailModal} variant="outlined">
            닫기
          </Button>
        </DialogActions>
      </Dialog>

      {/* ✅ 사용자 검색 모달 */}
      <Dialog open={openUserModal} onClose={() => setOpenUserModal(false)} maxWidth="sm" fullWidth>
        <DialogTitle>사용자목록</DialogTitle>
        <DialogContent>
          <Box sx={{ backgroundColor: "#e8f3ff", p: 2, borderRadius: 1, mb: 2 }}>
            <TextField
              fullWidth
              size="small"
              label="Search"
              value={userSearch}
              onChange={(e) => setUserSearch(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearchClick(e.target.value)}
            />
          </Box>

          <Box sx={{ mb: 1, textAlign: "right" }}>
            <Typography variant="body2" color="text.secondary">
              Total ({userList?.length || 0})
            </Typography>
          </Box>

          <div style={{ height: 320 }}>
            <DataGrid
              rows={userList}
              getRowId={(row) => row.USR_ID}
              columns={[
                { field: "USR_ID", headerName: "USR_ID", width: 250 },
                { field: "USR_NM", headerName: "USR_NM", width: 250 },
              ]}
              onRowClick={(params) => setSelectedUser(params.row)}
              hideFooter
              disableRowSelectionOnClick
            />
          </div>
        </DialogContent>

        <DialogActions>
          <Button onClick={handleUserSelect} variant="contained">
            OK
          </Button>
          <Button onClick={() => setOpenUserModal(false)} variant="outlined">
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
