// GPCLOPRMT02S1.jsx
import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  RadioGroup,
  FormControlLabel,
  Radio,
  Button,
  Paper,
  Grid,
  Stack,
} from "@mui/material";
import axios from "axios";
import { http } from "@/libs/TaskHttp";
import { message } from "antd";
import GDataGrid from "@/components/GDataGrid.jsx";

export default function GPCLOPRMT02S1() {
  // ==============================================================
  // 상태 변수 정의
  // ==============================================================
  const [cboConnStat, setCboConnStat] = useState("");
  const [cboUsrGrp, setCboUsrGrp] = useState("");
  const [rdoConn, setRdoConn] = useState("1"); // 1: 현황, 2: 내역
  const [userGroups, setUserGroups] = useState([]);
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [resultMessage, setResultMessage] = useState("조회 결과가 없습니다.");
  const [selectedGrpId, setSelectedGrpId] = useState(null);

  // ==============================================================
  // 사용자 그룹 조회
  // ==============================================================
  const getUserGroup = async () => {
    try {
      const res = await axios.post("/api/admin/getusergroup");
      console.log("📦 사용자 그룹 데이터:", res.data);
      setUserGroups(res.data);
    } catch (err) {
      console.error("❌ 사용자 그룹 조회 실패:", err);
    }
  };

  // ==============================================================
  // 컬럼 정의
  // ==============================================================
  const columns = [
    { field: "PRSNT_LOGIN_YN", headerName: "접속상태", width: 120 },
    { field: "USR_ID", headerName: "사용자 ID", width: 150 },
    { field: "USR_NM", headerName: "사용자명", width: 150 },
    { field: "USR_GRP_NM", headerName: "사용자유형", width: 150 },
    { field: "CLIENT_IP", headerName: "접속 IP", width: 150 },
    { field: "CONN_DD", headerName: "최근접속일", width: 150 },
    { field: "CONN_STRT_TM", headerName: "접속시간", width: 150 },
    { field: "END_DD", headerName: "접속종료일", width: 150 },
    { field: "CONN_END_TM", headerName: "종료시간", width: 150 },
    // { field: "SECU_PROGM_USE_YN", headerName: "보안PGM사용", width: 150 },
    { field: "", headerName: "History", width: 200 },
  ];

  // ==============================================================
  // 데이터 조회 함수
  // ==============================================================
  const getuserconnectstatus = async () => {
    try {
      setLoading(true);

      const param = {
        SYS_TP_CD: "STO", // 예시 TR시스템코드
        USR_GRP_ID: cboUsrGrp,
        PRSNT_LOGIN_YN:
          cboConnStat === "Y" ? "01" : cboConnStat === "N" ? "02" : "",
        USR_TP_CD: "",
        TR_CONN_STAT: "Y",
      };

      const { name, table } = await http.post(
        "/admin/getuserconnectstatus",
        param,
        { shape: "datatable" }
      );

      setData(table);

      if (table && table.length > 0) {
        setResultMessage(`${table.length}건이 조회되었습니다.`);
        message.info(`${table.length}건이 조회되었습니다.`);
        setSelectedGrpId(table[0]);
      } else {
        setResultMessage("조회 결과가 없습니다.");
        message.warning("조회 결과가 없습니다.");
      }
    } catch (e) {
      console.error("[사용자접속 모니터링] 그룹 조회 실패", e);
      message.error("그룹 목록을 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  };

  // ==============================================================
  // useEffect
  // ==============================================================
  useEffect(() => {
    // getUserGroup();
    getuserconnectstatus();
  }, []);

  // ==============================================================
  // 화면 구성
  // ==============================================================
  return (
    <Box p={2}>
      {/* 헤더 */}
      <Typography variant="h6" sx={{ mb: 2 }}>
        사용자접속모니터링
      </Typography>

      {/* 검색 영역 */}
      <Paper sx={{ p: 2, mb: 2, backgroundColor: "#E7F3FF" }}>
        <Grid container spacing={2} alignItems="center">
          {/* 접속상태 */}
          <Grid item xs={3}>
            <FormControl fullWidth size="small" sx={{ minWidth: 130 }}>
              <InputLabel>접속상태</InputLabel>
              <Select
                value={cboConnStat}
                onChange={(e) => setCboConnStat(e.target.value)}
              >
                <MenuItem value="">-- All --</MenuItem>
                <MenuItem value="Y">로그인</MenuItem>
                <MenuItem value="N">로그아웃</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* 사용자그룹 */}
          <Grid item xs={3}>
            <FormControl fullWidth size="small" sx={{ minWidth: 130 }}>
              <InputLabel>사용자그룹</InputLabel>
              <Select
                value={cboUsrGrp}
                onChange={(e) => setCboUsrGrp(e.target.value)}
              >
                <MenuItem value="">-- All --</MenuItem>
                {userGroups.length > 0 ? (
                  userGroups.map((grp, idx) => (
                    <MenuItem key={idx} value={grp.CD_VAL}>
                      {grp.CD_VAL_NM}
                    </MenuItem>
                  ))
                ) : (
                  <MenuItem disabled>데이터 없음</MenuItem>
                )}
              </Select>
            </FormControl>
          </Grid>

          {/* 접속현황/내역 */}
          <Grid item xs={3}>
            <FormControl>
              <RadioGroup
                row
                value={rdoConn}
                onChange={(e) => setRdoConn(e.target.value)}
              >
                <FormControlLabel
                  value="1"
                  control={<Radio />}
                  label="접속현황"
                />
                <FormControlLabel
                  value="2"
                  control={<Radio />}
                  label="접속내역"
                />
              </RadioGroup>
            </FormControl>
          </Grid>

          {/* 조회 버튼 */}
          <Grid item xs={3} textAlign="right">
            <Button
              variant="contained"
              color="primary"
              onClick={getuserconnectstatus}
              sx={{ fontWeight: "bold" }}
            >
              Search
            </Button>
          </Grid>
        </Grid>
      </Paper>

      {/* 그리드 영역 */}
      <Stack height={600}>
        <Box sx={{ width: "100%", overflow: "auto" }}>
          <Box
            sx={{
              minWidth: `${columns.reduce(
                (sum, c) => sum + (c.width || 120),
                0
              )}px`,
              "& .MuiPaper-root": { overflow: "visible !important" },
              "& .MuiTreeView-root": { overflowX: "visible !important" },
            }}
          >
            <GDataGrid
              title="사용자접속모니터링"
              rows={data}
              columns={columns}
              height={600}
              loading={loading}
              Buttons={[false, false, false, false]}
            />
          </Box>
        </Box>
      </Stack>
    </Box>
  );
}
