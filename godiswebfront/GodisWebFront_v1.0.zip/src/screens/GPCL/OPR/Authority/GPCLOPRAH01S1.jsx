import React, { useEffect, useMemo, useState, useRef } from 'react';
import { Card, Input, Select, Space, message } from 'antd';
import { Box, Checkbox } from '@mui/material';

import GDataGrid from '@/components/GDataGrid.jsx';
import GDataTreeGrid from '@/components/GDataTreeGrid.jsx';

import { Stack } from '@mui/material';
import { Button } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';

// 서버호출
import { http } from '@/libs/TaskHttp';

/**
 * GPCLOPRAH01S1 - 역할 정의 & 메뉴/버튼 권한
 * 상단: DataGrid (역할 정의)
 * 하단: DataGrid (트리 + 권한 체크박스 등 다양한 에디터)
 */
export default function GPCLOPRAH01S1() {
  // ==============================================================
  //                        변수 정의
  // ==============================================================
  const [roles, setRoles] = useState([]);                 // 권한 조회 결과
  const [menu, setMenu] = useState([]);                   // 메뉴 목록
  const [btns, setBtns] = useState([]);                   // 버튼 목록
  const [btnMap, setBtnMapp] = useState([]);              // 버튼별 매핑 목록
  const [menuButnAuth, setMenuButnAuth] = useState([]);   // 메뉴별 버튼 권한 목록

  // 첫 번째 그리드 값 선택 시
  const [selectedRoleId, setSelectedRoleId] = useState(null);


  const [loadingRoles, setLoadingRoles] = useState(false);  // 상단 그리드 로딩
  const [loadingMenus, setLoadingMenus] = useState(false);  // 하위 그리드 로딩

  // === Save 버튼용 상태 ===
  const [savingRole, setSavingRole] = useState(false);
  const [savingMenu, setSavingMenu] = useState(false);

  // === 공통컴포넌트 ref ===
  const roleRef = useRef(null);
  const menuRef = useRef(null);

  // ==============================================================
  //                        데이터 조회 처리
  // ==============================================================
  // ===== 역할 목록 조회 =====
  const getRoles = async () => {
    try {
      // DataTable 호출
      setLoadingRoles(true);

      const param = { SYS_TP_CD: "STO" }; // 조회 조건을 JS 객체(Map 형태)로
      const { name, table } = await http.post('/admin/getroles', param, { shape: 'datatable' });

      setRoles(table);

      if (table.length > 0) {
        handleRoleSelect(table[0].ROLE_ID);    // 하단 그리드 호출 로직
      }
    } catch (e) {
      console.error('[역할정의] 역할 조회 실패', e);
      message.error('역할 목록을 불러오지 못했습니다.');
    } finally {
      setLoadingRoles(false);
    }
  };
  useEffect(() => { getRoles(); }, []);

  // ===== 버튼 권한 목록 조회 =====
  const getMenuButnAuth = async (roleId) => {
    try {
      setLoadingMenus(true);

      const param = {
        SYS_TP_CD: "STO"
        , ROLE_ID: roleId
      }; // 조회 조건을 JS 객체(Map 형태)로

      const { tables } = await http.post('/admin/getMenuButnAuth', param, { shape: 'dataset' });

      setMenuButnAuth(tables.DtMenuButnAuth);  // 메뉴/버튼/권한
      setBtns(tables.DtBtn);                   // 버튼 목록
      setMenu(tables.DtMenu);                  // 메뉴 목록
      setBtnMapp(tables.DtProgmButnMappList);  // 버튼 매핑 목록
    } catch (e) {
      console.error('[메뉴/버튼/권한] 권한 조회 실패', e);
      message.error('권한 목록을 불러오지 못했습니다.');
    } finally {
      setLoadingMenus(false);
    }
  };
  // useEffect(() => { getMenuButnAuth(); }, []);

  // ==============================================================
  //                        데이터 저장 처리
  // ==============================================================
  /** ========== Save: 공통컴포넌트의 I/U/D만 전송 (getCudPayload 사용) ========== */
  const saveRole = async () => {
    const payload = roleRef.current?.getCudPayload?.() || { inserts: [], updates: [], deletes: [] };
    const empty = (!payload.inserts?.length && !payload.updates?.length && !payload.deletes?.length);
    if (empty) {
      message.info('변경된 내역이 없습니다.');
      return;
    }
    try {
      setSavingRole(true);

      const res = await fetch('/api/admin/saverole', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('공통코드그룹 저장 실패');
      await res.json().catch(() => ({}));
      message.success('역할이 저장되었습니다.');
      getRoles();
    } catch (e) {
      console.error(e);
      message.error(e.message || '역할 저장 중 오류가 발생했습니다.');
    } finally {
      setSavingRole(false);
    }
  };

  /** ========== Save: 공통컴포넌트의 I/U/D만 전송 (getCudPayload 사용) ========== */
  const saveMenu = async () => {
    const payload = menuRef.current?.getCudPayload?.() || { inserts: [], updates: [], deletes: [] };
    const empty = (!payload.inserts?.length && !payload.updates?.length && !payload.deletes?.length);
    if (empty) {
      message.info('변경된 내역이 없습니다.');
      return;
    }
    try {
      setSavingRole(true);
      const res = await fetch('/api/admin/saverolemenu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('공통코드그룹 저장 실패');
      await res.json().catch(() => ({}));
      message.success('공통코드그룹이 저장되었습니다.');
    } catch (e) {
      console.error(e);
      message.error(e.message || '공통코드그룹 저장 중 오류가 발생했습니다.');
    } finally {
      setSavingMenu(false);
    }
  };

  // ==============================================================
  //                        이벤트 정의
  // ==============================================================
  // ===== 권한 조회 호출 로직 =====
  const handleRoleSelect = (roleId) => {
    setSelectedRoleId(roleId);
    getMenuButnAuth(roleId);
  };

  // ==== All 클릭 이벤트 =====
  const handleAllToggle = (menuId, progId, checked) => {
    const definedBtns = progBtnMap[progId] || [];
    definedBtns.forEach((btnId) => {
      togglePermission(menuId, btnId, checked);
    });
  };


  // ==============================================================
  //                        그리드 컬럼 정의
  // ==============================================================
  // ===== 역할 정의 컬럼 =====
  const roleColumns = [
    { headerName: "사용자유형", field: 'USR_TP_CD', headerAlign: 'center', width: 110, editable: true },
    { headerName: "역할명", field: 'ROLE_NM', headerAlign: 'center', width: 180, editable: true },
    { headerName: "역할 영문명", field: 'ROLE_ENG_NM', headerAlign: 'center', width: 220, editable: true },
    { headerName: "설명", field: 'roleDsc', headerAlign: 'center', width: 360, editable: true }
  ];

  // ==== 체크박스 선언 ====
  const PermissionCheckbox = React.memo(({ checked, onChange }) => (
    <Checkbox checked={checked} onChange={onChange} />
  ));

  // ===== 메뉴/버튼/권한 컬럼 =====
  // pinned: "left" 를 통해 왼쪽 고정이 가능하지만 pro 버전에서만 가능
  const fixedColumns = [
    {
      headerName: "Menu", field: 'MENU_NM', headerAlign: 'center', width: 260, editable: true
    },
    {
      headerName: "All", field: 'ALL', headerAlign: 'center', width: 70, editable: true, renderCell: ({ row, value }) => {
        const hasDefinedBtns = (progBtnMap[row.PROGM_ID] || []).length > 0;

        return (
          <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100%" }}>
            <PermissionCheckbox
              checked={value}
              disabled={!hasDefinedBtns} // ✅ 버튼 정의 없으면 비활성화
              onChange={(e) => togglePermission(row.MENU_ID, btn.BUTN_ID, e.target.checked)}
            />
          </Box>
        );
      }
    },
  ];

  // ==== 버튼명 컬럼 ====
  const btnColumns = btns.map((btn) => ({
    field: btn.BUTN_ID,
    headerName: btn.BUTN_ID,
    width: 120,
    renderCell: ({ row, value }) => (
      <Checkbox
        checked={value}
        onChange={(e) => togglePermission(row.MENU_ID, btn.BUTN_ID, e.target.checked)}
      />
    ),
  }));

  // ==== 고정 컬럼명 ====
  const finalColumns = [...fixedColumns, ...btnColumns];

  // ==== 화면별 버튼 LIST 세팅 ====
  const progBtnMap = useMemo(() => {
    const map = {};
    btnMap.forEach((item) => {
      if (!map[item.PROGM_ID]) map[item.PROGM_ID] = [];
      map[item.PROGM_ID].push(item.BUTN_ID);
    });
    return map;
  }, [btnMap]);

  // ==== 메뉴 Tree 구조로 값 변경 ====
  const buildTree = (flatList) => {
    const map = {};
    const roots = [];

    flatList.forEach((item) => {
      map[item.MENU_ID] = { ...item, children: [] };
    });

    flatList.forEach((item) => {
      const parentId = item.UP_MENU_ID;
      if (parentId && map[parentId]) {
        map[parentId].children.push(map[item.MENU_ID]);
      } else {
        roots.push(map[item.MENU_ID]);
      }
    });

    return roots;
  };

  // ==== 컬럼/ROW 별 Cell 값 세팅 ====
  const treeRows = useMemo(() => {
    const enriched = menu.map((menuRow) => {
      const row = {
        MENU_ID: menuRow.MENU_ID,
        MENU_NM: menuRow.MENU_NM,
        DEPTH: menuRow.LEVEL,
        UP_MENU_ID: menuRow.UP_MENU_ID,
        PROGM_ID: menuRow.PROGM_ID,
        ALL: false,
      };

      const definedBtns = progBtnMap[menuRow.PROGM_ID] || [];

      definedBtns.forEach((btnId) => {
        const isChecked = menuButnAuth.some(
          (auth) => auth.MENU_ID === menuRow.MENU_ID && auth.BUTN_ID === btnId
        );
        row[btnId] = isChecked;
      });

      row.ALL = definedBtns.length > 0 && definedBtns.every((btnId) => row[btnId]);

      return row;
    });

    const propagated = propagateAllCheck(enriched);

    return buildTree(propagated);
  }, [menu, menuButnAuth, progBtnMap]);

  // ==== 상위 depth 체크 여부 확인 ====
  function propagateAllCheck(rows) {
    const rowMap = Object.fromEntries(rows.map(row => [row.MENU_ID, row]));

    // 하위 → 상위로 반복적으로 ALL 계산
    let changed = true;
    while (changed) {
      changed = false;

      rows.forEach(row => {
        if (!row.UP_MENU_ID) return;

        const parent = rowMap[row.UP_MENU_ID];
        if (!parent) return;

        const siblings = rows.filter(r => r.UP_MENU_ID === parent.MENU_ID);
        const allChildrenChecked = siblings.every(r => r.ALL);

        if (parent.ALL !== allChildrenChecked) {
          parent.ALL = allChildrenChecked;
          changed = true;
        }
      });
    }

    return rows;
  }

  // ==== 체크박스 값 변경 ====
  const togglePermission = (menuId, btnId, checked) => {
    setMenuButnAuth((prev) => {
      const exists = prev.some((auth) => auth.MENU_ID === menuId && auth.BUTN_ID === btnId);
      if (checked && !exists) {
        return [...prev, { MENU_ID: menuId, BUTN_ID: btnId }];
      } else if (!checked && exists) {
        return prev.filter((auth) => !(auth.MENU_ID === menuId && auth.BUTN_ID === btnId));
      }
      return prev;
    });
  };

  // ==============================================================
  //                          화면구성 영역
  // ==============================================================
  return (
    <div>
      {/* 상단: 역할 정의 */}
      <Stack height={300}>
        <Card size="small" title="역할 정의" />
        <GDataGrid
          rows={roles}
          columns={roleColumns}
          getRowId={(row) => row.ROLE_ID}
          columnHeaderHeight={30}
          rowHeight={25}
          checkboxSelection
          disableRowSelectionOnClick
          pagination={false}
          hideFooter
          onRowClick={(params) => { // row 클릭 시 버튼 권한 조회 로직 호출
            handleRoleSelect(params.row.ROLE_ID);
          }}
          onRowSelectionModelChange={(ids) => { // 조회 시 버튼 권한 조회 로직 호출
            const roleId = ids[0];
            handleRoleSelect(roleId);
          }}
        />
        {/* Save 버튼 (공통코드그룹) */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
          <Button auth="Save" type="primary" onClick={saveRole} loading={savingRole} width={100}>
            Save
          </Button>
        </div>
      </Stack>

      {/* 하단: 메뉴/버튼/권한 조회 */}
      <Stack height={300}>
        <Card size="small" title="메뉴버튼/권한" />
        <GDataTreeGrid
          rows={treeRows}
          columns={finalColumns}
          getRowId={(row) => row.MENU_ID}
          checkboxSelection={false}
          disableRowSelectionOnClick
          columnHeaderHeight={30}
          rowHeight={25}
          pagination={false}
          hideFooter
        // onRowClick={(params) => {
        //   const row = params.row;
        //   getItems(row);
        // }}
        />
        {/* Save 버튼 (공통코드그룹) */}
        <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
          <Button auth="Save" type="primary" onClick={saveMenu} loading={savingMenu} width={100}>
            Save
          </Button>
        </div>
      </Stack>
    </div>
  );
}