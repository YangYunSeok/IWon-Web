import React, { createContext, useState, useContext, useMemo } from 'react';

// 기본값(Provider 미적용 시에도 안전)
const defaultState = {
  // globalData는 실제 데이터 저장용 객체입니다. messages/map 구조를 여기에 담습니다.
  globalData: {
    messages: Object.create(null), // code -> text (prototype-less)
    messagesRaw: [],               // 서버 원본 List<Map>
  },
  // Provider 외부에서 setGlobalData 호출 시 경고용 함수
  setGlobalData: () => {
    if (process.env.NODE_ENV !== 'production') {
      console.warn('DataProvider가 없습니다. setGlobalData는 무시됩니다.');
    }
  },
};

const DataContext = createContext(defaultState);

export function DataProvider({ children }) {
  const [globalData, setGlobalData] = useState(defaultState.globalData);

  // globalData가 바뀔 때만 새로운 value 객체 생성
  // globalData를 평탄화해서 최상위에서도 messages 등에 접근할 수 있도록 한다.
  // 또한 globalData와 setGlobalData도 그대로 노출시켜 기존 구조와의 호환성을 유지한다.
  const value = useMemo(() => {
    return {
      // globalData의 속성을 상위로 전파 (messages, messagesRaw 등)
      ...globalData,
      // 기존 구조 유지
      globalData,
      setGlobalData,
    };
  }, [globalData]);

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
}

// Custom Hook
export function useData() {
  return useContext(DataContext);
}