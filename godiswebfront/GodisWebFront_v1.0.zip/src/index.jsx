// src/index.jsx
import React, { useMemo, useEffect, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, useNavigate } from 'react-router-dom';
import 'antd/dist/reset.css';

import { ConfigProvider } from 'antd';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

import { ThemeModeContext } from '@/theme/ThemeModeContext';
import { createMuiThemeFromTokens } from '@/theme/muiThemeFromTokens';
import { createAntdThemeConfig } from '@/theme/antdThemeFromMui';

import { AuthProvider } from '@/context/AuthContext.jsx';
import { PermissionProvider } from '@/authz/PermissionStore';
import PermissionEnforcer from '@/authz/PermissionEnforcer.jsx';
import { useAuth } from '@/context/AuthContext.jsx';
import { DataProvider } from '@/context/DataContext.jsx';
import { http } from '@/libs/TaskHttp';

import App from '@/App';
import Login from '@/login.jsx';

function AuthGate() {
  const navigate = useNavigate();
  const { setUser } = useAuth();
  const [status, setStatus] = React.useState({ loading: true, loggedIn: false });

  React.useEffect(() => {
    (async () => {
      try {
        const res = await http.post('/auth/session', {});
        if (!res || !res.success) {
          setUser(null);
          navigate('/login');
          setStatus({ loading: false, loggedIn: false });
        } else {
          setUser(res.user);
          setStatus({ loading: false, loggedIn: true });
        }
      } catch (e) {
        console.error(e);
        setUser(null);
        setStatus({ loading: false, loggedIn: false });
        navigate('/login');
      }
    })();
  }, [setUser, navigate]);

  if (status.loading) return <div>Loading...</div>;
  if (!status.loggedIn) return (
    <Login onSuccess={() => setStatus({ loading: false, loggedIn: true })} />
  );
  return <App />;
}

function Root() {
  const [mode, setMode] = useState(
    () => localStorage.getItem('mode') || 'light'
  );

  useEffect(() => {
    localStorage.setItem('mode', mode);
    document.documentElement.setAttribute('data-theme', mode);
  }, [mode]);

  // tokens.json → MUI theme
  const muiTheme = useMemo(
    () => createMuiThemeFromTokens(mode),
    [mode]
  );

  // MUI theme → AntD theme config
  const antdThemeConfig = useMemo(
    () => createAntdThemeConfig(muiTheme, mode),
    [muiTheme, mode]
  );

  return (
    <BrowserRouter>
      <ThemeModeContext.Provider value={{ mode, setMode }}>
        <ConfigProvider theme={antdThemeConfig}>
          <ThemeProvider theme={muiTheme}>
            <CssBaseline />
            <AuthProvider>
              <PermissionProvider>
                <PermissionEnforcer>
                  <DataProvider>
                    <AuthGate />
                  </DataProvider>
                </PermissionEnforcer>
              </PermissionProvider>
            </AuthProvider>
          </ThemeProvider>
        </ConfigProvider>
      </ThemeModeContext.Provider>
    </BrowserRouter>
  );
}

createRoot(document.getElementById('root')).render(<Root />);
