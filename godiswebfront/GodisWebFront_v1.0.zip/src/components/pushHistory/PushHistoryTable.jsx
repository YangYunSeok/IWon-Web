import {
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  Paper,
  TableContainer,
  Typography,
} from "@mui/material";
import "./css/pushHistory.css"; // ← 추가

export default function PushHistoryTable({ rows }) {
  return (
    <TableContainer component={Paper} className="ph-tableContainer">
      <Table stickyHeader size="small" aria-label="push-history-table">
        <TableHead>
          <TableRow>
            <TableCell>발신자</TableCell>
            <TableCell>메시지</TableCell>
            <TableCell>발송 시각</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.length === 0 ? (
            <TableRow>
              <TableCell colSpan={3} align="center">
                <Typography variant="body2" className="ph-emptyText">
                  조회 결과가 없습니다.
                </Typography>
              </TableCell>
            </TableRow>
          ) : (
            rows.map((r) => (
              <TableRow key={r.id} hover>
                <TableCell>{r.sender}</TableCell>
                <TableCell>{r.msg}</TableCell>
                <TableCell>{r.time}</TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </TableContainer>
  );
}
