// components/CommonRadio.jsx
import React from 'react';
import { Radio, Space } from 'antd';

const CommonRadio = ({
  value,
  onChange,
  options = [],
  direction = 'horizontal',
  size = 'middle',
  disabled = false,
  buttonStyle = false,
  optionType = 'default', // 'default' | 'button'
  className = '',
  style = {},
  loading = false,
  allowClear = false,
  defaultValue,
  ...rest
}) => {
  // 옵션 정규화
  const normalizedOptions = options.map(option => {
    if (typeof option === 'string') {
      return { label: option, value: option };
    }
    if (typeof option === 'number') {
      return { label: option.toString(), value: option };
    }
    return {
      label: option.label || option.value,
      value: option.value,
      disabled: option.disabled || false,
      ...option
    };
  });

  // 이벤트 핸들러
  const handleChange = (e) => {
    if (onChange) {
      onChange(e.target.value, e);
    }
  };

  // 클리어 핸들러
  const handleClear = () => {
    if (onChange) {
      onChange(undefined);
    }
  };

  const radioGroupProps = {
    value,
    onChange: handleChange,
    size,
    disabled: disabled || loading,
    className,
    style,
    defaultValue,
    optionType: buttonStyle ? 'button' : optionType,
    ...rest
  };

  if (direction === 'vertical') {
    return (
      <div>
        <Radio.Group {...radioGroupProps}>
          <Space direction="vertical">
            {normalizedOptions.map(option => (
              <Radio
                key={option.value}
                value={option.value}
                disabled={option.disabled || disabled || loading}
              >
                {option.label}
              </Radio>
            ))}
          </Space>
        </Radio.Group>
        {allowClear && value && (
          <div style={{ marginTop: 8 }}>
            <a onClick={handleClear} style={{ fontSize: '12px' }}>
              선택 해제
            </a>
          </div>
        )}
      </div>
    );
  }

  return (
    <div>
      <Radio.Group {...radioGroupProps} options={normalizedOptions} />
      {allowClear && value && (
        <a 
          onClick={handleClear} 
          style={{ marginLeft: 8, fontSize: '12px' }}
        >
          선택 해제
        </a>
      )}
    </div>
  );
};

export default CommonRadio;
