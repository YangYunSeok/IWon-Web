import React, { useState, useMemo, useEffect } from "react";
import { SimpleTreeView, TreeItem } from "@mui/x-tree-view";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import { Box, Typography, Paper } from "@mui/material";

/**
 * GDataTreeGrid - GDataGrid 스타일의 트리 그리드
 * @param {Array} rows - 트리 구조 포함된 row 데이터 (children 필드 없어도 DEPTH 기반으로 표현 가능)
 * @param {Array} columns - 컬럼 정의 (field, headerName, width, renderCell 등)
 * @param {Function} getRowId - 각 row의 고유 ID 추출 함수
 * @param {number} columnHeaderHeight - 헤더 높이
 * @param {number} rowHeight - 행 높이
 */
export default function GDataTreeGrid({
  rows = [],
  columns = [],
  getRowId = (row) => row.id,
  columnHeaderHeight = 50,
  rowHeight = 28,
  ...rest
}) {

  // ==== 변수 설정 ====
  const [expandedItems, setExpandedItems] = useState([]);

  // ==== 컬럼 너비 계산 ====
  const gridTemplate = useMemo(() => {
    return columns.map((col) =>
      typeof col.width === "number" ? `${col.width}px` : col.width || "1fr"
    ).join(" ");
  }, [columns]);

  // ==== 트리 구조 일괄 출력 ====
  const allItemIds = useMemo(() => {
    const collectIds = (nodes) => {
      let ids = [];
      nodes.forEach((node) => {
        ids.push(getRowId(node));
        if (node.children?.length) {
          ids = ids.concat(collectIds(node.children));
        }
      });
      return ids;
    };
    return collectIds(rows);
  }, [rows, getRowId]);

  useEffect(() => {
    setExpandedItems(allItemIds);
  }, [allItemIds]);


  // ==== 트리 구조를 DEPTH 기반으로 표현 ====
  const renderTree = (nodes) =>
    nodes.map((node) => {
      const rowId = getRowId(node);
      const depth = node.DEPTH || 0;

      return (
        <TreeItem
          key={rowId}
          itemId={rowId}
          label={
            <Box
              display="grid"
              gridTemplateColumns={gridTemplate}
              alignItems="center"
              sx={{
                "&:hover": { backgroundColor: "#f5f5f5" },
                padding: "4px 8px",
                height: rowHeight,
              }}
            >
              {columns.map((col) => {
                const value = node[col.field];
                return (
                  <Box
                    key={col.field}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      height: "100%", // ✅ 셀 높이 맞추기
                      overflow: "hidden", // ✅ 잘림 방지
                      height: "100%",     // 셀 높이 맞추기 
                      overflow: "hidden", // 잘림 방지
                    }}
                  >
                    {col.renderCell ? (
                      col.renderCell({ row: node, value })
                    ) : col.field === "MENU_NM" ? (
                      <Typography sx={{ pl: `${depth * 16}px` }}>{value}</Typography>
                    ) : (
                      <Typography variant="body2">{value}</Typography>
                    )}
                  </Box>
                );
              })}
            </Box>
          }
        >
          {node.children?.length > 0 ? renderTree(node.children) : null}
        </TreeItem>
      );
    });


  return (
    <Paper elevation={2} sx={{ padding: 1, width: "100%", overflowY: 'auto', overflowX: 'auto' }}>
      {/* 컬럼 헤더 */}
      <Box
        display="grid"
        gridTemplateColumns={gridTemplate}
        height={columnHeaderHeight}
        alignItems="center"
        fontWeight="bold"
        borderBottom="1px solid #ccc"
        paddingX={1}
        mb={0.5}
      >
        {columns.map((col) => (
          <Typography key={col.field}>{col.headerName}</Typography>
        ))}
      </Box>

      {/* 트리 그리드 */}
      <SimpleTreeView
        defaultExpandedItems={allItemIds}
        onExpandedItemsChange={(e, itemIds) => setExpandedItems(itemIds)}
        defaultCollapseIcon={<ExpandMoreIcon />}
        defaultExpandIcon={<ChevronRightIcon />}
      >
        {renderTree(rows)}
      </SimpleTreeView>
    </Paper>
  );
}