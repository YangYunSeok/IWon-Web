import React, { createContext, useContext, useState } from 'react';

// Material‑UI components.  Stack arranges items in a row or column,
// Accordion/AccordionSummary/AccordionDetails provide collapsible panels,
// and Typography/Box render text and containers.
import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

/**
 * Context used by LayoutItem and LayoutGroup to share the maximum label
 * width and a function for registering new widths.  Each group can either
 * inherit the parent context (align labels across groups) or create a new
 * context (align labels locally).  See LayoutGroup for details.
 */
export const LayoutContext = createContext(null);

/**
 * LayoutGroup arranges its children (LayoutItem or nested LayoutGroup)
 * horizontally or vertically using MUI's Stack component.  It also
 * supplies a LayoutContext so that LayoutItem components can align their
 * labels to the widest label in the group.  The `labelAlignment` prop
 * controls whether nested groups share the parent context ('across') or
 * start a new context ('local').
 */
function LayoutGroup({
  children,
  orientation = 'vertical',
  spacing = 1,
  labelAlignment,
  header,
  collapsible = false,
}) {
  // Access the parent context, if any.  If labelAlignment === 'local', we
  // create a new context for this group; otherwise we inherit the parent's
  // context.  If there is no parent context, a new context is created.
  const parentContext = useContext(LayoutContext);
  const isLocal = labelAlignment === 'local';
  const [maxLabelWidth, setMaxLabelWidth] = useState(0);
  const registerLabelWidth = (width) => {
    setMaxLabelWidth((prev) => (width > prev ? width : prev));
  };
  const contextValue = isLocal || !parentContext
    ? { maxLabelWidth, registerLabelWidth }
    : parentContext;

  // Compose children inside a Stack for orientation and spacing.
  const content = (
    <Stack direction={orientation === 'vertical' ? 'column' : 'row'} spacing={spacing}>
      {children}
    </Stack>
  );

  // Render header and optional collapsible functionality.
  let groupBody;
  if (collapsible) {
    groupBody = (
      <Accordion defaultExpanded sx={{ width: '100%' }}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          sx={{ minHeight: 32, '& .MuiAccordionSummary-content': { margin: 0 } }}
        >
          {header && <Typography variant="subtitle2">{header}</Typography>}
        </AccordionSummary>
        <AccordionDetails>{content}</AccordionDetails>
      </Accordion>
    );
  } else if (header) {
    groupBody = (
      <Box sx={{ border: 1, borderColor: 'divider', borderRadius: 1, p: 1, width: '100%' }}>
        <Typography variant="subtitle2" sx={{ mb: 0.5 }}>
          {header}
        </Typography>
        {content}
      </Box>
    );
  } else {
    groupBody = content;
  }

  return (
    <LayoutContext.Provider value={contextValue}>{groupBody}</LayoutContext.Provider>
  );
}

export default LayoutGroup;