import React, { useState, useEffect } from 'react';
import { getItems } from '@/api/codeApi.jsx';
import { Select, MenuItem, FormControl, CircularProgress, InputAdornment } from '@mui/material';

// ✅ 컴포넌트 외부에 캐시 저장소
const CODE_CACHE = {};

const GSelectBox = (props) => {
  const {
    grpCdId,
    data,
    valueKey,
    labelKey,
    value,
    onChange,
    includeAll = true,
    allLabel = '-- All --',
    includeSelect = false,
    selectLabel = '-- Select --',
    width = 160,
    height = 25,
    placeholder,
    disabled = false,
    readOnly = false,
    style = {},
    size = 'small',
    useCache = true,  // ✅ 캐시 사용 여부 (기본값 true)
    ...rest
  } = props;

  const [options, setOptions] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadOptions = async () => {
      console.log('🔹 useEffect 시작 - grpCdId:', grpCdId);

      // ========================================
      // 모드 1: 직접 데이터 모드
      // ========================================
      if (data && Array.isArray(data)) {
        const directOptions = data.map(item => ({
          value: item[valueKey || 'value'],
          label: item[labelKey || 'label']
        }));

        const topOptions = [];
        if (includeAll) {
          topOptions.push({ value: 'ALL', label: allLabel });
        }
        if (includeSelect) {
          topOptions.push({ value: '', label: selectLabel });
        }

        setOptions([...topOptions, ...directOptions]);
        return;
      }

      // ========================================
      // 모드 2: 공통코드 API 모드
      // ========================================
      if (!grpCdId) {
        setOptions([]);
        return;
      }

      setLoading(true);
      try {
        console.log('🔹 getItems 호출 직전 - grpCdId:', grpCdId);
        const items = await getItems(grpCdId);
        console.log('🔹 받은 items:', items);

        // 공통코드 데이터를 옵션 형태로 변환
        const codeOptions = items
          .filter(item => item.USE_YN === 'Y')
          .sort((a, b) => (a.SORT_ORD || 0) - (b.SORT_ORD || 0))
          .map(item => ({
            value: item.CD_VAL,
            label: item.CD_VAL_NM || item.CD_VAL
          }));

        console.log('🔹 변환된 codeOptions:', codeOptions);

        // 상단 옵션 추가
        const topOptions = [];
        if (includeAll) {
          topOptions.push({ value: 'ALL', label: allLabel });
        }
        if (includeSelect) {
          topOptions.push({ value: '', label: selectLabel });
        }

        const finalOptions = [...topOptions, ...codeOptions];
        console.log('🔹 최종 options:', finalOptions);
        
        setOptions(finalOptions);
      } catch (error) {
        console.error('❌ 공통코드 옵션 로드 실패:', error);
        setOptions([]);
      } finally {
        setLoading(false);
      }
    };

    loadOptions();
  }, [grpCdId, data, valueKey, labelKey, includeAll, allLabel, includeSelect, selectLabel]);


  return (
    <FormControl
      size={size}
      disabled={disabled || loading}
      style={{
        width: `${width}px`,
        minWidth: `${width}px`,
        ...style
      }}
      renderInput={(params) => (
        <TextField
          {...params}
          placeholder={placeholder}
          InputProps={{
            ...params.InputProps,
            style: {
              height: `${height}px`,
              minHeight: `${height}px`,
            },
            endAdornment: (
              <>
                {loading ? <CircularProgress color="inherit" size={20} /> : null}
                {params.InputProps.endAdornment}
              </>
            ),
          }}
        />
      )}
      {...rest}
    />
  );
};

export default GSelectBox;