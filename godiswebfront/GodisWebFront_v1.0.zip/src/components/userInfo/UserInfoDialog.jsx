import React, { useMemo } from "react";
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Box,
  Alert,
} from "@mui/material";
import UserInfoCard from "./UserInfoCard";
import "./css/userInfo.css";
import { useAuth } from "@/context/AuthContext";

export default function UserInfoDialog({ open, onClose }) {
  const { user } = useAuth(); // { userId, userNm, usrGrpNm, ... }

  const viewModel = useMemo(() => {
    if (!user) return null;
    return {
      username: user.userId ?? "",
      displayName: user.userNm ?? "",
      department: user.usrGrpNm ?? user.department ?? "",
      position: user.position ?? "",
      accountType: user.accountType ?? "-",  
      groupId: user.usrGrpId ?? "",
      authorities: Array.isArray(user.authorities) ? user.authorities : [],
    };
  }, [user]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="sm"
      fullWidth
      slotProps={{ paper: { className: "ui-paper" } }}
    >
      <DialogTitle className="ui-header">
        <span className="ui-header-title">User Information</span>
      </DialogTitle>

      <DialogContent className="ui-content">
        {!viewModel ? (
          <Alert severity="info">
            로그인 정보가 없습니다. (세션 만료 또는 미로그인)
          </Alert>
        ) : (
          <UserInfoCard user={viewModel} />
        )}
      </DialogContent>

      <DialogActions className="ui-actions">
        <Button onClick={onClose} variant="contained" className="ui-close-btn">
          Close
        </Button>
      </DialogActions>
    </Dialog>
  );
}
