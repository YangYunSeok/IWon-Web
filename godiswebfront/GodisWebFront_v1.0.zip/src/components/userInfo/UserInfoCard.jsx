import { Box } from "@mui/material";
import "./css/userInfo.css";

/**
 * props:
 * - user: { username, accountType, department, position }
 */
export default function UserInfoCard({ user }) {
  return (
    <Box className="ui-card">
      <div className="ui-row">
        <div className="ui-label">사용자</div>
        <div className="ui-sep">|</div>
        <div className="ui-value">{user.username || "-"}</div>

        <div className="ui-spacer" />

        <div className="ui-label">계정유형</div>
        <div className="ui-sep">|</div>
        <div className="ui-value">{user.accountType || "-"}</div>
      </div>

      <div className="ui-row">
        <div className="ui-label">부서명</div>
        <div className="ui-sep">|</div>
        <div className="ui-value">{user.department || "-"}</div>

        <div className="ui-spacer" />

        <div className="ui-label">직위</div>
        <div className="ui-sep">|</div>
        <div className="ui-value">{user.position || "-"}</div>
      </div>
    </Box>
  );
}
