// src/components/GMessageBox.jsx
import * as React from 'react';
import ReactDOM from 'react-dom';
import {
  Dialog, DialogTitle, DialogContent, DialogActions,
  Button, Stack, Typography, Box
} from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import WarningAmberOutlinedIcon from '@mui/icons-material/WarningAmberOutlined';
import ErrorOutlineOutlinedIcon from '@mui/icons-material/ErrorOutlineOutlined';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';

// 전역 DataContext (없으면 안전하게 null 반환하도록 try-catch)
import { useData } from '@/context/DataContext.jsx';

// ---------- 모듈 전역(폴백) ----------
let MESSAGE_MAP = {};           // { CODE: "문구{0}" }
let MESSAGE_RESOLVER = null;    // async (code) => string

export function setMessageMap(map = {}) { MESSAGE_MAP = { ...map }; }
export function setMessageResolver(fn) { MESSAGE_RESOLVER = (typeof fn === 'function') ? fn : null; }

// ---------- 유틸 ----------
function fmt(text, args = []) {
  if (!text) return '';
  let out = String(text);
  args?.forEach((v, i) => { out = out.replace(new RegExp(`\\{${i}\\}`, 'g'), v ?? ''); });
  return out;
}

function safeUseData() {
  try { return useData(); } catch { return null; }
}

function pickFromRow(row, codeKey = ['MSG_CD','msgCd','code'], textKey = ['MSG_NM','msgNm','message']) {
  if (!row) return null;
  let code, text;
  for (const k of codeKey) if (row[k] != null) { code = String(row[k]); break; }
  for (const k of textKey) if (row[k] != null) { text = String(row[k]); break; }
  return (code ? { code, text } : null);
}

function findMessageInList(list, code) {
  if (!Array.isArray(list) || !code) return null;
  for (const r of list) {
    const p = pickFromRow(r);
    if (p && p.code === String(code)) return p.text ?? null;
  }
  return null;
}

// 메시지 해석: message > props.messageMap > 컨텍스트(messages/list/map) > 모듈 resolver > 모듈 map > 코드 그대로
async function resolveMessage({ message, code, args, messageMap, messagesFromContext }) {
  if (message) return fmt(message, args);

  if (code) {
    // 1) props.messageMap
    if (messageMap && messageMap[code]) return fmt(messageMap[code], args);

    // 2) 컨텍스트가 배열 형태인 경우
    if (Array.isArray(messagesFromContext)) {
      const found = messagesFromContext.find(
        (row) =>
          row.MSG_CD === code ||
          row.msgCd === code ||
          row.code === code
      );
      if (found) {
        const msg = found.MSG_NM || found.msgNm || found.message || code;
        return fmt(msg, args);
      }
    }

    // 3) 컨텍스트가 맵 형태인 경우
    if (messagesFromContext && typeof messagesFromContext === 'object') {
      const msg = messagesFromContext[code];
      if (typeof msg === 'string') return fmt(msg, args);
    }

    // 4) 전역 MESSAGE_MAP
    if (MESSAGE_MAP[code]) return fmt(MESSAGE_MAP[code], args);

    // 5) fallback
    return code;
  }

  return '';
}

const PRESETS = {
  Ok: ['ok'],
  OkCancel: ['ok', 'cancel'],
  YesNo: ['yes', 'no'],
  YesNoCancel: ['yes', 'no', 'cancel'],
};

function labelOf(key, labels) {
  const defaults = { ok: 'OK', cancel: 'Cancel', yes: 'Yes', no: 'No' };
  return (labels && labels[key]) || defaults[key] || key;
}

function IconByType({ type = 'info' }) {
  const sx = { fontSize: 28 };
  if (type === 'warning') return <WarningAmberOutlinedIcon color="warning" sx={sx} />;
  if (type === 'error')   return <ErrorOutlineOutlinedIcon color="error" sx={sx} />;
  if (type === 'success') return <CheckCircleOutlineOutlinedIcon color="success" sx={sx} />;
  return <InfoOutlinedIcon color="info" sx={sx} />;
}

// ---------- 프레젠테이션 컴포넌트 ----------
function MessageBoxControl(props) {
  const {
    open, onClose, title, message, code, args,
    messageMap, buttons = 'Ok', buttonLabels,
    type = 'info', maxWidth = 'xs', keepMounted = true,
  } = props;

  // 컨텍스트에서 messages 꺼내기 (Provider 밖이면 null)
  const dataCtx = safeUseData();              // { messages, globalData, cache, ... } | null
  // 컨텍스트에서 메시지 맵 추출.
  // 우선적으로 평탄화된 messages를 사용하고, 그다음 legacy 구조인 globalData.messages, cache.messages 순으로 찾는다.
  let messagesFromContext = null;
  if (dataCtx) {
    if (dataCtx.messages) {
      messagesFromContext = dataCtx.messages;
    } else if (dataCtx.globalData && dataCtx.globalData.messages) {
      messagesFromContext = dataCtx.globalData.messages;
    } else if (dataCtx.cache && dataCtx.cache.messages) {
      messagesFromContext = dataCtx.cache.messages;
    } else {
      messagesFromContext = null;
    }
  }

  const [text, setText] = React.useState('');

  React.useEffect(() => {
    let alive = true;
    (async () => {
      const t = await resolveMessage({ message, code, args, messageMap, messagesFromContext });
      if (alive) setText(t);
    })();
    return () => { alive = false; };
  }, [open, message, code, JSON.stringify(args), messageMap, messagesFromContext]);

  const btnKeys = Array.isArray(buttons) ? buttons : (PRESETS[buttons] || PRESETS.Ok);

  const handleKeyDown = (e) => {
    if (!open) return;
    if (e.key === 'Enter') {
      onClose?.(btnKeys.includes('ok') ? 'ok' : btnKeys[0]);
    } else if (e.key === 'Escape') {
      const esc = btnKeys.includes('cancel') ? 'cancel' : (btnKeys.includes('no') ? 'no' : null);
      if (esc) onClose?.(esc);
    }
  };

  return (
    <Dialog open={open} onClose={() => onClose?.('cancel')} onKeyDown={handleKeyDown}
            maxWidth={maxWidth} fullWidth keepMounted={keepMounted}>
      <DialogTitle sx={{ py: 1.25 }}>
        <Stack direction="row" spacing={1.25} alignItems="center">
          <IconByType type={type} />
          <Typography variant="subtitle1" fontWeight={700}>
            {title || (code ? code : type.toUpperCase())}
          </Typography>
        </Stack>
      </DialogTitle>

      <DialogContent dividers sx={{ pt: 1.5, pb: 2 }}>
        <Box sx={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontSize: 14.5 }}>
          {text}
        </Box>
      </DialogContent>

      <DialogActions sx={{ px: 2, py: 1, display:'flex', justifyContent:'center', gap:1.5 }}>
        {btnKeys.map((k) => (
          <Button key={k}
            variant={(k === 'ok' || k === 'yes') ? 'contained' : 'outlined'}
            color={(k === 'ok' || k === 'yes') ? (props.type === 'error' ? 'error' : 'primary') : 'inherit'}
            onClick={() => onClose?.(k)}
            autoFocus={k === btnKeys[0]}
            sx={{ minWidth: 76 }}>
            {labelOf(k, buttonLabels)}
          </Button>
        ))}
      </DialogActions>
    </Dialog>
  );
}

// ---------- 이벤트 버스 + Host(Provider 안에서 렌더) ----------
const _listeners = new Set();
function _emit(v){ _listeners.forEach(fn => { try{fn(v)}catch{}}); }
function _sub(fn){ _listeners.add(fn); return () => _listeners.delete(fn); }
let _current = null;

function Host() {
  const [state, setState] = React.useState(_current);
  React.useEffect(() => _sub(setState), []);
  if (!state || !state.open) return null;
  return <MessageBoxControl open onClose={state.onClose} {...(state.opts || {})} />;
}

// 정적 API
function Show(code, buttons='Ok', type='info', title='', extra={}) {
  return ShowEx({ code, buttons, type, title, ...extra });
}
function ShowEx(opts={}) {
  return new Promise((resolve) => {
    _current = {
      open: true,
      opts,
      onClose: (result) => { _current = null; _emit(null); resolve(result); }
    };
    _emit(_current);
  });
}

const GMessageBox = { Host, Show, ShowEx, setMessageMap, setMessageResolver };
export default GMessageBox;
