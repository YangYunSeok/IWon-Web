import React, { useState, useEffect } from 'react';
import { Select, Input, Button, Space, message } from 'antd';
import { getCommonCodes } from '@/utils/api'; // axios로 공통코드 조회

const SearchBar = ({ onSearch, loading = false }) => {
  const [grpTypeOptions, setGrpTypeOptions] = useState([{ value: 'ALL', label: '-- All --' }]);
  const [grpNm, setGrpNm] = useState('');
  const [grpType, setGrpType] = useState('ALL');

  useEffect(() => {
    const fetchCodes = async () => {
      try {
        const codes = await getCommonCodes('GRP_TYPE'); // API에서 코드 조회
        const options = codes.map(c => ({ value: c.code, label: c.name }));
        setGrpTypeOptions([{ value: 'ALL', label: '-- All --' }, ...options]);
      } catch (e) {
        console.error(e);
        message.error('공통코드 불러오기 실패');
      }
    };
    fetchCodes();
  }, []);

  const handleClick = () => onSearch(grpNm, grpType);

  return (
    <Space align="center" wrap>
      <Space.Compact>
        <Input
          value={grpNm}
          onChange={(e) => setGrpNm(e.target.value)}
          placeholder="그룹코드명"
          style={{ width: 200 }}
          performanceMode="large"
        />
        <Select
          value={grpType}
          onChange={setGrpType}
          options={grpTypeOptions}
          style={{ width: 160 }}
          performanceMode="large"
        />
      </Space.Compact>
      <Button type="primary" loading={loading} onClick={handleClick}>
        Search
      </Button>
    </Space>
  );
};

export default SearchBar;
