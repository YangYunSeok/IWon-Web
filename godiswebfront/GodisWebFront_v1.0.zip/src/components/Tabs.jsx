import React from 'react';
export default function Tabs({ tabs, activeKey, onChange, onClose, render }) {
  return (
    <div style={{display: 'flex', flexDirection:'column', height: '100%'}}>
      <div className="tabs">
        {tabs.map(t => (
          <div key={t.key} className={'tab' + (activeKey === t.key ? ' active' : '')} onClick={() => onChange?.(t.key)} title={t.title}>
            {t.title}
            <button onClick={(e) => { e.stopPropagation(); onClose?.(t.key); }} aria-label="close">×</button>
          </div>
        ))}
      </div>
      <div className="tabpanel">
        {tabs.length === 0 ? (<div className="help">좌측 메뉴를 클릭해 탭을 여세요.</div>) : (
          tabs.map(t => (<div key={t.key} style={{display: activeKey === t.key ? 'block' : 'none'}}>{render?.(t)}</div>))
        )}
      </div>
    </div>
  );
}
