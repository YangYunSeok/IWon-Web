// src/App.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import { useAuth } from '@/context/AuthContext';
import AutoLogout from '@/hooks/AutoLogout';
import SessionKeepStatus from '@/hooks/SessionKeepStatus';

import { useTheme } from '@mui/material/styles';
import {
  AppBar,
  Toolbar,
  Box,
  Tabs as MuiTabs,
  Tab,
  Card,
  Switch as MuiSwitch,
  Tooltip as MuiTooltip,
  Stack,
  Autocomplete,
  TextField,
  IconButton,
  Typography,
} from '@mui/material';

// 🔹 RichTreeView (MUI X)
import { RichTreeView } from '@mui/x-tree-view/RichTreeView';

import { useThemeMode } from '@/theme/ThemeModeContext';

import PageHost from '@/pages/PageHost.jsx';
import Placeholder from '@/pages/Placeholder.jsx';
import { usePerm } from '@/authz/PermissionStore.jsx';
import { http } from '@/libs/TaskHttp';
import { cacheMsgs } from '@/libs/DataUtils';
import { useData } from '@/context/DataContext.jsx';
import GMessageBox from '@/components/GMessageBox.jsx';

import {
  LogoutOutlined,
  UserOutlined,
  LockOutlined,
  HomeOutlined,
  DatabaseOutlined,
  FormOutlined,
  ProjectOutlined,
  SettingOutlined,
  NotificationOutlined,
} from '@ant-design/icons';
import NotificationSocket from './components/socket/NotifcationSocket';
import PushHistoryDialog from "./components/pushHistory/PushHistoryDialog";
import UserInfoDialog from "./components/userInfo/UserInfoDialog";

// ----------------- 유틸 -----------------

function buildTreeData(data) {
  return data.map(item => {
    const titleContent = item.code ? (
      <span>
        <span className="menu-num">{item.code}</span>
         <span className="menu-label">{item.title}</span>
      </span>
    ) : item.title;

    const node = {
      key: item.key,
      title: titleContent,
      // 텍스트 label용 (RichTreeView label에 사용)
      screnNo:item.screnNo,
      titleText:
        typeof item.title === 'string'
          ? item.title
          : (item.menuNm || ''),
      butnId: item.butnId ?? item.BUTN_ID ?? '',
      menuId: item.menuId ?? item.key,
      clssNm: item.clssNm || item.CLSS_NM || item.className,
    };

    if (item.children) node.children = buildTreeData(item.children);
    if (item.component) node.component = item.component;
    return node;
  });
}

function createContent(node) {
  const titleText =
    node?.titleText ||
    node?.menuNm ||
    (typeof node?.title === 'string' ? node.title : '');
  const clssNm = node?.clssNm || node?.CLSS_NM || node?.className;
  return clssNm
    ? <PageHost clssNm={clssNm} title={titleText} />
    : <Placeholder title={titleText} />;
}

function Brand({ onClick, color }) {
  return (
    <Box
      onClick={onClick}
      sx={{
        display: 'flex',
        alignItems: 'center',
        gap: 1.75,
        px: 2.5,
        cursor: 'pointer',
        userSelect: 'none',
        whiteSpace: 'nowrap',
      }}
      aria-label="MetaDomix Studio Home"
      title="MetaDomix Studio"
    >
      <svg width="28" height="28" viewBox="0 0 24 24" role="img" aria-hidden="true">
        <g
          fill="none"
          stroke={color}
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <rect x="3" y="3" width="18" height="18" rx="3" />
          <path d="M9 3v18M15 3v18M3 9h18M3 15h18" />
        </g>
      </svg>
      <Box sx={{ display: 'flex', alignItems: 'baseline', gap: 0.75 }}>
        <Typography
          variant="h5"
          sx={{ fontWeight: 900, color, letterSpacing: 0.4 }}
        >
          MetaDomix
        </Typography>
        <Typography
          variant="h6"
          sx={{ fontWeight: 600, color, opacity: 0.85 }}
        >
          Studio
        </Typography>
      </Box>
    </Box>
  );``
}

// ----------------- 메인 컴포넌트 -----------------

export default function App() {
  const { mode, setMode } = useThemeMode();
  const theme = useTheme();

  const SHADOW_1 = theme.shadows?.[1] ?? theme.shadows[1];

  SessionKeepStatus();
  AutoLogout(30);

  const { user, setUser } = useAuth();
  const navigate = useNavigate();
  const { setActive } = usePerm();
  const { setGlobalData } = useData();

  const [menuData, setMenuData] = useState([]);
  const [openTopMenu, setOpenTopMenu] = useState(null);

  const [tabs, setTabs] = useState([]);
  const [activeKey, setActiveKey] = useState(undefined);

  const [sidebarWidth, setSidebarWidth] = useState(260);
  const [isResizing, setIsResizing] = useState(false);

  const [pushOpen, setPushOpen] = useState(false);
  const [userInfoOpen, setUserInfoOpen] = useState(false);

  const [treeItems, setTreeItems] = useState([]);
  const [treeNodeMap, setTreeNodeMap] = useState({}); // id → 원래 node 매핑

  // -------- 메시지 캐시 --------
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        if (!user?.userId) return;
        const param = { MSG_CLSS_CD: '01' };
        const list = await cacheMsgs(param);
        if (!Array.isArray(list)) return;
        const idx = {};
        for (const r of list) {
          const code = r?.MSG_CD ?? r?.msgCd ?? r?.code;
          const text = r?.MSG_NM ?? r?.msgNm ?? r?.message;
          if (code && typeof text === 'string') idx[String(code)] = text;
        }
        if (!cancelled) {
          setGlobalData(prev => ({
            ...(prev || {}),
            messagesRaw: list,
            messages: idx,
          }));
        }
      } catch (e) {
        console.error('[App] message cache fail:', e);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.userId, setGlobalData]);

  // -------- 메뉴 로딩 --------
  useEffect(() => {
    async function fetchMenus() {
      if (!user?.userId) {
        navigate('/login');
        return;
      }
      try {
        const param = { SYS_TP_CD: 'STO', USR_ID: user.userId };
        const { table = [] } = await http.post('/webcom/getmain', param, { shape: 'datatable' });

        const idToNode = {};
        table.forEach(item => {
          idToNode[item.MENU_ID] = {
            key: item.MENU_ID,
            title: item.MENU_NM,
            titleText: item.MENU_NM,
            butnId: item.BUTN_ID || '',
            progmId: item.PROGM_ID,
            screnNo: item.SCREN_NO,
            clssNm: item.CLSS_NM,
            children: [],
          };
        });

        table.forEach(item => {
          const node = idToNode[item.MENU_ID];
          node.component =
            item.CLSS_NM && String(item.CLSS_NM).trim()
              ? <PageHost clssNm={item.CLSS_NM} title={item.MENU_NM} />
              : <Placeholder title={item.MENU_NM} />;
          if (item.UP_MENU_ID && idToNode[item.UP_MENU_ID]) {
            idToNode[item.UP_MENU_ID].children.push(node);
          }
        });

        const roots = [];
        table.forEach(item => {
          if (item.LV === 1) {
            const node = idToNode[item.MENU_ID];
            const title = item.MENU_NM;
            let icon;
            if (title.includes('Home') || title.includes('대시보드') || title.includes('홈'))
              icon = <HomeOutlined />;
            else if (title.includes('기초') || title.includes('자산'))
              icon = <DatabaseOutlined />;
            else if (title.includes('청약') || title.includes('배정'))
              icon = <FormOutlined />;
            else if (title.includes('배치') || title.includes('운영'))
              icon = <ProjectOutlined />;
            else if (title.includes('관리'))
              icon = <SettingOutlined />;
            else
              icon = <FormOutlined />;

            node.icon = icon;
            roots.push(node);
          }
        });

        setMenuData(roots);
        if (roots.length > 0) setOpenTopMenu(roots[0].key);
      } catch (error) {
        console.error('Failed to load menus', error);
      }
    }
    fetchMenus();
  }, [user?.userId, navigate]);

  // -------- 메뉴 변경 시 RichTreeView용 아이템 생성 --------
  useEffect(() => {
    const root = menuData.find(item => item.key === openTopMenu);
    const children = root?.children || [];
    const mapped = {};
    const toItems = (nodes) =>
      nodes.map(n => {
        const id = String(n.key);
        mapped[id] = n; // 클릭 시 다시 찾기용
        return {
          id,
          label: n.screnNo ? "[" + n.screnNo + "] " +  n.titleText || n.title : n.titleText || n.title , // 문자열/JSX 모두 허용
          children: n.children ? toItems(n.children) : undefined,
        };
      });

    const items = toItems(children);
    setTreeItems(items);
    setTreeNodeMap(mapped);
  }, [menuData, openTopMenu]);

  
  const handleTopMenuClick = (_e, value) => {
    setOpenTopMenu(value);
  };

  const openNodeAsTab = (node) => {
    if (!node) return;
    const { key, children } = node;

    try {
      setActive(String(node.menuId || node.key || ''), node.butnId);
    } catch {}

    if (children && children.length > 0) return;

    const existing = tabs.find(tab => tab.key === key);
    if (existing) {
      setActiveKey(existing.key);
    } else {
      const newTab = {
        key,
        title: node.titleText || node.title,
        content: node.component || createContent(node),
        node,
      };
      setTabs(prev => [...prev, newTab]);
      setActiveKey(key);
    }
  };

  const handleTreeItemClick = (_event, itemId) => {
    const node = treeNodeMap[itemId];
    if (node) openNodeAsTab(node);
  };

  const removeTab = (targetKey) => {
    const newTabs = tabs.filter(tab => tab.key !== targetKey);
    if (newTabs.length === 0) {
      setTabs([]);
      setActiveKey(undefined);
      return;
    }

    if (activeKey === targetKey) {
      const idx = tabs.findIndex(tab => tab.key === targetKey);
      const fallback = newTabs[idx] || newTabs[idx - 1] || newTabs[0];
      setActiveKey(fallback.key);
      try {
        if (fallback.node) {
          setActive(
            String(fallback.node.menuId || fallback.node.key || ''),
            fallback.node.butnId
          );
        }
      } catch {}
    }

    setTabs(newTabs);
  };

  const getLeafNodes = (data, leaves = []) => {
    data.forEach(item => {
      if (item.children?.length) getLeafNodes(item.children, leaves);
      else if (item.component) {
        leaves.push({
          key: item.key,
          code: item.code || '',
          title: item.title,
          title: item.title,
        });
      }
    });
    return leaves;
  };

  const leafNodes = getLeafNodes(menuData);
  const selectOptions = leafNodes.map(item => ({
    label: `${item.code ? item.code + ' ' : ''}${item.title}`,
    value: item.key,
  }));

  const openTabByKey = (value) => {
    if (!value) return;
    const findItem = (data, key) => {
      for (const item of data) {
        if (item.key === key) return item;
        if (item.children) {
          const found = findItem(item.children, key);
          if (found) return found;
        }
      }
      return null;
    };
    const node = findItem(menuData, value);
    if (node) openNodeAsTab(node);
  };

  const handleMouseDown = () => setIsResizing(true);
  const handleMouseMove = (e) => {
    if (!isResizing) return;
    const next = Math.min(400, Math.max(180, e.clientX));
    setSidebarWidth(next);
  };
  const handleMouseUp = () => setIsResizing(false);

  const handleLogout = async () => {
    if (!window.confirm('정말 로그아웃 하시겠습니까?')) return;
    try {
      await http.post('/auth/logout');
      setUser(null);
      navigate('/login', { replace: true });
    } catch (err) {
      console.error('Logout failed', err);
    }
  };

  const handleUserInfo = () => setUserInfoOpen(true);
  const handlePushInfo = () => setPushOpen(true);
  const handleLock = () => window.alert('화면 잠금 기능이 호출되었습니다.');

  // ----------------- 렌더 -----------------

  return (
    <>
      {GMessageBox?.Host ? <GMessageBox.Host /> : null}

      <Box
        sx={{
          minHeight: '100vh',
          bgcolor: theme.palette.background.default,
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* 상단 헤더 */}
        <AppBar
          position="static"
          sx={{ bgcolor: theme.palette.primary.main, color: theme.palette.primary.contrastText, boxShadow: 'none' }}
        >
          <Toolbar
            sx={{
              minHeight: 64,
              px: 0,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              width: '100%',
            }}
          >
            <Brand
              onClick={() => {
                if (menuData?.length) setOpenTopMenu(menuData[0].key);
              }}
              color={theme.palette.primary.contrastText}
            />

            {/* 상단 메뉴: Tabs */}
            <MuiTabs
              value={openTopMenu || false}
              onChange={handleTopMenuClick}
              sx={{
                flex: 1,
                ml: 5,
                '& .MuiTab-root': {
                  color: theme.palette.primary.contrastText,
                  minHeight: 64,
                  textTransform: 'none',
                },
                '& .Mui-selected': {
                  color: theme.palette.primary.contrastText,
                  fontWeight: 600,
                  bgcolor: 'rgba(255,255,255,0.5)',
                },
                '& .MuiTabs-indicator': {
                  bgcolor: theme.palette.primary.contrastText,
                },
              }}
            >
              {menuData.map(item => (
                <Tab
                  key={item.key}
                  value={item.key}
                  label={item.title}
                  icon={item.icon}
                  iconPosition="start"
                />
              ))}
            </MuiTabs>

            {/* 우측 컨트롤 */}
            <Stack
              direction="row"
              spacing={1.2}
              alignItems="center"
              sx={{ ml: 2.5, mr: 2, zIndex: 10 }}
            >
              <MuiTooltip title={`테마 전환 (${mode === 'light' ? 'Light' : 'Dark'})`}>
                <MuiSwitch
                  checked={mode === 'dark'}
                  onChange={(e) => setMode(e.target.checked ? 'dark' : 'light')}
                  sx={{ mr: 0.5 }}
                />
              </MuiTooltip>

              <MuiTooltip title="화면 잠금">
                <IconButton size="small" onClick={handleLock} sx={{ color: theme.palette.primary.contrastText }}>
                  <LockOutlined />
                </IconButton>
              </MuiTooltip>
              <MuiTooltip title="PUSH 알림내역">
                <IconButton size="small" onClick={handlePushInfo} sx={{ color: theme.palette.primary.contrastText }}>
                  <NotificationOutlined />
                </IconButton>
              </MuiTooltip>
              <MuiTooltip title="사용자 정보">
                <IconButton size="small" onClick={handleUserInfo} sx={{ color: theme.palette.primary.contrastText }}>
                  <UserOutlined />
                </IconButton>
              </MuiTooltip>
              <MuiTooltip title="로그아웃">
                <IconButton size="small" onClick={handleLogout} sx={{ color: theme.palette.primary.contrastText }}>
                  <LogoutOutlined />
                </IconButton>
              </MuiTooltip>
            </Stack>
          </Toolbar>
        </AppBar>

        {/* 본문 */}
        <Box
          sx={{
            display: 'flex',
            flex: 1,
            height: 'calc(100vh - 64px)',
          }}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {/* 좌측: 검색 + RichTreeView */}
          <Box
            sx={{
              width: sidebarWidth,
              bgcolor: theme.palette.background.default,
              p: 1,
              overflowY: 'auto',
            }}
          >
            <Autocomplete
              size="small"
              options={selectOptions}
              getOptionLabel={(opt) => opt.label || ''}
              onChange={(_, value) => openTabByKey(value?.value)}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="메뉴 검색"
                  placeholder="메뉴 검색"
                  variant="outlined"
                  fullWidth
                  sx={{ mb: 1 }}
                />
              )}
            />

            <RichTreeView
              items={treeItems}
              defaultExpandedItems={treeItems.map(i => i.id)} // 1차 확장 (필요시 조정)
              sx={{
                flexGrow: 1,
                bgcolor: 'transparent',
                color: theme.palette.text.primary,
                '& .MuiRichTreeView-itemLabel': {
                  fontSize: 14,
                },
              }}
              onItemClick={handleTreeItemClick}
            />
          </Box>

          {/* 리사이즈 핸들 */}
          <Box
            sx={{
              width: 4,
              cursor: 'col-resize',
              bgcolor: 'rgba(0,0,0,0.08)',
            }}
            onMouseDown={handleMouseDown}
          />

          {/* 우측: 탭 + 컨텐츠 */}
          <Box
            id="app-content-root"
            sx={{
              flex: 1,
              overflow: 'hidden',
              height: '100%',
              bgcolor: theme.palette.background.default,
              p: 1,
            }}
          >
            <Card
              sx={{
                height: '100%',
                boxShadow: SHADOW_1,
                bgcolor: theme.palette.background.paper,
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              {/* 탭 바 */}
              <Box
                sx={{
                  display: 'flex',
                  alignItems: 'center',
                  borderBottom: 1,
                  borderColor: 'divider',
                  minHeight: 30,
                  px: 1,
                  gap: 0.2,
                  flexShrink: 0,
                }}
              >
                {tabs.map(tab => (
                  <Box
                    height={30}
                    key={tab.key}
                    onClick={() => setActiveKey(tab.key)}
                    sx={{
                      display: 'flex',
                      alignItems: 'center',
                      px: 1.2,
                      py: 0.4,
                      mr: 0.5,
                      borderTopLeftRadius: 8,     // 왼쪽 상단 모서리
                      borderTopRightRadius: 8,    // 오른쪽 상단 모서리
                      borderBottomLeftRadius: 0,  // 왼쪽 하단 모서리 (직각)
                      borderBottomRightRadius: 0, // 오른쪽 하단 모서리 (직각)
                      cursor: 'pointer',
                      bgcolor:
                        activeKey === tab.key ? theme.palette.action.selected : 'transparent',
                      '&:hover': {
                        bgcolor: theme.palette.action.hover,
                      },
                    }}
                  >
                    <Typography variant="body2" noWrap sx={{ mr: 0.5 }}>
                      {tab.title}
                    </Typography>
                    <IconButton
                      size="small"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeTab(tab.key);
                      }}
                    >
                      ✕
                    </IconButton>
                  </Box>
                ))}
              </Box>

              {/* 탭 컨텐츠 */}
              <Box sx={{ flex: 1, overflow: 'hidden' }}>
                {tabs.map(tab =>
                  tab.key === activeKey ? (
                    <Box key={tab.key} sx={{ height: '100%' }}>
                      {tab.content}
                    </Box>
                  ) : null
                )}
              </Box>
            </Card>
          </Box>
        </Box>
      </Box>

      <PushHistoryDialog open={pushOpen} onClose={() => setPushOpen(false)} />
      <NotificationSocket />
      <UserInfoDialog
        open={userInfoOpen}
        onClose={() => setUserInfoOpen(false)}
        fetchUrl="/api/users/me"
      />
    </>
  );
}
